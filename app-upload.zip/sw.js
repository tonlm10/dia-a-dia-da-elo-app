importScripts('./version.js');
const APP_VERSION=self.ELO_APP_VERSION||'4.0.0';
const CACHE=`elo-official-${APP_VERSION}-r30`;
const CORE=['./','./index.html','./version.js','./styles.css','./v3.css','./polish.css','./games-v350.css','./app.js','./v3.js','./pet.js','./manifest.webmanifest','./privacy.html','./terms.html','./rpg.html','./assets/rpg-cover-v1-5.png','./assets/logo-oficial.webp','./assets/icons/icon-192.png','./assets/icons/icon-512.png','./assets/icons/icon-maskable-192.png','./assets/icons/icon-maskable-512.png','./assets/icons/apple-touch-icon.png','./assets/audio/elo-intro.m4a','./assets/game-ui/unicorn.svg','./assets/game-ui/ghost.svg'];
async function addSafe(cache,urls){await Promise.allSettled(urls.map(async u=>{try{const r=await fetch(u,{cache:'reload'});if(r.ok)await cache.put(u,r.clone())}catch(_){}}))}
self.addEventListener('install',e=>e.waitUntil((async()=>{const c=await caches.open(CACHE);await addSafe(c,CORE);await self.skipWaiting()})()));
self.addEventListener('activate',e=>e.waitUntil((async()=>{const ks=await caches.keys();await Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})()));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const u=new URL(e.request.url);
  if(u.origin!==location.origin)return;
  const fresh=e.request.mode==='navigate'||/\/(index\.html|app\.js|v3\.js|pet\.js|styles\.css|v3\.css|polish\.css|games-v350\.css|version\.js|rpg\.html|manifest\.webmanifest|privacy\.html|terms\.html)$/.test(u.pathname);
  if(fresh){
    e.respondWith((async()=>{
      try{
        const r=await fetch(e.request.url,{cache:'no-store'});
        if(r.ok){const c=await caches.open(CACHE);c.put(e.request,r.clone())}
        return r;
      }catch(_){
        return (await caches.match(e.request))||(e.request.mode==='navigate'?await caches.match('./index.html'):new Response('',{status:504}));
      }
    })());
    return;
  }
  e.respondWith((async()=>{
    const hit=await caches.match(e.request);
    if(hit)return hit;
    try{
      const r=await fetch(e.request);
      if(r.ok){const c=await caches.open(CACHE);c.put(e.request,r.clone())}
      return r;
    }catch(_){
      return new Response('',{status:504});
    }
  })());
});
