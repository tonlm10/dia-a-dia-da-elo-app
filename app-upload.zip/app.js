
function drawFlyingUnicorn(ctx, x, y, isFlying){
  ctx.save();
  ctx.translate(x, y);

  if(isFlying){
    const rainbowColors=['rgba(236,72,153,0.55)','rgba(168,85,247,0.55)','rgba(56,189,248,0.55)','rgba(250,204,21,0.55)'];
    for(let i=0;i<4;i++){
      ctx.fillStyle=rainbowColors[i];
      ctx.beginPath();
      ctx.ellipse(-26-i*12, 22+i*4, 20, 6, -0.15, 0, Math.PI*2);
      ctx.fill();
    }
  }

  const tailColors=['#ec4899','#a855f7','#38bdf8','#34d399'];
  for(let i=0;i<tailColors.length;i++){
    ctx.fillStyle=tailColors[i];
    ctx.beginPath();
    ctx.ellipse(-22-i*5, 18+Math.sin(trailTick*0.25+i)*5, 11, 5, -0.4, 0, Math.PI*2);
    ctx.fill();
  }

  ctx.fillStyle='#f8f5fc';
  if(isFlying){
    ctx.fillRect(40, 26, 14, 6);
    ctx.fillRect(44, 30, 12, 5);
    ctx.fillRect(-12, 26, 14, 6);
    ctx.fillRect(-15, 30, 12, 5);
    ctx.fillStyle='#fbbf24';
    ctx.fillRect(52, 25, 7, 7);
    ctx.fillRect(-19, 25, 7, 7);
  } else {
    ctx.fillRect(36, 22, 7, 20);
    ctx.fillRect(47, 22, 7, 20);
    ctx.fillRect(-6, 22, 7, 20);
    ctx.fillRect(5, 22, 7, 20);
    ctx.fillStyle='#fbbf24';
    ctx.fillRect(36, 38, 7, 6);
    ctx.fillRect(47, 38, 7, 6);
    ctx.fillRect(-6, 38, 7, 6);
    ctx.fillRect(5, 38, 7, 6);
  }

  ctx.fillStyle='#ffffff';
  ctx.beginPath();
  ctx.ellipse(20, 18, 32, 16, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.strokeStyle='#e9d5ff';
  ctx.lineWidth=1.5;
  ctx.stroke();

  ctx.fillStyle='#ec4899';
  ctx.beginPath();
  ctx.roundRect(12, 8, 22, 9, 3);
  ctx.fill();
  ctx.fillStyle='#fde047';
  ctx.beginPath();
  ctx.arc(23, 12, 2.5, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle='#ffffff';
  ctx.beginPath();
  ctx.moveTo(34, 14);
  ctx.lineTo(52, -3);
  ctx.lineTo(62, -3);
  ctx.lineTo(48, 22);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.ellipse(58, -1, 14, 11, 0.2, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle='#ffd8e8';
  ctx.beginPath();
  ctx.ellipse(68, 2, 7, 6, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.fillStyle='#f472b6';
  ctx.beginPath();
  ctx.arc(70, 1, 1.5, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle='#4c1d95';
  ctx.beginPath();
  ctx.arc(60, -3, 2.8, 0, Math.PI*2);
  ctx.fill();
  ctx.fillStyle='#ffffff';
  ctx.beginPath();
  ctx.arc(61, -4, 0.9, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle='rgba(244, 114, 182, 0.5)';
  ctx.beginPath();
  ctx.ellipse(58, 2, 3.5, 2, 0, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle='#ffffff';
  ctx.beginPath();
  ctx.moveTo(50, -10);
  ctx.lineTo(54, -19);
  ctx.lineTo(58, -10);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle='#fbcfe8';
  ctx.beginPath();
  ctx.moveTo(52, -11);
  ctx.lineTo(54, -16);
  ctx.lineTo(56, -11);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle='#fde047';
  ctx.beginPath();
  ctx.moveTo(63, -7);
  ctx.lineTo(76, -21);
  ctx.lineTo(66, -4);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle='#ffffff';
  ctx.beginPath();
  ctx.arc(76, -21, 2, 0, Math.PI*2);
  ctx.fill();

  const maneColors=['#ec4899','#a855f7','#38bdf8','#fbbf24'];
  for(let i=0;i<maneColors.length;i++){
    ctx.fillStyle=maneColors[i];
    ctx.beginPath();
    ctx.ellipse(47-i*5, -2+i*4, 7, 4.5, -0.3, 0, Math.PI*2);
    ctx.fill();
  }

  const wingFlap=isFlying?Math.sin(trailTick*0.35)*0.45:Math.sin(trailTick*0.1)*0.15;
  ctx.save();
  ctx.translate(20, 10);
  ctx.rotate(wingFlap);
  ctx.fillStyle='#bae6fd';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(-12, -30, -4, -42);
  ctx.quadraticCurveTo(12, -38, 16, -20);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle='#fbcfe8';
  ctx.beginPath();
  ctx.moveTo(2, -2);
  ctx.quadraticCurveTo(-6, -24, 0, -32);
  ctx.quadraticCurveTo(10, -29, 11, -15);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle='#38bdf8';
  ctx.beginPath();
  ctx.arc(-4, -42, 2, 0, Math.PI*2);
  ctx.fill();
  ctx.restore();

  ctx.restore();
}

const APP_VERSION=self.ELO_APP_VERSION||'4.0.0';

// ===== v2.0 • Perfis locais, acessibilidade, tempo saudável, tutorial e backup =====
const V2_PROFILES_KEY='eloProfilesV2',V2_ACTIVE_KEY='eloActiveProfileId',V2_MIGRATION_KEY='eloProfilesV2Migrated';
const V2_AVATARS=['🌟','🦄','🌈','🎀','🐱','🦋','🎮','🎨'];
function loadProfiles(){try{const v=JSON.parse(localStorage.getItem(V2_PROFILES_KEY)||'[]');return Array.isArray(v)?v:[]}catch(_){return[]}}
function saveProfiles(v){localStorage.setItem(V2_PROFILES_KEY,JSON.stringify(v))}
function ensureProfiles(){let ps=loadProfiles();if(!ps.length){ps=[{id:'elo',name:'Elo',avatar:'🌟',ageRange:'6-8',createdAt:Date.now()}];saveProfiles(ps)}let changed=false;ps=ps.map(p=>{if(!p.ageRange){changed=true;return {...p,ageRange:'6-8'}}return p});if(changed)saveProfiles(ps);let active=localStorage.getItem(V2_ACTIVE_KEY);if(!ps.some(x=>x.id===active)){active=ps[0].id;localStorage.setItem(V2_ACTIVE_KEY,active)}if(localStorage.getItem(V2_MIGRATION_KEY)!=='1'){const oldKeys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&(/^eloStars$|^eloFavStories$|^eloReadStories$|^eloRpgSaveV1$|^eloRpgMedals$|^eloMedal-|^eloMemoryHardWon$|^eloPuzzleWon$|^artReward|^eloDaily|^daily-/.test(k)))oldKeys.push(k)}for(const k of oldKeys){const dest=`eloProfile:${active}:${k}`;if(localStorage.getItem(dest)==null)localStorage.setItem(dest,localStorage.getItem(k))}localStorage.setItem(V2_MIGRATION_KEY,'1')}return {profiles:ps,active}}
let __profileState=ensureProfiles();
let activeProfileId=__profileState.active;
function pkey(k){return `eloProfile:${activeProfileId}:${k}`}
function pget(k){return localStorage.getItem(pkey(k))}
function pset(k,v){localStorage.setItem(pkey(k),v)}
function premove(k){localStorage.removeItem(pkey(k))}
function getActiveProfile(){return loadProfiles().find(x=>x.id===activeProfileId)||loadProfiles()[0]||{id:'elo',name:'Elo',avatar:'🌟'}}
function setActiveProfile(id){if(!loadProfiles().some(x=>x.id===id))return;localStorage.setItem(V2_ACTIVE_KEY,id);location.reload()}
function chooseAgeRange(current='6-8'){const raw=(prompt('Faixa etária do perfil:\n1 = 3–5 anos\n2 = 6–8 anos\n3 = 9–11 anos',current==='3-5'?'1':current==='9-11'?'3':'2')||'').trim();return raw==='1'?'3-5':raw==='3'?'9-11':raw==='2'?'6-8':null}
function createProfile(){requestParentAccess(createProfileUnlocked,'Digite o PIN dos responsáveis para criar um perfil.')}
function createProfileUnlocked(){const ps=loadProfiles();if(ps.length>=4)return toast('Máximo de 4 perfis neste aparelho.');let name=(prompt('Nome do perfil (somente neste aparelho):','')||'').trim().slice(0,18);if(!name)return;const ageRange=chooseAgeRange('6-8');if(!ageRange)return;const id='p'+Date.now().toString(36),avatar=V2_AVATARS[ps.length%V2_AVATARS.length];ps.push({id,name,avatar,ageRange,createdAt:Date.now()});saveProfiles(ps);localStorage.setItem(V2_ACTIVE_KEY,id);location.reload()}
function editProfileAge(id){requestParentAccess(()=>{const ps=loadProfiles(),p=ps.find(x=>x.id===id);if(!p)return;const ageRange=chooseAgeRange(p.ageRange||'6-8');if(!ageRange)return;p.ageRange=ageRange;saveProfiles(ps);if(id===activeProfileId)pset('englishAge',ageRange);renderProfileManager();renderParentV2();toast('Faixa etária atualizada 💗')},'Digite o PIN dos responsáveis para alterar a faixa etária.')}
function deleteProfile(id){requestParentAccess(()=>deleteProfileUnlocked(id),'Digite o PIN dos responsáveis para apagar um perfil.')}
function deleteProfileUnlocked(id){const ps=loadProfiles();if(ps.length<=1)return toast('Mantenha pelo menos um perfil.');const target=ps.find(x=>x.id===id);if(!target||!confirm(`Apagar o perfil ${target.name} e todo o progresso dele neste aparelho?`))return;const prefix=`eloProfile:${id}:`;const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(prefix))keys.push(k)}keys.forEach(k=>localStorage.removeItem(k));const next=ps.filter(x=>x.id!==id);saveProfiles(next);if(activeProfileId===id)localStorage.setItem(V2_ACTIVE_KEY,next[0].id);renderProfileManager();toast('Perfil removido.')}
function renderProfileManager(){const p=getActiveProfile();const ageLabel=a=>a==='3-5'?'3–5 anos':a==='9-11'?'9–11 anos':'6–8 anos';const chip=document.getElementById('profileChip');if(chip)chip.innerHTML=`<span>👤</span><b>${escapeHtml(p.name)}</b><small>perfil</small>`;const ps=loadProfiles();const rows=ps.map(x=>`<div class="profileRow ${x.id===activeProfileId?'on':''}"><button onclick="setActiveProfile('${x.id}')"><span>${x.avatar}</span><div><b>${escapeHtml(x.name)}</b><small>${x.id===activeProfileId?'Perfil atual':'Usar este perfil'} • ${ageLabel(x.ageRange)}</small></div></button><button class="profileDelete" onclick="editProfileAge('${x.id}')" aria-label="Alterar faixa etária">🎂</button><button class="profileDelete" onclick="deleteProfile('${x.id}')" ${ps.length<=1?'disabled':''}>🗑️</button></div>`).join('');const box=document.getElementById('profileList');if(box)box.innerHTML=rows+`<button class="btn secondary full" onclick="createProfile()">＋ Criar novo perfil</button>`;const top=document.getElementById('profileListTop');if(top)top.innerHTML=rows}
function currentNavKey(){return document.querySelector('.navbtn.active')?.dataset.nav||'home'}
function openProfileChooser(fromHistory=false){document.getElementById('profileModal')?.classList.remove('hidden');document.body.style.overflow='hidden';renderProfileManager();if(!fromHistory)pushAppState({eloApp:true,type:'profile',base:appStateForPanel(currentPanelId(),currentNavKey())})}
function closeProfileChooser(){if(history.state?.eloApp&&history.state.type==='profile')return history.back();document.getElementById('profileModal')?.classList.add('hidden');document.body.style.overflow=''}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

const A11Y_KEY='eloAccessibilityV2';
function getA11y(){try{return Object.assign({large:false,contrast:false,reduce:false,big:false,speech:true},JSON.parse(localStorage.getItem(A11Y_KEY)||'{}'))}catch(_){return{large:false,contrast:false,reduce:false,big:false,speech:true}}}
function applyA11y(){const a=getA11y(),b=document.body;if(!b)return;b.classList.toggle('a11y-large',!!a.large);b.classList.toggle('a11y-contrast',!!a.contrast);b.classList.toggle('a11y-reduce',!!a.reduce);b.classList.toggle('a11y-big',!!a.big);document.querySelectorAll('[data-a11y]').forEach(el=>{const k=el.dataset.a11y;if(el.type==='checkbox')el.checked=!!a[k]});const sb=document.getElementById('speechBtn');if(sb)sb.textContent=a.speech?'🔊':'🔇'}
function setA11y(k,v){const a=getA11y();a[k]=!!v;localStorage.setItem(A11Y_KEY,JSON.stringify(a));applyA11y();toast('Preferência atualizada 💗')}
function toggleSpeech(){const a=getA11y();a.speech=!a.speech;localStorage.setItem(A11Y_KEY,JSON.stringify(a));if(!a.speech&&'speechSynthesis'in window)speechSynthesis.cancel();applyA11y();toast(a.speech?'Leitura em voz ligada 🔊':'Leitura em voz desligada 🔇')}
function speakText(txt){if(!getA11y().speech||!('speechSynthesis'in window))return toast('Leitura em voz está desligada.');speechSynthesis.cancel();const spoken=String(txt||'').replace(/\bElo\b/g,'Elô').replace(/\s+/g,' ').trim();const u=new SpeechSynthesisUtterance(spoken);u.lang='pt-BR';u.rate=.95;u.pitch=1.05;speechSynthesis.speak(u)}
function speakYoungPanelIntro(id){
 const p=getActiveProfile();if((p?.ageRange||'6-8')!=='3-5'||!getA11y().speech)return;
 const key='eloYoungIntro:'+id;if(sessionStorage.getItem(key)==='1')return;
 const lines={watchPanel:'Aqui você pode assistir aos vídeos da Elo. Para sair do aplicativo, um responsável precisa autorizar.',playPanel:'Escolha um jogo e vamos brincar!',learnPanel:'Vamos aprender brincando. Toque nas atividades e escute as instruções.',createPanel:'Escolha um desenho ou uma atividade para criar.',roomPanel:'Este é o meu quarto! Toque nos móveis e objetos para brincar comigo.',wardrobePanel:'Vamos escolher meu cabelo, roupa e acessórios.',storiesPanel:'Escolha uma história. Eu posso ler as páginas para você.',familyPanel:'Chame alguém da família e escolham uma brincadeira para fazer juntos.'};
 const msg=lines[id];if(!msg)return;sessionStorage.setItem(key,'1');setTimeout(()=>speakText(msg),260);
}

function readCurrentScreen(){const panel=document.querySelector('.panel.active');if(!panel)return;if(panel.id==='readerPanel')return readStoryPage();const txt=[...panel.querySelectorAll('h1,h2,h3,p,.muted,.quiz-q')].filter(x=>x.offsetParent!==null).map(x=>x.textContent.trim()).filter(Boolean).slice(0,18).join('. ');speakText(txt||'Tela atual do Dia a Dia da Elo.')}

const LIMIT_KEY='eloDailyLimitV2';
function dayKey(){const d=new Date();return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`}
function usageKey(){return `usage-${dayKey()}`}
function getTodayUsage(){return Number(pget(usageKey())||0)}
function setDailyLimit(min){localStorage.setItem(LIMIT_KEY,String(Number(min)||0));renderParentV2();toast(min?`Limite suave: ${min} minutos por dia`:'Lembrete de tempo desativado')}
function getActivityStats(){try{return JSON.parse(pget('activityStatsV1')||'{}')}catch(_){return{}}}
function trackActivity(name){const s=getActivityStats();s[name]=Number(s[name]||0)+1;pset('activityStatsV1',JSON.stringify(s))}
function getLast7Usage(){let total=0;for(let i=0;i<7;i++){const d=new Date();d.setDate(d.getDate()-i);const k=`usage-${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;total+=Number(pget(k)||0)}return total}
function renderParentProgress(){const box=document.getElementById('parentProgressDashboard');if(!box)return;const p=getActiveProfile(),age=p.ageRange||'6-8',stats=getActivityStats(),entries=Object.entries(stats).sort((a,b)=>b[1]-a[1]);const names={games:'Jogos',rpg:'RPG',stories:'Histórias',english:'Inglês',school:'Escolinha',coloring:'Criar'};const top=entries[0]?`${names[entries[0][0]]||entries[0][0]} (${entries[0][1]}x)`:'Ainda sem dados';const oldAge=typeof englishAge!=='undefined'?englishAge:null;let eng=0;try{eng=englishOverallPercent(age)}catch(_){eng=0}box.innerHTML=`<div class="parentProgressGrid"><div><strong>${stars}</strong><span>estrelas</span></div><div><strong>${readStories.length}</strong><span>histórias</span></div><div><strong>${eng}%</strong><span>inglês ${age.replace('-', '–')}</span></div><div><strong>${getLast7Usage()} min</strong><span>últimos 7 dias</span></div></div><p class="muted" style="margin:10px 0 0">Atividade mais aberta: <b>${escapeHtml(top)}</b>. Tudo é calculado somente neste aparelho.</p>`}
function renderParentV2(){const sel=document.getElementById('dailyLimitSelect');if(sel)sel.value=localStorage.getItem(LIMIT_KEY)||'0';const u=document.getElementById('usageToday');if(u)u.textContent=`${getTodayUsage()} min`;applyA11y();renderProfileManager();renderParentProgress()}
setInterval(()=>{if(document.visibilityState!=='visible')return;const v=getTodayUsage()+1;pset(usageKey(),v);const limit=Number(localStorage.getItem(LIMIT_KEY)||0);if(limit&&v>=limit&&pget(`restWarn-${dayKey()}`)!=='1'){pset(`restWarn-${dayKey()}`,'1');document.getElementById('restOverlay')?.classList.remove('hidden')}renderParentV2()},60000);
function closeRestOverlay(){document.getElementById('restOverlay')?.classList.add('hidden')}

let tutorialSteps=[],tutorialIndex=0,tutorialKey='';
function showTutorialOnce(key,title,steps){if(pget(`tutorial-${key}`)==='1')return;tutorialKey=key;tutorialSteps=steps;tutorialIndex=0;const ov=document.getElementById('tutorialOverlay');if(!ov)return;document.getElementById('tutorialTitle').textContent=title;ov.classList.remove('hidden');document.body.style.overflow='hidden';renderTutorialStep()}
function renderTutorialStep(){const s=tutorialSteps[tutorialIndex]||'';document.getElementById('tutorialText').textContent=s;document.getElementById('tutorialCount').textContent=`${tutorialIndex+1}/${tutorialSteps.length}`;document.getElementById('tutorialNext').textContent=tutorialIndex===tutorialSteps.length-1?'Entendi!':'Próximo'}
function tutorialNext(){if(tutorialIndex<tutorialSteps.length-1){tutorialIndex++;renderTutorialStep();return}pSetTutorialDone()}
function pSetTutorialDone(){if(tutorialKey)pset(`tutorial-${tutorialKey}`,'1');document.getElementById('tutorialOverlay')?.classList.add('hidden');document.body.style.overflow='';tutorialKey=''}
function tutorialSpeak(){speakText(document.getElementById('tutorialText')?.textContent||'')}

function exportProfileBackup(){const prefix=`eloProfile:${activeProfileId}:`,data={version:2,profile:getActiveProfile(),progress:{}};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(prefix))data.progress[k.slice(prefix.length)]=localStorage.getItem(k)}const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`dia-a-dia-da-elo-${getActiveProfile().name.replace(/[^a-z0-9_-]/gi,'_')}-backup.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Backup criado 💾')}
let backupImportMode='replace';
function triggerImportBackup(mode='replace'){backupImportMode=mode;document.getElementById('backupInput')?.click()}
async function importProfileBackup(input){const f=input.files?.[0];if(!f)return;try{const d=JSON.parse(await f.text());if(!d||d.version!==2||!d.progress)throw new Error('invalid');if(backupImportMode==='new'){const ps=loadProfiles();if(ps.length>=4)return toast('Máximo de 4 perfis neste aparelho.');const id='p'+Date.now().toString(36),name=((d.profile?.name||'Perfil restaurado')+'').slice(0,18),avatar=d.profile?.avatar||V2_AVATARS[ps.length%V2_AVATARS.length],ageRange=d.profile?.ageRange||'6-8';ps.push({id,name,avatar,ageRange,createdAt:Date.now()});saveProfiles(ps);for(const [k,v] of Object.entries(d.progress))localStorage.setItem(`eloProfile:${id}:${k}`,v);localStorage.setItem(V2_ACTIVE_KEY,id);toast('Novo perfil restaurado. Reiniciando…');setTimeout(()=>location.reload(),650);return}if(!confirm('Restaurar este backup no perfil atual? O progresso atual deste perfil será apagado e substituído pelo backup.'))return;const prefix=`eloProfile:${activeProfileId}:`,keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(prefix))keys.push(k)}keys.forEach(k=>localStorage.removeItem(k));for(const [k,v] of Object.entries(d.progress))pset(k,v);toast('Backup restaurado. Reiniciando…');setTimeout(()=>location.reload(),650)}catch(_){toast('Arquivo de backup inválido.')}finally{input.value='';backupImportMode='replace'}}
// ===== fim v2.0 =====

const CHANNEL_URL='https://www.youtube.com/@diaadiadaelo';
const SUBSCRIBE_URL='https://www.youtube.com/@diaadiadaelo?sub_confirmation=1';
const INSTAGRAM_URL='https://www.instagram.com/elo_verissimo';
const MEMBER_URL='https://www.youtube.com/channel/UCBPBaYweoBPjr8XlfOz1dwQ/join';
const PLAYLISTS=[
 {id:'PLhOZycBHbEs6cNunzaW8lPEsXR46fBmq4',title:'Escolinha da Elo | Aprenda Brincando',icon:'📚'},
 {id:'PLhOZycBHbEs48-Z1X_bN6lvUpw4Rosz2I',title:'Ache o Personagem Escondido',icon:'🔎'},
 {id:'PLhOZycBHbEs5VT6AAr2Xiv_teqn03Lwsg',title:'Maratona da Elo | Todos os Vídeos',icon:'🎬'},
 {id:'PLhOZycBHbEs6C_t7GSPeVEEl5aO7dd8gH',title:'Shows, Eventos e Personagens da Elo',icon:'🎭'},
 {id:'PLhOZycBHbEs5D4-Wqa3RNgAZYxDRZqP4i',title:'Momentos que Marcaram a História da Elo',icon:'🎉'},
 {id:'PLhOZycBHbEs4EQl6kh96zvbpq9N_Ybxbm',title:'Momentos na Escola e Apresentações da Elo',icon:'🍎'},
 {id:'PLhOZycBHbEs7Zo4Flf2SmadR9MsC4yOYO',title:'Aventuras e Passeios da Elo',icon:'🌎'},
 {id:'PLhOZycBHbEs4LjNfBDJCjhe1E_M7K1oSq',title:'Peixes da Elo',icon:'🐠'},
 {id:'PLhOZycBHbEs64afG13roQP2ZnzPx5fXd-',title:'Natal da Elo',icon:'🎄'},
 {id:'PLhOZycBHbEs5vV3X_PACKBO-irNlLhWIF',title:'Escolinha, Brincadeiras e Desafios da Elo',icon:'🎮'},
 {id:'PLhOZycBHbEs7JROD9ymRS9LreZ4MBz0wV',title:'Lives e Bate-papo',icon:'🔴'},
 {id:'PLhOZycBHbEs5yoHE1PgIDLfn08_7rd86u',title:'Shorts Divertidos da Elo',icon:'⚡'},
 {id:'PLhOZycBHbEs6Afo_8He5MhGlLcd9vXjRh',title:'Cozinha da Elo | Receitas e Diversão',icon:'🍳'}
];
const STORIES=[
 {id:'story1',title:'A Mochila Desaparecida',summary:'Organização e responsabilidade.',moral:'Guardar cada coisa no seu lugar.',pages:10},
 {id:'story2',title:'O Guarda-Chuva Rosa',summary:'Gentileza que transforma o dia.',moral:'Gentileza também é uma aventura.',pages:10},
 {id:'story3',title:'A Sementinha Misteriosa',summary:'Paciência, cuidado e descobertas.',moral:'Com amor e paciência, pequenas sementes viram grandes belezas.',pages:10},
 {id:'story4',title:'Elo e o Passarinho Perdido',summary:'Empatia e respeito aos animais.',moral:'Ajudar também é saber dar espaço.',pages:10}
];
const STORY_PAGE_TEXTS={
 story1:[
  'As Aventuras da Elo. A Mochila Desaparecida.',
  'Bom dia, Elo! Está na hora de acordar para ir à escola!',
  'Bom dia, papai! Já estou acordando!',
  'Ué... Cadê minha mochila?',
  'Calma, Elo. Vamos procurar juntos! Elo respondeu: Vamos!',
  'Não está aqui...',
  'Também não está aqui...',
  'Será que ficou lá fora? Vamos ver!',
  'Papai... Acho que encontrei!',
  'Agora posso ir para a escola! Que bom que encontramos! Lição da Elo: quando guardamos nossas coisas sempre no mesmo lugar, fica muito mais fácil encontrá-las quando precisamos.'
 ],
 story2:[
  'O Guarda-Chuva Rosa. Em uma manhã chuvosa, a Elo estava pronta para ir à escola quando encontrou um lindo guarda-chuva rosa perto da porta de casa.',
  'Quando abriu o guarda-chuva, pequenas estrelinhas brilhantes apareceram ao seu redor. Tudo parecia um pouco mais colorido e mágico.',
  'A Elo saiu de casa com o seu guarda-chuva rosa e foi caminhando pela rua. Ela adorava ver as gotinhas dançando no chão.',
  'A Elo abriu o seu guarda-chuva e continuou caminhando, pulando nas poças d’água e rindo sem parar. A manhã chuvosa ficou ainda mais divertida!',
  'A Elo pulava nas poças, girava o guarda-chuva e ria sem parar. Era como se a chuva tivesse trazido um dia cheio de magia só para ela!',
  'A Elo olhou para o céu e viu um arco-íris lindo aparecendo entre as nuvens. Ela sorriu e pensou: Que dia especial! A chuva pode ser mágica!',
  'A Elo pulou nas poças, fez cócegas na chuva e correu feliz pelo parque. Cada gotinha era como um lembrete de que a vida fica mais bonita quando a gente sorri.',
  'De repente, Elo encontrou uma senhora que parecia procurar alguma coisa. Ela estava um pouco preocupada e olhava para todos os lados. Você perdeu um guarda-chuva? perguntou Elo.',
  'Era dela! Elo entregou o guarda-chuva, e a senhora abriu um grande sorriso. Muito obrigada! disse ela. Elo ficou feliz por ter ajudado.',
  'Naquele dia, Elo descobriu que fazer o que é certo deixa o mundo um pouquinho mais bonito. Gentileza também é uma grande aventura!'
 ],
 story3:[
  'As Aventuras da Elo. A Sementinha Misteriosa.',
  'Elo estava brincando no quintal quando viu algo pequeno brilhando no chão. Ela se aproximou e encontrou uma sementinha!',
  'Ela pegou a sementinha na mão e ficou pensativa. O que será que vai nascer? pensou Elo.',
  'Elo decidiu plantar a sementinha em um vasinho com muito carinho. Vamos ver o que vai nascer!',
  'Elo cuidou da sementinha com muito carinho. Ela regou todos os dias, com amor e atenção. Com cuidado, tudo pode crescer!',
  'No outro dia, Elo correu para olhar sua sementinha... Mas ainda não tinha nascido nada. Elo ficou um pouquinho triste.',
  'Depois de alguns dias, Elo viu um pequenininho brotinho saindo da terra! Elo ficou muito feliz!',
  'Elo continuou cuidando todos os dias com muito carinho e atenção. O brotinho foi crescendo mais e mais!',
  'Até que um dia... Nasceu uma linda flor colorida! Elo ficou encantada com a surpresa! Toda a espera valeu a pena!',
  'Elo aprendeu que, com amor, paciência e cuidado, pequenas sementes podem se transformar em grandes belezas! E assim, Elo e sua flor viveram muitas aventuras juntas!'
 ],
 story4:[
  'Elo e o Passarinho Perdido.',
  'Elo estava brincando no quintal quando ouviu um Piu! Piu! vindo perto das flores. Ela foi investigar para saber o que era.',
  'Elo encontrou um pequeno passarinho no chão. Ele parecia assustado e não conseguia voar. Será que ele está perdido? pensou Elo.',
  'Elo olhou com cuidado e percebeu outros passarinhos voando nas árvores. Talvez a família dele esteja procurando por ele! pensou Elo.',
  'Elo se afastou um pouquinho e ficou bem quietinha para não assustá-lo. O passarinho olhou para ela e fez: Piu! Piu! novamente.',
  'De repente, outro passarinho apareceu em um galho próximo. Elo percebeu a aproximação e ficou animada: Olha! Acho que vieram procurar você!',
  'O passarinho conseguiu subir para um galho baixo. Elo observou tudo com alegria, mantendo distância para não assustar. Ela sabia que estava fazendo a coisa certa.',
  'O passarinho foi para o ninho, onde sua mamãe o esperava com carinho. Ele deu pulinhos e contou tudo o que viu, sabendo que sempre teria um lugar seguro para voltar. Elo sorriu, feliz por ter presenciado aquele momento especial!',
  'Os passarinhos voam juntos pelo céu. Elo acena sorrindo: Tchau, amiguinho!',
  'Moral da história: Elo aprendeu que ajudar também significa saber respeitar os animais e dar espaço quando eles precisam.'
 ]
};
function readStoryPage(){const s=STORIES[currentStory];if(!s)return;const pages=STORY_PAGE_TEXTS[s.id]||[];const txt=pages[currentPage]||`${s.title}. Página ${currentPage+1}.`;speakText(txt)}

let stars=Number(pget('eloStars')||0),currentStory=0,currentPage=0;
let favorites=JSON.parse(pget('eloFavStories')||'[]');
let readStories=JSON.parse(pget('eloReadStories')||'[]');
const starCount=document.getElementById('starCount');

function renderStars(){starCount.textContent=stars;renderBadges()}
function addStars(n=1,msg='Você ganhou uma estrelinha! ⭐'){
  stars+=n;
  pset('eloStars',stars);
  renderStars();
  if(typeof triggerStarConfetti==='function') triggerStarConfetti();
  toast(msg);
}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),1900)}
let appRestoringHistory=false,appExitArmed=false,appExitFallback=null;
function currentPanelId(){return document.querySelector('.panel.active')?.id||'homePanel'}
function appStateForPanel(id,nav){return {eloApp:true,type:id==='homePanel'?'home':'panel',id,nav}}
function pushAppState(state){if(appRestoringHistory)return;const cur=history.state||{};if(cur.eloApp&&cur.type===state.type&&cur.id===state.id)return;history.pushState(state,'')}
function openPanel(id,nav,fromHistory=false){const previous=currentPanelId();if(previous==='parentsPanel'&&id!=='parentsPanel')lockParentAccess();document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',b.dataset.nav===nav));window.scrollTo({top:0,behavior:'smooth'});if(id==='storiesPanel')renderLibrary();if(id==='parentsPanel'||id==='achievementsPanel')renderBadges();if(id==='parentsPanel')renderParentV2();if(id==='achievementsPanel'){renderV2Album();renderEnglishAlbum()}if(id==='learnPanel'){renderEnglishHomeProgress();if(typeof selectSchoolTrack==='function')selectSchoolTrack('letters');}if(id==='englishPanel')renderEnglishSchool();if(id==='playPanel'){clearInterval(findTimer);clearTimeout(tapTimer);clearInterval(chaseInterval);trailStop()}if(id==='createPanel'){renderColoringGallery();renderPalette();if(typeof initFreeDrawCanvas==='function')setTimeout(initFreeDrawCanvas,60);}if(!fromHistory)speakYoungPanelIntro(id);if(!fromHistory)pushAppState(appStateForPanel(id,nav))}
function exitDialogOpen(){return !document.getElementById('exitConfirm')?.classList.contains('hidden')}
function profileChooserOpen(){return !document.getElementById('profileModal')?.classList.contains('hidden')}
function isAnyModalOpen(){
  const ids = ['gameModal', 'coloringModal', 'rpgOverlay', 'cinemaPlayerModal', 'starShopModal', 'eloHubModal', 'modelStudioModal', 'rewardVideoOverlay', 'profileModal', 'exitConfirm'];
  return ids.some(id => {
    const el = document.getElementById(id);
    return el && !el.classList.contains('hidden');
  });
}
function mainMenuVisible(){
  return currentPanelId() === 'homePanel' && !isAnyModalOpen();
}
function appBack(){
  if(exitDialogOpen()) return cancelAppExit();
  if(!document.getElementById('rewardVideoOverlay')?.classList.contains('hidden')){ document.getElementById('rewardVideoOverlay').classList.add('hidden'); return; }
  if(!document.getElementById('starShopModal')?.classList.contains('hidden')){ closeStarShop(); return; }
  if(!document.getElementById('modelStudioModal')?.classList.contains('hidden')){ closeModelStudio(); return; }
  if(!document.getElementById('eloHubModal')?.classList.contains('hidden')){ closeEloHubModal(); return; }
  if(!document.getElementById('cinemaPlayerModal')?.classList.contains('hidden')) return closeCinemaPlayer();
  if(profileChooserOpen()) return closeProfileChooser();
  if(mainMenuVisible()) return showExitConfirm();
  history.back();
}
function showExitConfirm(){document.getElementById('exitConfirm')?.classList.remove('hidden');document.body.style.overflow='hidden'}
function cancelAppExit(){document.getElementById('exitConfirm')?.classList.add('hidden');document.body.style.overflow=''}
function confirmAppExit(){appExitArmed=true;document.getElementById('exitConfirm')?.classList.add('hidden');document.body.style.overflow='';clearTimeout(appExitFallback);history.back();appExitFallback=setTimeout(()=>{try{window.close()}catch(_){/* navegadores podem ignorar */}},900)}
function setupAppHistory(){if(history.state?.eloGuard||history.state?.eloApp)return;history.replaceState({eloGuard:true},'');history.pushState({eloApp:true,type:'home',id:'homePanel',nav:'home'},'')}
function restoreAppHistoryState(s){appRestoringHistory=true;try{document.getElementById('profileModal')?.classList.add('hidden');document.getElementById('gameModal')?.classList.add('hidden');document.getElementById('coloringModal')?.classList.add('hidden');document.getElementById('rpgOverlay')?.classList.add('hidden');closeCinemaPlayer();if(s?.type!=='rpg'){const rf=document.getElementById('rpgFrame');if(rf)rf.src='about:blank'}document.body.style.overflow='';clearInterval(findTimer);clearTimeout(tapTimer);clearInterval(chaseInterval);trailStop();if(!s||s.type==='home')openPanel('homePanel','home',true);else if(s.type==='panel')openPanel(s.id||'homePanel',s.nav||'home',true);else if(s.type==='game'){openPanel('playPanel','play',true);openGame(s.id,s.title,true)}else if(s.type==='coloring'){openPanel('createPanel','create',true);openColoring(Number(s.index)||0,true)}else if(s.type==='rpg'){openPanel('playPanel','play',true);openRpg(true)}else if(s.type==='profile'){const b=s.base||{type:'home'};if(b.type==='panel')openPanel(b.id||'homePanel',b.nav||'home',true);else openPanel('homePanel','home',true);openProfileChooser(true)}}finally{appRestoringHistory=false}}
window.addEventListener('popstate',e=>{
 if(appExitArmed){if(e.state?.eloApp||e.state?.eloGuard){setTimeout(()=>history.back(),0);return}clearTimeout(appExitFallback);appExitArmed=false;return}
 /* Se o usuário já está visualmente no menu principal, Voltar não reabre telas antigas: pede saída. */
 if(mainMenuVisible()){history.pushState({eloApp:true,type:'home',id:'homePanel',nav:'home'},'');restoreAppHistoryState({type:'home'});showExitConfirm();return}
 if(e.state?.eloGuard){history.pushState({eloApp:true,type:'home',id:'homePanel',nav:'home'},'');restoreAppHistoryState({type:'home'});showExitConfirm();return}
 if(e.state?.eloApp)restoreAppHistoryState(e.state)
});
let parentPendingAction=null,parentPinBuffer='',parentPinMode='verify',parentPinFirst='';
function launchExternal(url){const w=window.open(url,'_blank','noopener,noreferrer');if(!w)location.href=url}
function hasParentPin(){return /^\d{4}$/.test(localStorage.getItem('eloParentPin')||'')}
function parentUnlocked(){const until=Number(sessionStorage.getItem('eloParentUnlockedUntil')||0);if(until>Date.now())return true;sessionStorage.removeItem('eloParentUnlockedUntil');return false}
function lockParentAccess(){sessionStorage.removeItem('eloParentUnlockedUntil')}
function updatePinDots(){document.querySelectorAll('#pinDots .pinDot').forEach((d,i)=>d.classList.toggle('on',i<parentPinBuffer.length))}
function showParentPin(message,mode='verify',action=null){parentPendingAction=action;parentPinMode=mode;parentPinBuffer='';parentPinFirst='';const modal=document.getElementById('parentPinModal');document.getElementById('pinTitle').textContent=mode.startsWith('setup')?'Criar PIN dos responsáveis':'Área dos responsáveis';document.getElementById('pinMessage').textContent=message;updatePinDots();modal.classList.remove('hidden');document.body.style.overflow='hidden'}
function closeParentPin(){document.getElementById('parentPinModal').classList.add('hidden');document.body.style.overflow='';parentPinBuffer='';parentPendingAction=null;updatePinDots()}
function finishParentAccess(){sessionStorage.setItem('eloParentUnlockedUntil',String(Date.now()+5*60*1000));const cb=parentPendingAction;document.getElementById('parentPinModal').classList.add('hidden');document.body.style.overflow='';parentPendingAction=null;parentPinBuffer='';updatePinDots();if(cb)cb()}
function requestParentAccess(action,message='Digite o PIN de 4 dígitos dos responsáveis para continuar.'){if(parentUnlocked())return action();if(!hasParentPin())return showParentPin('Crie um PIN de 4 dígitos. Ele ficará salvo somente neste aparelho.','setup1',action);showParentPin(message,'verify',action)}
function pinKey(n){if(parentPinBuffer.length>=4)return;parentPinBuffer+=n;updatePinDots();if(parentPinBuffer.length===4)processParentPin()}
function pinBackspace(){parentPinBuffer=parentPinBuffer.slice(0,-1);updatePinDots()}
function processParentPin(){if(parentPinBuffer.length!==4)return;const entered=parentPinBuffer;if(parentPinMode==='setup1'){parentPinFirst=entered;parentPinBuffer='';parentPinMode='setup2';document.getElementById('pinMessage').textContent='Repita o novo PIN para confirmar.';updatePinDots();return}if(parentPinMode==='setup2'){if(entered!==parentPinFirst){parentPinBuffer='';parentPinMode='setup1';parentPinFirst='';document.getElementById('pinMessage').textContent='Os PINs não coincidiram. Crie novamente um PIN de 4 dígitos.';updatePinDots();return}localStorage.setItem('eloParentPin',entered);finishParentAccess();toast('PIN dos responsáveis criado 🔐');return}if(parentPinMode==='change1'){parentPinFirst=entered;parentPinBuffer='';parentPinMode='change2';document.getElementById('pinMessage').textContent='Repita o novo PIN para confirmar.';updatePinDots();return}if(parentPinMode==='change2'){if(entered!==parentPinFirst){parentPinBuffer='';parentPinMode='change1';parentPinFirst='';document.getElementById('pinMessage').textContent='Os PINs não coincidiram. Tente novamente.';updatePinDots();return}localStorage.setItem('eloParentPin',entered);document.getElementById('parentPinModal').classList.add('hidden');document.body.style.overflow='';parentPinBuffer='';updatePinDots();toast('PIN alterado com sucesso 🔐');return}if(entered===localStorage.getItem('eloParentPin'))finishParentAccess();else{parentPinBuffer='';document.getElementById('pinMessage').textContent='PIN incorreto. Tente novamente.';updatePinDots()}}
function changeParentPin(){parentPinBuffer='';parentPinFirst='';parentPinMode='change1';parentPendingAction=null;document.getElementById('pinTitle').textContent='Alterar PIN';document.getElementById('pinMessage').textContent='Digite um novo PIN de 4 dígitos.';updatePinDots();document.getElementById('parentPinModal').classList.remove('hidden');document.body.style.overflow='hidden'}
function openExternal(url){requestParentAccess(()=>launchExternal(url),'Digite o PIN dos responsáveis para abrir este link externo.')}
function openParents(){requestParentAccess(()=>openPanel('parentsPanel','parents'))}
function openMemberWithGate(){openExternal(MEMBER_URL)}
function openSubscribe(){openExternal(SUBSCRIBE_URL)}
function openInstagram(){openExternal(INSTAGRAM_URL)}
function openGame(id,title,fromHistory=false){if(!fromHistory)trackActivity('games');clearInterval(findTimer);clearTimeout(tapTimer);clearInterval(chaseInterval);trailStop();document.getElementById('gameModalTitle').textContent=title;document.querySelectorAll('.gameSection').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');document.getElementById('gameModal').classList.remove('hidden');document.body.style.overflow='hidden';if(!fromHistory)pushAppState({eloApp:true,type:'game',id,title});if(id==='findGame')resetFind(true);if(id==='mazeGame')startMaze();if(id==='unicornChaseGame')startChase();if(id==='memoryGame')startMemory();if(id==='puzzleGame')startPuzzle(false);if(id==='tapGameSection')startTapGame();if(id==='trailGame')startTrailGame();if(!fromHistory){const tips={findGame:['Procure a pequena estrela escondida no cenário.','Quanto maior a dificuldade, menor a estrela e menor o tempo.'],mazeGame:['Leve a Elo até o unicórnio.','Use as setas ou deslize o dedo pelo labirinto.'],unicornChaseGame:['Colete os unicórnios e fuja do fantasminha.','Planeje rotas abertas e não fique presa em cantos.'],memoryGame:['Vire duas cartas de cada vez e encontre os pares.'],puzzleGame:['Toque em duas peças para trocar de lugar.','Quando tudo estiver certo, as peças ficam bloqueadas.'],tapGameSection:['Leia o número pedido e toque nele antes do tempo acabar.'],trailGame:['Toque em Pular para desviar e coletar objetos.','No chefão, o Poder funciona o tempo todo. Use quando quiser e aproveite os intervalos sem tiros para atacar com mais segurança.']};showTutorialOnce('game-'+id,title,tips[id]||['Divirta-se e complete o desafio!'])}}
function closeGame(fromHistory=false){if(!fromHistory&&history.state?.type==='game')return history.back();clearInterval(findTimer);clearTimeout(tapTimer);clearInterval(chaseInterval);trailStop();document.getElementById('gameModal').classList.add('hidden');document.body.style.overflow=''}
function openRpg(fromHistory=false){
  if(!fromHistory) trackActivity('rpg');
  trailStop();
  clearInterval(findTimer);
  clearTimeout(tapTimer);
  clearInterval(chaseInterval);
  const frame = document.getElementById('rpgFrame');
  const overlay = document.getElementById('rpgOverlay');
  const wanted = new URL('./rpg.html?v=' + encodeURIComponent(APP_VERSION) + '&profile=' + encodeURIComponent(activeProfileId), location.href).href;
  if(frame) frame.src = wanted;
  if(overlay) overlay.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  if(!fromHistory){
    pushAppState({eloApp: true, type: 'rpg'});
  }
}
window.openRpg = openRpg;
function closeRpg(fromHistory=false){if(!fromHistory&&history.state?.type==='rpg')return history.back();const frame=document.getElementById('rpgFrame');document.getElementById('rpgOverlay').classList.add('hidden');document.body.style.overflow='';if(frame)frame.src='about:blank';renderBadges()}
window.addEventListener('message',e=>{const d=e.data||{};if(d.type==='rpg-close')closeRpg();if(d.type==='rpg-open-youtube')openExternal(CHANNEL_URL);if(d.type==='rpg-medal')renderBadges();if(d.type==='rpg-stars')addStars(Number(d.amount)||1,d.msg||'Você ganhou estrelas no RPG! ⭐');});
function openColoring(i,fromHistory=false){if(!fromHistory)trackActivity('coloring');chooseColoring(i,true);if(!fromHistory)pushAppState({eloApp:true,type:'coloring',index:i})}
function closeColoring(fromHistory=false){if(!fromHistory&&history.state?.type==='coloring')return history.back();document.getElementById('coloringModal').classList.add('hidden');document.body.style.overflow='';if(typeof resetColorZoom==='function')resetColorZoom()}

const daily=[['Missão da Elo','Dê 5 pulinhos e faça uma pose engraçada!'],['Missão das cores','Ache 3 coisas cor-de-rosa perto de você.'],['Missão do sorriso','Faça alguém da família dar risada.'],['Missão movimento','Imite um sapinho por 10 segundos.'],['Missão desenho','Pinte um desenho da Elo e mostre para alguém.'],['Missão gentil','Faça uma gentileza para alguém da família.']];
const d=daily[new Date().getDate()%daily.length];
const dEl = document.getElementById('dailyText');
if(dEl) dEl.textContent = d[1];
const dailyKey='eloDaily'+new Date().toDateString();
const dpEl = document.getElementById('dailyProgress');
if(pget(dailyKey) && dpEl) dpEl.style.width='100%';
function completeDaily(){
  if(pget(dailyKey)) return toast('A missão de hoje já foi concluída 💗');
  pset(dailyKey,'1');
  const p = document.getElementById('dailyProgress');
  if(p) p.style.width='100%';
  addStars(2,'Missão concluída! +2 ⭐');
}

function renderStoryStrip(){const box=document.getElementById('storyStrip');if(!box)return;box.innerHTML=STORIES.map((s,i)=>`<button class="storyCard" onclick="openStory(${i})"><div class="storyThumb" style="background-image:url('assets/stories/${s.id}-cover.webp')"><span class="numBadge">${i+1}</span><span class="heartBadge">${favorites.includes(s.id)?'♥':'♡'}</span></div><div class="storyInfo"><b>${s.title}</b><small>${s.summary}</small></div></button>`).join('')}
function renderLibrary(){const box=document.getElementById('libraryGrid');if(!box)return;box.innerHTML=STORIES.map((s,i)=>`<article class="libCard"><div class="libCover" style="background-image:url('assets/stories/${s.id}-cover.webp')"><span class="numBadge">${i+1}</span><button class="fav ${favorites.includes(s.id)?'on':''}" onclick="toggleFav('${s.id}',event)">${favorites.includes(s.id)?'♥':'♡'}</button></div><div class="libBody"><h3>${s.title}</h3><p>${s.summary}</p><div class="libMeta"><small>📖 ${s.pages} páginas ${readStories.includes(s.id)?'• ✅ lida':''}</small><button class="btn" onclick="openStory(${i})">Ler</button></div></div></article>`).join('')}
function toggleFav(id,e){e.stopPropagation();favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];pset('eloFavStories',JSON.stringify(favorites));renderLibrary();renderStoryStrip();toast(favorites.includes(id)?'Adicionada aos favoritos 💗':'Removida dos favoritos')}
function openStory(i){trackActivity('stories');currentStory=i;currentPage=0;openPanel('readerPanel','stories');renderReader()}
function renderReader(){const s=STORIES[currentStory],page=document.getElementById('storyPage');document.getElementById('readerTitle').textContent=s.title;page.style.backgroundImage=`url('assets/stories/${s.id}.webp')`;page.style.backgroundRepeat='no-repeat';page.style.backgroundSize=`100% ${s.pages*100}%`;page.style.backgroundPosition=`center ${currentPage*(100/(s.pages-1))}%`;document.getElementById('pageCounter').textContent=`Página ${currentPage+1} de ${s.pages}`;document.getElementById('readerMoral').textContent=currentPage===s.pages-1?'✨ '+s.moral:'';document.getElementById('readerDots').innerHTML=Array.from({length:s.pages},(_,i)=>`<i class="dot ${i===currentPage?'on':''}"></i>`).join('');if(currentPage===s.pages-1&&!readStories.includes(s.id)){readStories.push(s.id);pset('eloReadStories',JSON.stringify(readStories));addStars(3,'História concluída! +3 ⭐');renderLibrary()}}
function nextPage(){const s=STORIES[currentStory];if('speechSynthesis'in window)speechSynthesis.cancel();if(currentPage<s.pages-1){currentPage++;renderReader()}else toast('Fim da história 💗')}
function prevPage(){if('speechSynthesis'in window)speechSynthesis.cancel();if(currentPage>0){currentPage--;renderReader()}else toast('Você está na primeira página')}
let touchX=0;
const spEl = document.getElementById('storyPage');
if(spEl){
  spEl.addEventListener('touchstart',e=>touchX=e.changedTouches[0].clientX,{passive:true});
  spEl.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-touchX;if(dx<-45)nextPage();if(dx>45)prevPage()},{passive:true});
}

const CINEMA_SHORTS_PLAYLIST='PLhOZycBHbEs5yoHE1PgIDLfn08_7rd86u';
const CINEMA_LATEST_PLAYLIST='UUBPBaYweoBPjr8XlfOz1dwQ'; // playlist automática de uploads do canal
const CINEMA_PLAYLISTS=[{id:CINEMA_LATEST_PLAYLIST,title:'Mais recente',icon:'🆕'},...[6,9,0,12,11,3,2,4,5,7,8,1,10].map(i=>PLAYLISTS[i])];
const cinemaCatalog={};
let cinemaProbePlayer=null,cinemaYTReady=false,cinemaLoadStarted=false,cinemaQueueIndex=0,cinemaProbeToken=0;
function cinemaIsShorts(p){return p.id===CINEMA_SHORTS_PLAYLIST}
function cinemaIsLatest(p){return p.id===CINEMA_LATEST_PLAYLIST}
function cinemaEsc(s=''){return String(s).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}
function cinemaItemTitle(item){return item?.title||'Carregando título…'}
function cinemaRailSnapshot(){const pos={};document.querySelectorAll('#cinemaShelves .cinemaRail[data-playlist]').forEach(r=>pos[r.dataset.playlist]=r.scrollLeft||0);return pos}
function cinemaRestoreRails(pos={}){requestAnimationFrame(()=>{document.querySelectorAll('#cinemaShelves .cinemaRail[data-playlist]').forEach(r=>{const v=pos[r.dataset.playlist];if(Number.isFinite(v))r.scrollLeft=v})})}
function cinemaRailMove(playlistId,dir){const rail=document.querySelector(`#cinemaShelves .cinemaRail[data-playlist="${CSS.escape(playlistId)}"]`);if(!rail)return;rail.scrollBy({left:dir*Math.max(180,rail.clientWidth*.78),behavior:'smooth'})}
function updateCinemaCardMeta(playlistId,item){if(!item?.id)return;const root=document.getElementById('cinemaShelves');if(!root)return;const card=root.querySelector(`.cinemaVideoCard[data-playlist="${CSS.escape(playlistId)}"][data-video="${CSS.escape(item.id)}"]`);if(!card)return;const title=card.querySelector('b'),img=card.querySelector('img');if(title)title.textContent=cinemaItemTitle(item);if(img)img.alt=cinemaItemTitle(item)}
function renderCinemaShelves(){const root=document.getElementById('cinemaShelves');if(!root)return;const pos=cinemaRailSnapshot();root.innerHTML=CINEMA_PLAYLISTS.map(p=>{const latest=cinemaIsLatest(p),items=cinemaCatalog[p.id],short=cinemaIsShorts(p);let cards='';if(latest){const src=`https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(CINEMA_LATEST_PLAYLIST)}&index=0&controls=0&rel=0&playsinline=1`;cards=`<button class="cinemaLatestDynamic" type="button" onclick="openCinemaPlaylist('${p.id}',false)"><span class="cinemaLatestFrame"><iframe src="${src}" title="Último vídeo do canal Dia a Dia da Elo" tabindex="-1" aria-hidden="true" allow="encrypted-media; picture-in-picture"></iframe><span class="cinemaLatestCover"><i>▶</i></span></span><b>Último vídeo do canal</b><small>Atualiza automaticamente quando um novo vídeo ou Short é publicado.</small></button>`}else if(Array.isArray(items)&&items.length){cards=items.slice(0,12).map((item,i)=>`<button class="cinemaVideoCard ${short?'shortCard':''}" data-playlist="${p.id}" data-video="${item.id}" onclick="openCinemaVideo('${item.id}','${p.id}',${i},${short})"><span class="cinemaThumb"><img loading="lazy" src="https://i.ytimg.com/vi/${item.id}/${short?'hqdefault':'mqdefault'}.jpg" alt="${cinemaEsc(cinemaItemTitle(item))}"><i>▶</i></span><b>${cinemaEsc(cinemaItemTitle(item))}</b><small>${short?'Short':'Vídeo'} • Dia a Dia da Elo</small></button>`).join('')}else if(items===null){cards=`<button class="cinemaVideoCard cinemaPlaylistFallback" onclick="openCinemaPlaylist('${p.id}',${short})"><span class="cinemaFallbackIcon">${p.icon}</span><b>${cinemaEsc(p.title)}</b><small>Abrir esta playlist dentro do app</small></button>`}else{cards=Array.from({length:4},()=>'<div class="cinemaSkeleton"></div>').join('')}const tools=latest?'<div class="cinemaShelfTools"><small>ÚLTIMO DO CANAL</small></div>':`<div class="cinemaShelfTools"><small>${short?'SHORTS':'PLAYLIST'}</small><button type="button" onclick="cinemaRailMove('${p.id}',-1)" aria-label="Vídeos anteriores">‹</button><button type="button" onclick="cinemaRailMove('${p.id}',1)" aria-label="Próximos vídeos">›</button></div>`;return `<section class="cinemaShelf ${short?'shortShelf':''} ${latest?'latestShelf':''}"><div class="cinemaShelfHead"><div><span>${p.icon}</span><h3>${cinemaEsc(p.title)}</h3></div>${tools}</div><div class="cinemaRail" data-playlist="${p.id}">${cards}</div></section>`}).join('');cinemaRestoreRails(pos)}
function loadYouTubeCinemaApi(){if(window.YT&&YT.Player){cinemaYTReady=true;startCinemaProbe();return}if(document.getElementById('youtubeIframeApi'))return;const s=document.createElement('script');s.id='youtubeIframeApi';s.src='https://www.youtube.com/iframe_api';document.head.appendChild(s)}
const previousYTReady=window.onYouTubeIframeAPIReady;
window.onYouTubeIframeAPIReady=function(){cinemaYTReady=true;try{if(typeof previousYTReady==='function')previousYTReady()}catch(_){}startCinemaProbe()};
function startCinemaProbe(){if(!cinemaYTReady||cinemaLoadStarted)return;cinemaLoadStarted=true;cinemaQueueIndex=0;probeNextCinemaPlaylist()}
function finishCinemaProbe(token){if(token!==cinemaProbeToken)return;try{cinemaProbePlayer?.destroy()}catch(_){}cinemaProbePlayer=null;cinemaQueueIndex++;setTimeout(probeNextCinemaPlaylist,120)}
function probeNextCinemaPlaylist(){if(!cinemaYTReady||cinemaQueueIndex>=CINEMA_PLAYLISTS.length)return;const host=document.getElementById('cinemaProbeHost'),p=CINEMA_PLAYLISTS[cinemaQueueIndex];if(!host)return;if(cinemaIsLatest(p)){cinemaCatalog[p.id]='latest';renderCinemaShelves();cinemaQueueIndex++;setTimeout(probeNextCinemaPlaylist,40);return}const token=++cinemaProbeToken;host.innerHTML='<div id="cinemaProbePlayer"></div>';let mode='list',items=[],metaIndex=-1,done=false,listTimer=null,metaTimer=null;
 const fail=()=>{if(done||token!==cinemaProbeToken)return;done=true;clearTimeout(listTimer);clearTimeout(metaTimer);if(cinemaCatalog[p.id]===undefined)cinemaCatalog[p.id]=null;renderCinemaShelves();finishCinemaProbe(token)};
 const nextMeta=()=>{if(done||token!==cinemaProbeToken)return;metaIndex++;if(metaIndex>=items.length){done=true;clearTimeout(metaTimer);renderCinemaShelves();return finishCinemaProbe(token)}mode='meta';clearTimeout(metaTimer);metaTimer=setTimeout(()=>{if(items[metaIndex]&&!items[metaIndex].title)items[metaIndex].title='Vídeo da Elo';updateCinemaCardMeta(p.id,items[metaIndex]);nextMeta()},1700);try{cinemaProbePlayer.cueVideoById(items[metaIndex].id)}catch(_){nextMeta()}};
 try{cinemaProbePlayer=new YT.Player('cinemaProbePlayer',{width:'320',height:'200',playerVars:{controls:0,playsinline:1,rel:0},events:{onReady:e=>{listTimer=setTimeout(fail,6500);try{e.target.cuePlaylist({listType:'playlist',list:p.id,index:0})}catch(_){fail()}},onStateChange:e=>{if(done||token!==cinemaProbeToken||e.data!==YT.PlayerState.CUED)return;if(mode==='list'){clearTimeout(listTimer);let ids=[];try{ids=e.target.getPlaylist()||[]}catch(_){}ids=[...new Set(ids.filter(Boolean))].slice(0,12);if(!ids.length)return fail();items=ids.map(id=>({id,title:''}));cinemaCatalog[p.id]=items;renderCinemaShelves();nextMeta();return}if(mode==='meta'&&metaIndex>=0&&items[metaIndex]){clearTimeout(metaTimer);try{const d=e.target.getVideoData?.();items[metaIndex].title=(d?.title||'').trim()||'Vídeo da Elo'}catch(_){items[metaIndex].title='Vídeo da Elo'}updateCinemaCardMeta(p.id,items[metaIndex]);setTimeout(nextMeta,60)}} ,onError:()=>{if(mode==='meta'&&metaIndex>=0&&items[metaIndex]){clearTimeout(metaTimer);items[metaIndex].title='Vídeo da Elo';updateCinemaCardMeta(p.id,items[metaIndex]);return setTimeout(nextMeta,60)}fail()}}})}catch(_){fail()}}
function initCinema(){renderCinemaShelves();loadYouTubeCinemaApi();setTimeout(()=>{if(!cinemaYTReady){for(const p of CINEMA_PLAYLISTS)if(cinemaCatalog[p.id]===undefined)cinemaCatalog[p.id]=null;renderCinemaShelves()}},7000)}
function openCinemaPlaylist(playlistId,isShort=false){openCinemaVideo('',playlistId,0,isShort)}
function openCinemaVideo(videoId,playlistId,index=0,isShort=false){const modal=document.getElementById('cinemaPlayerModal'),wrap=document.getElementById('cinemaPlayerWrap'),host=document.getElementById('cinemaPlayerHost'),p=CINEMA_PLAYLISTS.find(x=>x.id===playlistId);if(!modal||!wrap||!host)return;modal.classList.remove('hidden');modal.classList.toggle('shortPlayer',!!isShort);document.body.style.overflow='hidden';wrap.classList.toggle('shortMode',!!isShort);document.getElementById('cinemaPlayerCategory').textContent=p?.title||'Cinema da Elo';const item=Array.isArray(cinemaCatalog[playlistId])?cinemaCatalog[playlistId].find(x=>x.id===videoId):null;document.getElementById('cinemaPlayerTitle').textContent=videoId?(item?.title||p?.title||'Vídeo da Elo'):(p?.title||'Playlist da Elo');const origin=location.origin&&location.origin!=='null'?`&origin=${encodeURIComponent(location.origin)}`:'';const src=videoId?`https://www.youtube.com/embed/${encodeURIComponent(videoId)}?playsinline=1&rel=0${origin}`:`https://www.youtube.com/embed?listType=playlist&list=${encodeURIComponent(playlistId)}&index=${Math.max(0,index|0)}&playsinline=1&rel=0${origin}`;host.innerHTML=`<iframe src="${src}" title="${cinemaEsc(item?.title||p?.title||'Vídeo da Elo')}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`}
function closeCinemaPlayer(){const m=document.getElementById('cinemaPlayerModal');m?.classList.add('hidden');m?.classList.remove('shortPlayer');document.body.style.overflow='';const h=document.getElementById('cinemaPlayerHost');if(h)h.innerHTML=''}
function cinemaFullscreen(){const iframe=document.querySelector('#cinemaPlayerHost iframe'),el=iframe||document.getElementById('cinemaPlayerWrap');if(!el)return;const fn=el.requestFullscreen||el.webkitRequestFullscreen||el.msRequestFullscreen;if(fn)fn.call(el)}
window.cinemaRailMove=cinemaRailMove;window.openCinemaVideo=openCinemaVideo;window.openCinemaPlaylist=openCinemaPlaylist;window.closeCinemaPlayer=closeCinemaPlayer;window.cinemaFullscreen=cinemaFullscreen;
function renderPlaylists(){initCinema()}

// Game medals — bronze on easy, silver on medium, gold on hard
const MEDAL_TIERS={easy:{icon:'🥉',label:'Bronze'},medium:{icon:'🥈',label:'Prata'},hard:{icon:'🥇',label:'Ouro'}};
const MEDAL_GAMES=[
 {id:'find',icon:'⭐',name:'Olho de Águia'},
 {id:'maze',icon:'🦄',name:'Exploradora do Labirinto'},
 {id:'chase',icon:'👻',name:'Caçadora de Unicórnios'},
 {id:'memory',icon:'🧠',name:'Mestra da Memória'},
 {id:'puzzle',icon:'🧩',name:'Mestra do Quebra-cabeça'},
 {id:'tap',icon:'🎯',name:'Raio dos Números'},
 {id:'trail',icon:'✨',name:'Heroína da Trilha'}
];
const RPG_MEDALS=[
 {id:'first-step',icon:'👣',name:'Primeiro Passo'},{id:'home-explorer',icon:'🏠',name:'Casa Doce Casa'},{id:'tv-fan',icon:'📺',name:'Fã da Elo'},
 {id:'good-meal',icon:'🍎',name:'Bom Apetite'},{id:'rested',icon:'🌙',name:'Soninho Restaurador'},{id:'first-chat',icon:'💬',name:'Primeira Conversa'},
 {id:'social',icon:'🤝',name:'Amiga da Cidade'},{id:'quest',icon:'📜',name:'Primeira Missão'},{id:'first-win',icon:'✨',name:'Primeira Vitória'},
 {id:'level2',icon:'🌟',name:'Ficando Mais Forte'},{id:'level5',icon:'👑',name:'Heroína Experiente'},{id:'shopper',icon:'🛍️',name:'Primeira Compra'},
 {id:'stylish',icon:'👗',name:'Elo Estilosa'},{id:'explorer',icon:'🗺️',name:'Exploradora'},{id:'fighter10',icon:'👾',name:'Protetora do Reino'},
 {id:'rich',icon:'🪙',name:'Cofrinho Cheio'},{id:'potion',icon:'🧪',name:'Preparada'},{id:'chapter1',icon:'🏆',name:'Guardiã da Primeira Estrela'}
];
function getRpgMedals(){try{return JSON.parse(pget('eloRpgMedals')||'[]')}catch(_){return[]}}
function renderRpgMedals(){const box=document.getElementById('rpgMedals');if(!box)return;const got=getRpgMedals();box.innerHTML=RPG_MEDALS.map(m=>`<div class="rpgMedal ${got.includes(m.id)?'on':''}"><span>${m.icon}</span><strong>${m.name}</strong><small>${got.includes(m.id)?'Conquistada!':'Bloqueada'}</small></div>`).join('')}

function medalKey(game,level){return `eloMedal-${game}-${level}`}
function hasGameMedal(game,level){return pget(medalKey(game,level))==='1'}
function unlockGameMedal(game,level){const first=!hasGameMedal(game,level);if(first)pset(medalKey(game,level),'1');renderBadges();if(first){const gameInfo=MEDAL_GAMES.find(g=>g.id===game),tier=MEDAL_TIERS[level];setTimeout(()=>toast(`${tier.icon} ${tier.label} • ${gameInfo.name}!`),420)}return first}
function renderGameMedals(){const box=document.getElementById('gameMedals');if(!box)return;box.innerHTML=MEDAL_GAMES.map(g=>`<div class="medalGame"><div class="medalGameHead"><span>${g.icon}</span><strong>${g.name}</strong></div><div class="medalTiers">${['easy','medium','hard'].map(level=>{const t=MEDAL_TIERS[level],ok=hasGameMedal(g.id,level);return `<div class="medalTier ${ok?'on':''}"><span>${t.icon}</span><b>${level==='easy'?'Fácil':level==='medium'?'Médio':'Difícil'}</b><small>${ok?'Conquistada':'Bloqueada'}</small></div>`}).join('')}</div></div>`).join('')}

// Find the star
let findLevel='easy',findTimer=null,findLeft=20,findRounds=0;
const FIND={easy:{size:13,time:20,reward:1,count:46},medium:{size:10,time:14,reward:2,count:62},hard:{size:8,time:9,reward:3,count:78}};
const FIND_SCENES=[
 {bg:'linear-gradient(180deg,#7ed6ff 0 48%,#8fe38e 48% 75%,#f6c56b 75%)',objects:['☁️','🌷','🌳','🏠','🦋','🌼','🌻','🍄','🌿','🍎','🐞','🐝','🪁','🎈'],sparkles:['✦','✨','✧','💛','🌟','☀️']},
 {bg:'linear-gradient(180deg,#a7dcff 0 44%,#ffe0ef 44% 65%,#8ed27d 65%)',objects:['☁️','🎈','🪁','🌈','🐥','🌼','🧸','🍭','🍓','🦄','🌸','🧁','🍬','🎀'],sparkles:['✦','✨','✧','💛','🌟','☀️']},
 {bg:'linear-gradient(180deg,#6953a8 0 42%,#8f7bd5 42% 62%,#3f7b67 62%)',objects:['🌙','☁️','🦄','🎀','🍬','🍩','💜','🌸','🎠','🧁','🌳','🏰','🦋'],sparkles:['✦','✨','✧','💛','🌟','⭐']}
];
const findStage=document.getElementById('findStage');
function rand(min,max){return Math.random()*(max-min)+min}
function setFindLevel(level,btn){findLevel=level;document.querySelectorAll('[data-find]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');resetFind(true)}
function buildFindScene(cfg){const scene=FIND_SCENES[Math.floor(Math.random()*FIND_SCENES.length)];findStage.innerHTML='';findStage.style.background=scene.bg;for(let i=0;i<cfg.count;i++){const el=document.createElement('div');el.className='obj';el.textContent=scene.objects[Math.floor(Math.random()*scene.objects.length)];el.style.left=rand(0,94)+'%';el.style.top=rand(1,91)+'%';el.style.fontSize=rand(15,34)+'px';el.style.opacity=String(rand(.72,1));el.style.transform=`rotate(${rand(-24,24)}deg)`;findStage.appendChild(el)}for(let i=0;i<Math.floor(cfg.count*.7);i++){const el=document.createElement('div');el.className='fake';el.textContent=scene.sparkles[Math.floor(Math.random()*scene.sparkles.length)];el.style.left=rand(1,95)+'%';el.style.top=rand(2,92)+'%';el.style.fontSize=rand(Math.max(7,cfg.size-2),cfg.size+7)+'px';findStage.appendChild(el)}const t=document.createElement('button');t.id='target';t.className='target';t.setAttribute('aria-label','estrela escondida');t.innerHTML='<span>⭐</span>';t.style.left=rand(2,94)+'%';t.style.top=rand(2,91)+'%';t.style.setProperty('--star-size',cfg.size+'px');t.style.transform=`rotate(${rand(-30,30)}deg)`;t.dataset.found='0';t.onclick=()=>{if(t.dataset.found==='1')return;t.dataset.found='1';clearInterval(findTimer);findRounds++;document.getElementById('findStatus').textContent='Achou! 🎉';addStars(FIND[findLevel].reward,`Achou! +${FIND[findLevel].reward} ⭐`);unlockGameMedal('find',findLevel);setTimeout(()=>resetFind(),850)};findStage.appendChild(t)}
function resetFind(manual=false){clearInterval(findTimer);const cfg=FIND[findLevel];buildFindScene(cfg);findLeft=cfg.time;document.getElementById('findTime').textContent=findLeft+'s';document.getElementById('findStatus').textContent=manual?'Nova estrela escondida!':'Ache a estrela!';findTimer=setInterval(()=>{findLeft--;document.getElementById('findTime').textContent=findLeft+'s';if(findLeft<=0){clearInterval(findTimer);document.getElementById('findStatus').textContent='O tempo acabou!';setTimeout(()=>resetFind(),900)}},1000)}

// Personagem unificada dos minijogos: sempre clona a Elo atual do guarda-roupa.
function gameEloClone(kind,size){const source=document.getElementById('wardrobeElo');if(!source)return null;const mount=document.createElement('span');mount.className=`gameEloMount ${kind}EloMount`;const doll=source.cloneNode(true);doll.removeAttribute('id');doll.classList.add('gameEloClone');doll.setAttribute('aria-hidden','true');mount.style.setProperty('--game-elo-scale',String(size));mount.appendChild(doll);return mount}
function gameEloScale(mode,size){if(mode==='maze')return size<=9?.16:size<=11?.135:.115;if(mode==='chase')return size<=13?.105:size<=15?.09:.078;return .12}
function syncMiniGameLegend(id){const mount=document.getElementById(id),source=document.getElementById('wardrobeElo');if(!mount||!source)return;const doll=source.cloneNode(true);doll.removeAttribute('id');doll.classList.add('gameEloClone');doll.setAttribute('aria-hidden','true');mount.replaceChildren(doll)}
const gameUnicornImg=new Image();gameUnicornImg.src='assets/game-ui/unicorn.svg';
// Maze game — three difficulty levels
const MAZE_LEVELS={easy:{size:9,reward:2},medium:{size:11,reward:3},hard:{size:13,reward:5}};
let mazeLevel='easy',mazeSize=MAZE_LEVELS.easy.size,mazeMap=[],mazePlayer={x:1,y:1},mazeGoal={x:mazeSize-2,y:mazeSize-2},mazeMoves=0,mazeWon=false,mazeRewarded=false;
function setMazeLevel(level,btn){mazeLevel=level;document.querySelectorAll('[data-maze]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');startMaze()}
function makeMaze(size){const grid=Array.from({length:size},()=>Array(size).fill('#'));const dirs=[[2,0],[-2,0],[0,2],[0,-2]];function dig(x,y){grid[y][x]='.';const order=shuffle(dirs);for(const [dx,dy] of order){const nx=x+dx,ny=y+dy;if(nx<=0||ny<=0||nx>=size-1||ny>=size-1||grid[ny][nx]!=='#')continue;grid[y+dy/2][x+dx/2]='.';dig(nx,ny)}}dig(1,1);grid[1][1]='S';grid[size-2][size-2]='G';return grid}
let mazeBonusStars = [];
function startMaze(){
  const cfg=MAZE_LEVELS[mazeLevel];
  mazeSize=cfg.size;
  mazeMap=makeMaze(mazeSize);
  mazeMoves=0;
  mazeWon=false;
  mazeRewarded=false;
  mazeBonusStars=[];
  let openPaths=[];
  for(let y=0;y<mazeMap.length;y++){
    for(let x=0;x<mazeMap[y].length;x++){
      if(mazeMap[y][x]==='S'){mazePlayer={x,y};mazeMap[y][x]='.'}
      else if(mazeMap[y][x]==='G'){mazeGoal={x,y};mazeMap[y][x]='.'}
      else if(mazeMap[y][x]==='.'){openPaths.push({x,y});}
    }
  }
  // Spawn 3 to 5 bonus stars inside the maze paths
  shuffle(openPaths).slice(0, Math.min(4, Math.floor(mazeSize/3))).forEach(p => mazeBonusStars.push(p));
  document.getElementById('mazeBoard').style.gridTemplateColumns=`repeat(${mazeSize},1fr)`;
  document.getElementById('mazeMoves').textContent='Movimentos: 0';
  document.getElementById('mazeStatus').textContent='Pegue as estrelinhas e encontre o unicórnio!';
  renderMaze();
}
function renderMaze(){const board=document.getElementById('mazeBoard');board.innerHTML='';board.style.setProperty('--maze-size',mazeSize);const scale=gameEloScale('maze',mazeSize);mazeMap.forEach((row,y)=>row.forEach((cell,x)=>{const d=document.createElement('div');const isPlayer=mazePlayer.x===x&&mazePlayer.y===y,isGoal=mazeGoal.x===x&&mazeGoal.y===y,isStar=mazeBonusStars.some(s=>s.x===x&&s.y===y);
d.className='mazeCell '+(cell==='#'?'wall':'path')+(isPlayer?' player':'')+(isGoal?' goal':'')+(isStar?' hasStar':'');
if(isPlayer){const elo=gameEloClone('maze',scale);if(elo)d.appendChild(elo)}
else if(isGoal){d.innerHTML='<img class="gameCreature unicornSprite" src="assets/game-ui/unicorn.svg" alt="Unicórnio">'}
else if(isStar){d.innerHTML='<span class="mazeStarItem" style="font-size:22px;animation:dollHappy .6s infinite alternate;">⭐</span>'}
else if(cell==='#'&&(x+y)%7===0)d.innerHTML='<span class="mazeLeaf">🌿</span>';
board.appendChild(d)}));syncMiniGameLegend('mazeLegendElo')}
function moveMaze(dx,dy){if(!mazeMap.length||mazeWon)return;const nx=mazePlayer.x+dx,ny=mazePlayer.y+dy;if(ny<0||ny>=mazeMap.length||nx<0||nx>=mazeMap[0].length)return;if(mazeMap[ny][nx]==='#'){toast('Parede! Tente outro caminho 😊');return}mazePlayer={x:nx,y:ny};
mazeMoves++;
document.getElementById('mazeMoves').textContent='Movimentos: '+mazeMoves;
// Check star collection
const starIdx = mazeBonusStars.findIndex(s=>s.x===nx&&s.y===ny);
if(starIdx !== -1){
  mazeBonusStars.splice(starIdx, 1);
  addStars(1, 'Estrelinha do labirinto encontrada! +1 ⭐');
}
renderMaze();if(nx===mazeGoal.x&&ny===mazeGoal.y){mazeWon=true;document.getElementById('mazeStatus').textContent='Elo chegou ao unicórnio! 🦄✨';if(!mazeRewarded){mazeRewarded=true;const cfg=MAZE_LEVELS[mazeLevel];addStars(cfg.reward,`Labirinto concluído! +${cfg.reward} ⭐`);unlockGameMedal('maze',mazeLevel)}}else document.getElementById('mazeStatus').textContent='Continue procurando o caminho.'}
let mazeTouchStart=null;
const mazeBoard=document.getElementById('mazeBoard');
mazeBoard.addEventListener('touchstart',e=>{const t=e.changedTouches[0];mazeTouchStart={x:t.clientX,y:t.clientY}},{passive:true});
mazeBoard.addEventListener('touchend',e=>{if(!mazeTouchStart)return;const t=e.changedTouches[0],dx=t.clientX-mazeTouchStart.x,dy=t.clientY-mazeTouchStart.y;mazeTouchStart=null;if(Math.abs(dx)<20&&Math.abs(dy)<20)return;if(Math.abs(dx)>Math.abs(dy))moveMaze(dx>0?1:-1,0);else moveMaze(0,dy>0?1:-1)},{passive:true});


// Caça aos Unicórnios — arena aberta com espaço real para fugir
const CHASE_LEVELS={easy:{size:13,total:4,ghostMs:2200,reward:2,smart:.62,startDelay:2200},medium:{size:15,total:5,ghostMs:1550,reward:3,smart:.82,startDelay:1800},hard:{size:17,total:6,ghostMs:1100,reward:5,smart:1,startDelay:1400}};
let chaseLevel='easy',chaseSize=CHASE_LEVELS.easy.size,chaseTotal=CHASE_LEVELS.easy.total,chaseMap=[],chasePlayer={x:1,y:1},chaseGhost={x:chaseSize-2,y:chaseSize-2},chaseUnicorns=[],chaseInterval=null,chaseWon=false,chaseLost=false,chaseCollected=0;
function setChaseLevel(level,btn){chaseLevel=level;document.querySelectorAll('[data-chase]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');startChase()}
function chaseKey(x,y){return `${x},${y}`}
function makeChaseMap(){const n=chaseSize,grid=Array.from({length:n},(_,y)=>Array.from({length:n},(_,x)=>(x===0||y===0||x===n-1||y===n-1)?'#':'.'));const mid=Math.floor(n/2);const reserved=(x,y)=>x<=2&&y<=2||x>=n-3&&y>=n-3||x===1||y===1||x===n-2||y===n-2||x===mid||y===mid;for(let y=3;y<n-3;y+=4){for(let x=3;x<n-3;x+=4){if(reserved(x,y))continue;const shape=(x+y)%3;if(shape===0){grid[y][x]='#';if(x+1<n-2&&!reserved(x+1,y))grid[y][x+1]='#'}else if(shape===1){grid[y][x]='#';if(y+1<n-2&&!reserved(x,y+1))grid[y+1][x]='#'}else grid[y][x]='#'}}for(let i=0;i<Math.floor(n/3);i++){const x=2+Math.floor(Math.random()*(n-4)),y=2+Math.floor(Math.random()*(n-4));if(!reserved(x,y)&&Math.random()>.35)grid[y][x]='#'}grid[1][1]='.';grid[n-2][n-2]='.';return grid}
function chaseOpenCells(){const cells=[];for(let y=1;y<chaseSize-1;y++)for(let x=1;x<chaseSize-1;x++)if(chaseMap[y][x]==='.')cells.push({x,y});return cells}
function chaseDistance(a,b){return Math.abs(a.x-b.x)+Math.abs(a.y-b.y)}
function startChase(){clearInterval(chaseInterval);const cfg=CHASE_LEVELS[chaseLevel];chaseSize=cfg.size;chaseTotal=cfg.total;chaseMap=makeChaseMap();chasePlayer={x:1,y:1};chaseGhost={x:chaseSize-2,y:chaseSize-2};chaseWon=false;chaseLost=false;chaseCollected=0;let candidates=shuffle(chaseOpenCells().filter(p=>chaseDistance(p,chasePlayer)>Math.max(5,Math.floor(chaseSize/3))&&chaseDistance(p,chaseGhost)>4));chaseUnicorns=[];
for(const c of candidates){
  if(chaseUnicorns.every(u=>chaseDistance(u,c)>3)){
    chaseUnicorns.push(c);
    if(chaseUnicorns.length>=chaseTotal)break;
  }
}
if(chaseUnicorns.length<chaseTotal)chaseUnicorns=candidates.slice(0,chaseTotal);
document.getElementById('chaseBoard').style.gridTemplateColumns=`repeat(${chaseSize},1fr)`;document.getElementById('chaseStatus').textContent='Corra pela arena e pegue os unicórnios!';document.getElementById('chaseCount').innerHTML=`<img class="inlineCreature" src="assets/game-ui/unicorn.svg" alt=""> 0/${chaseTotal}`;renderChase();setTimeout(()=>{if(!chaseWon&&!chaseLost&&!document.getElementById('gameModal').classList.contains('hidden'))chaseInterval=setInterval(moveChaseGhost,cfg.ghostMs)},cfg.startDelay)}
function renderChase(){const board=document.getElementById('chaseBoard');if(!board)return;board.innerHTML='';board.style.setProperty('--chase-size',chaseSize);const scale=gameEloScale('chase',chaseSize),uni=new Set(chaseUnicorns.map(p=>chaseKey(p.x,p.y)));for(let y=0;y<chaseSize;y++){for(let x=0;x<chaseSize;x++){const d=document.createElement('div'),wall=chaseMap[y][x]==='#',player=chasePlayer.x===x&&chasePlayer.y===y,ghost=chaseGhost.x===x&&chaseGhost.y===y,unicorn=uni.has(chaseKey(x,y));d.className='chaseCell '+(wall?'wall':'path')+(player?' player':'')+(ghost?' ghost':'')+(unicorn?' unicorn':'');if(player){const elo=gameEloClone('chase',scale);if(elo)d.appendChild(elo)}else if(ghost)d.innerHTML='<img class="gameCreature ghostSprite" src="assets/game-ui/ghost.svg" alt="Fantasminha">';else if(unicorn){
  d.innerHTML='<img class="gameCreature unicornSprite" src="assets/game-ui/unicorn.svg" alt="Unicórnio">';
}else if(!wall&&(x*7+y*11)%31===0)d.innerHTML='<span class="chaseFlower">🌸</span>';board.appendChild(d)}}syncMiniGameLegend('chaseLegendElo')}
function collectChaseUnicorn(){
  const k = chaseKey(chasePlayer.x, chasePlayer.y), before = chaseUnicorns.length;
  chaseUnicorns = chaseUnicorns.filter(p => chaseKey(p.x, p.y) !== k);
  if(chaseUnicorns.length < before){
    chaseCollected++;
    toast('Unicórnio resgatado! 🦄✨');
    const countEl = document.getElementById('chaseCount');
    if(countEl) countEl.innerHTML = `<img class="inlineCreature" src="assets/game-ui/unicorn.svg" alt=""> ${chaseCollected}/${chaseTotal}`;
    if(chaseCollected >= chaseTotal){
      chaseWon = true;
      clearInterval(chaseInterval);
      const stEl = document.getElementById('chaseStatus');
      if(stEl) stEl.textContent = 'Você pegou todos! 🎉';
      const cfg = CHASE_LEVELS[chaseLevel];
      addStars(cfg.reward, `Todos os unicórnios encontrados! +${cfg.reward} ⭐`);
      unlockGameMedal('chase', chaseLevel);
    }
  }
}
function chaseCaught(){if(chaseWon||chaseLost)return;chaseLost=true;clearInterval(chaseInterval);document.getElementById('chaseStatus').textContent='O fantasminha encontrou a Elo! 👻';toast('Quase! Agora há bastante espaço para fugir — tente outra rota 💗');renderChase()}
function moveChase(dx,dy){if(chaseWon||chaseLost||!chaseMap.length)return;const nx=chasePlayer.x+dx,ny=chasePlayer.y+dy;if(ny<0||ny>=chaseSize||nx<0||nx>=chaseSize||chaseMap[ny][nx]==='#')return;chasePlayer={x:nx,y:ny};collectChaseUnicorn();if(chasePlayer.x===chaseGhost.x&&chasePlayer.y===chaseGhost.y)return chaseCaught();renderChase()}
function chaseNeighbors(pos){return [[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dy])=>({x:pos.x+dx,y:pos.y+dy})).filter(p=>p.x>0&&p.y>0&&p.x<chaseSize-1&&p.y<chaseSize-1&&chaseMap[p.y][p.x]!== '#')}
function chasePathStep(){const q=[chaseGhost],seen=new Set([chaseKey(chaseGhost.x,chaseGhost.y)]),parent=new Map(),dirs=[[1,0],[-1,0],[0,1],[0,-1]];let found=false;for(let qi=0;qi<q.length&&!found;qi++){const cur=q[qi];for(const [dx,dy] of dirs){const nx=cur.x+dx,ny=cur.y+dy,k=chaseKey(nx,ny);if(nx<0||ny<0||nx>=chaseSize||ny>=chaseSize||chaseMap[ny][nx]==='#'||seen.has(k))continue;seen.add(k);parent.set(k,cur);q.push({x:nx,y:ny});if(nx===chasePlayer.x&&ny===chasePlayer.y){found=true;break}}}if(!found)return chaseGhost;let cur={...chasePlayer};while(true){const p=parent.get(chaseKey(cur.x,cur.y));if(!p)return chaseGhost;if(p.x===chaseGhost.x&&p.y===chaseGhost.y)return cur;cur=p}}
function moveChaseGhost(){if(chaseWon||chaseLost)return;const cfg=CHASE_LEVELS[chaseLevel];let next;if(Math.random()<=cfg.smart)next=chasePathStep();else{const opts=shuffle(chaseNeighbors(chaseGhost)).filter(p=>!(p.x===chasePlayer.x&&p.y===chasePlayer.y));next=opts[0]||chaseGhost}chaseGhost={x:next.x,y:next.y};if(chaseGhost.x===chasePlayer.x&&chaseGhost.y===chasePlayer.y)return chaseCaught();renderChase()}
let chaseTouchStart=null;
const chaseBoard=document.getElementById('chaseBoard');
chaseBoard.addEventListener('touchstart',e=>{const t=e.changedTouches[0];chaseTouchStart={x:t.clientX,y:t.clientY}},{passive:true});
chaseBoard.addEventListener('touchend',e=>{if(!chaseTouchStart)return;const t=e.changedTouches[0],dx=t.clientX-chaseTouchStart.x,dy=t.clientY-chaseTouchStart.y;chaseTouchStart=null;if(Math.abs(dx)<20&&Math.abs(dy)<20)return;if(Math.abs(dx)>Math.abs(dy))moveChase(dx>0?1:-1,0);else moveChase(0,dy>0?1:-1)},{passive:true});
window.addEventListener('keydown',e=>{if(document.getElementById('gameModal').classList.contains('hidden'))return;let move=null;if(e.key==='ArrowUp')move=[0,-1];if(e.key==='ArrowDown')move=[0,1];if(e.key==='ArrowLeft')move=[-1,0];if(e.key==='ArrowRight')move=[1,0];if(!move)return;if(document.getElementById('mazeGame').classList.contains('active'))moveMaze(...move);else if(document.getElementById('unicornChaseGame').classList.contains('active'))moveChase(...move)});


// Memory game — 8 / 16 / 32 cards with illustrated Elo themes
const MEMORY_IMAGES=[
 {src:'assets/memory-cards/card-01.webp',label:'Vídeos'},
 {src:'assets/memory-cards/card-02.webp',label:'Shorts'},
 {src:'assets/memory-cards/card-03.webp',label:'Brincadeiras'},
 {src:'assets/memory-cards/card-04.webp',label:'Culinária'},
 {src:'assets/memory-cards/card-05.webp',label:'Escolinha'},
 {src:'assets/memory-cards/card-06.webp',label:'Médica'},
 {src:'assets/memory-cards/card-07.webp',label:'Viagem'},
 {src:'assets/memory-cards/card-08.webp',label:'Shows'},
 {src:'assets/memory-cards/card-09.webp',label:'Personagens'},
 {src:'assets/memory-cards/card-10.webp',label:'Animais'},
 {src:'assets/memory-cards/card-11.webp',label:'Esportes'},
 {src:'assets/memory-cards/card-12.webp',label:'Unicórnio'},
 {src:'assets/memory-cards/card-13.webp',label:'Pintura'},
 {src:'assets/memory-cards/card-14.webp',label:'Leitura'},
 {src:'assets/memory-cards/card-15.webp',label:'Música'},
 {src:'assets/memory-cards/card-16.webp',label:'Aventuras'}
];
const MEMORY_LEVELS={easy:4,medium:8,hard:16};
let memoryLevel='easy',memoryOpen=[],memoryLock=false,matched=0,memoryMoves=0,memoryTotal=8;
function setMemoryLevel(level,btn){memoryLevel=level;document.querySelectorAll('[data-memory]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');startMemory()}
function startMemory(){const pairs=MEMORY_LEVELS[memoryLevel];const chosen=shuffle(MEMORY_IMAGES).slice(0,pairs).map((x,i)=>({...x,key:'elo'+i}));const cards=shuffle(chosen.flatMap(x=>[x,x]));memoryTotal=cards.length;memoryOpen=[];memoryLock=false;matched=0;memoryMoves=0;const box=document.getElementById('memory');box.className='memory '+memoryLevel;box.style.gridTemplateColumns='repeat(4,1fr)';box.innerHTML='';document.getElementById('memoryStatus').textContent='Encontre os pares!';document.getElementById('memoryMoves').textContent='Jogadas: 0';cards.forEach(card=>{const b=document.createElement('button');b.className='mem';b.dataset.key=card.key;b.dataset.src=card.src;b.setAttribute('aria-label','Carta de memória fechada');b.onclick=()=>flip(b);box.appendChild(b)})}
function showMemImage(b){const d=document.createElement('div');d.className='memPic';d.style.backgroundImage=`url('${b.dataset.src}')`;b.innerHTML='';b.appendChild(d)}
function hideMemImage(b){b.innerHTML=''}
function flip(b){if(memoryLock||b.classList.contains('done')||b.classList.contains('open'))return;b.classList.add('open');showMemImage(b);memoryOpen.push(b);if(memoryOpen.length===2){memoryLock=true;memoryMoves++;document.getElementById('memoryMoves').textContent='Jogadas: '+memoryMoves;setTimeout(()=>{const[a,c]=memoryOpen;if(a.dataset.key===c.dataset.key){a.classList.add('done');c.classList.add('done');matched+=2;if(matched===memoryTotal){document.getElementById('memoryStatus').textContent='Você encontrou todos! 🎉';if(memoryLevel==='hard')pset('eloMemoryHardWon','1');addStars(memoryLevel==='hard'?5:memoryLevel==='medium'?3:2,'Memória completa! ⭐');unlockGameMedal('memory',memoryLevel)}}else{a.classList.remove('open');c.classList.remove('open');hideMemImage(a);hideMemImage(c)}memoryOpen=[];memoryLock=false},650)}}

// Puzzle game — tap two pieces to swap them
const PUZZLE_LEVELS={easy:3,medium:4,hard:5};
// 16 artes visualmente únicas (v3.0.3)
const PUZZLE_IMAGES=Array.from({length:16},(_,i)=>i+1).filter(n=>![6,8,14].includes(n)).map(n=>`assets/puzzle/puzzle-${String(n).padStart(2,'0')}.webp`);
let puzzleLevel='easy',puzzleImageIndex=0,puzzleOrder=[],puzzleSelected=-1,puzzleMoves=0,puzzleRewarded=false,puzzleComplete=false;
function setPuzzleLevel(level,btn){puzzleLevel=level;document.querySelectorAll('[data-puzzle]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');startPuzzle(false)}
function renderPuzzleChoices(){const box=document.getElementById('puzzleChoices');if(!box)return;box.innerHTML=PUZZLE_IMAGES.map((src,i)=>`<button class="puzzleChoice ${i===puzzleImageIndex?'on':''}" onclick="choosePuzzleImage(${i})"><img src="${src}" alt="Imagem ${i+1} da Elo"></button>`).join('')}
function choosePuzzleImage(i){puzzleImageIndex=i;startPuzzle(false)}
function makePuzzleOrder(total){let a=Array.from({length:total},(_,i)=>i);do{a=shuffle(a)}while(a.every((v,i)=>v===i));return a}
function startPuzzle(randomPhoto=false){const n=PUZZLE_LEVELS[puzzleLevel];if(randomPhoto)puzzleImageIndex=(puzzleImageIndex+1+Math.floor(Math.random()*(PUZZLE_IMAGES.length-1)))%PUZZLE_IMAGES.length;puzzleOrder=makePuzzleOrder(n*n);puzzleSelected=-1;puzzleMoves=0;puzzleRewarded=false;puzzleComplete=false;const prev=document.getElementById('puzzlePreview');if(prev)prev.src=PUZZLE_IMAGES[puzzleImageIndex];document.getElementById('puzzleStatus').textContent='Monte a imagem!';document.getElementById('puzzleMoves').textContent='Jogadas: 0';document.getElementById('puzzleCompleteNote').classList.add('hidden');renderPuzzleChoices();renderPuzzle()}
function piecePosition(piece,n){const row=Math.floor(piece/n),col=piece%n;const x=n===1?0:(col/(n-1))*100,y=n===1?0:(row/(n-1))*100;return `${x}% ${y}%`}
function renderPuzzle(){const n=PUZZLE_LEVELS[puzzleLevel],board=document.getElementById('puzzleBoard');if(!board)return;board.style.gridTemplateColumns=`repeat(${n},1fr)`;board.classList.toggle('completed',puzzleComplete);board.innerHTML='';puzzleOrder.forEach((piece,pos)=>{const b=document.createElement('button');b.className='puzzlePiece'+(puzzleSelected===pos?' selected':'')+(piece===pos?' correct':'');b.style.backgroundImage=`url('${PUZZLE_IMAGES[puzzleImageIndex]}')`;b.style.backgroundSize=`${n*100}% ${n*100}%`;b.style.backgroundPosition=piecePosition(piece,n);b.setAttribute('aria-label',`Peça ${pos+1}`);b.disabled=puzzleComplete;b.onclick=()=>tapPuzzlePiece(pos);board.appendChild(b)})}
function tapPuzzlePiece(pos){if(puzzleComplete)return;if(puzzleSelected<0){puzzleSelected=pos;document.getElementById('puzzleStatus').textContent='Agora escolha onde colocar essa peça.';renderPuzzle();return}if(puzzleSelected===pos){puzzleSelected=-1;document.getElementById('puzzleStatus').textContent='Escolha uma peça.';renderPuzzle();return}const a=puzzleSelected;[puzzleOrder[a],puzzleOrder[pos]]=[puzzleOrder[pos],puzzleOrder[a]];puzzleSelected=-1;puzzleMoves++;document.getElementById('puzzleMoves').textContent='Jogadas: '+puzzleMoves;const solved=puzzleOrder.every((v,i)=>v===i);if(solved){puzzleComplete=true;renderPuzzle();document.getElementById('puzzleStatus').textContent='Quebra-cabeça completo! 🎉';document.getElementById('puzzleCompleteNote').classList.remove('hidden');if(!puzzleRewarded){puzzleRewarded=true;pset('eloPuzzleWon','1');addStars(puzzleLevel==='hard'?5:puzzleLevel==='medium'?3:2,'Quebra-cabeça completo! ⭐');unlockGameMedal('puzzle',puzzleLevel)}}else{renderPuzzle();document.getElementById('puzzleStatus').textContent='Muito bem! Continue montando.'}}

// Tap the number — 10 correct answers complete each level
const TAP_LEVELS={easy:{start:5000,min:3000,step:100,reward:2},medium:{start:3500,min:1800,step:90,reward:3},hard:{start:2500,min:900,step:80,reward:5}},TAP_GOAL=10;
let tapLevel='easy',tapTarget=1,tapScore=0,tapTimer=null,tapRound=0,tapDelay=TAP_LEVELS.easy.start,tapWon=false;
function setTapLevel(level,btn){tapLevel=level;document.querySelectorAll('[data-tap]').forEach(x=>x.classList.remove('on'));btn.classList.add('on');startTapGame()}
function buildTapRound(){clearTimeout(tapTimer);if(tapWon)return;tapRound++;tapTarget=Math.floor(Math.random()*9)+1;document.getElementById('tapPrompt').textContent=`Toque no número ${tapTarget} antes que ele mude!`;if(getActiveProfile().ageRange==='3-5')setTimeout(()=>speakText(`Toque no número ${tapTarget}`),120);const nums=Array.from({length:9},(_,i)=>i+1).sort(()=>Math.random()-.5);document.getElementById('tapGame').innerHTML=nums.map(n=>`<button class="tapNum" onclick="tapAnswer(${n})">${n}</button>`).join('');const cfg=TAP_LEVELS[tapLevel];tapDelay=Math.max(cfg.min,cfg.start-tapScore*cfg.step);document.getElementById('tapTimeText').textContent=(tapDelay/1000).toFixed(1).replace('.',',')+'s';const bar=document.getElementById('tapTimerBar');bar.style.transition='none';bar.style.transform='scaleX(1)';requestAnimationFrame(()=>requestAnimationFrame(()=>{bar.style.transition=`transform ${tapDelay}ms linear`;bar.style.transform='scaleX(0)'}));tapTimer=setTimeout(()=>{toast('Mudou! Seja mais rápido 😄');buildTapRound()},tapDelay)}
function startTapGame(){clearTimeout(tapTimer);tapScore=0;tapRound=0;tapWon=false;document.getElementById('tapScore').textContent=`Acertos: 0/${TAP_GOAL}`;buildTapRound()}
function tapAnswer(n){if(tapWon)return;if(n===tapTarget){tapScore++;document.getElementById('tapScore').textContent=`Acertos: ${tapScore}/${TAP_GOAL}`;if(tapScore>=TAP_GOAL){tapWon=true;clearTimeout(tapTimer);const bar=document.getElementById('tapTimerBar');bar.style.transition='none';bar.style.transform='scaleX(1)';document.getElementById('tapPrompt').textContent='Desafio concluído! 🎉';document.getElementById('tapGame').innerHTML='';const cfg=TAP_LEVELS[tapLevel];addStars(cfg.reward,`10 acertos! +${cfg.reward} ⭐`);unlockGameMedal('tap',tapLevel);return}if(tapScore%3===0)addStars(1,'Boa sequência! +1 ⭐');else toast('Acertou! 🎯');buildTapRound()}else toast('Ops! Esse não era o número 😊')}



// Elo na Trilha Encantada
const TRAIL_LEVELS={easy:{speed:1.05,jump:18.7,bossHp:6,reward:4,spawnMin:118,spawnVar:52,collectMin:38,collectVar:30,bossAttack:145,bossRest:125,bossShot:66},medium:{speed:1.55,jump:19.1,bossHp:8,reward:5,spawnMin:86,spawnVar:38,collectMin:31,collectVar:26,bossAttack:165,bossRest:105,bossShot:52},hard:{speed:2.05,jump:19.5,bossHp:10,reward:6,spawnMin:64,spawnVar:30,collectMin:25,collectVar:21,bossAttack:185,bossRest:90,bossShot:43}};
let trailLevel='easy',trailAnim=0,trailTick=0,trailCanvas=document.getElementById('trailCanvas'),trailCtx=trailCanvas.getContext('2d');
let trailRunning=false,trailLast=0,trailState=null;
const trailUI={phase:document.getElementById('trailPhase'),lives:document.getElementById('trailLives'),collected:document.getElementById('trailCollected'),score:document.getElementById('trailScore'),status:document.getElementById('trailStatus'),mode:document.getElementById('trailMode'),bossBar:document.getElementById('trailBossBar'),bossFill:document.getElementById('trailBossFill')};
function syncTrailEloClone(){
 const mount=document.getElementById('trailEloMount'),source=document.getElementById('wardrobeElo'),s=trailState;
 if(!mount||!source||!s?.player)return;
 let doll=mount.querySelector('.trailEloClone');
 if(!doll){doll=source.cloneNode(true);doll.removeAttribute('id');doll.classList.add('trailEloClone');doll.setAttribute('aria-hidden','true');mount.replaceChildren(doll)}
 const wanted=[...source.classList].filter(c=>c!=='trailEloClone'&&c!=='trailFacingRight').join(' ');
 const current=[...doll.classList].filter(c=>c!=='trailEloClone'&&c!=='trailFacingRight').join(' ');
 if(current!==wanted)doll.className=wanted+' trailEloClone trailFacingRight';else doll.classList.add('trailFacingRight');
 const ratioX=(trailCanvas.clientWidth||trailCanvas.width)/trailCanvas.width;
 const ratioY=(trailCanvas.clientHeight||trailCanvas.height)/trailCanvas.height;
 const p=s.player;
 const avatarScale=.35*ratioX;
 // O canvas pode ficar mais alto no celular por causa do min-height. X e Y precisam de escalas separadas.
 // O topo da faixa de chão visível é ground+38 no canvas; os pés da Elo são ancorados exatamente ali.
 const footX=(p.x+p.w/2)*ratioX;
 const footY=(p.y+p.h+38)*ratioY;
 doll.style.left=(footX-75*avatarScale)+'px';
 doll.style.top=(footY-303*avatarScale)+'px';
 doll.style.transform=`scale(${avatarScale})`;
 doll.style.opacity=(p.inv>0&&Math.floor(p.inv)%4<2)?'.45':'1';
}

function setTrailLevel(level,btn){trailLevel=level;document.querySelectorAll('[data-trail]').forEach(x=>x.classList.remove('on'));if(btn)btn.classList.add('on');restartTrailRun()}
function baseTrailState(){return {mode:'ready',phase:1,lives:3,score:0,totalCollected:0,nextLifeAt:100,phaseCollected:0,phaseGoal:18,phaseDistance:0,phaseDistanceGoal:2400,bossHp:0,bossMaxHp:0,bossShotCd:0,bossPattern:'attack',bossPatternTimer:0,bossVulnerable:false,gameOver:false,messageShown:false,hasShield:false,magnetTimer:0,isFlying:false,flyStamina:100,player:{x:110,y:0,vy:0,w:58,h:76,jumpBuffer:0,inv:0},ground:390,worldSpeed:TRAIL_LEVELS[trailLevel].speed,spawnTimer:0,collectTimer:0,entities:[],projectiles:[],effects:[],bossProjectiles:[],boss:null,medalGiven:false}};
function restartTrailRun(){trailStop();trailState=baseTrailState();prepareTrailPhase();drawTrailScene(0);syncTrailHud();trailUI.status.textContent='Fase 1 • A aventura recomeçou!'}
function startTrailGame(){if(!trailState||trailState.lives<=0||trailState.gameOver)restartTrailRun();trailStop();trailState.worldSpeed=TRAIL_LEVELS[trailLevel].speed+(trailState.phase-1)*0.06;trailRunning=true;trailLast=performance.now();trailUI.status.textContent=isTrailBossPhase()?`Fase ${trailState.phase} • Desvie dos ataques!`:`Fase ${trailState.phase} • Corra com a Elo e pegue os objetos brilhantes!`;trailAnim=requestAnimationFrame(trailLoop)}
function trailStop(){trailRunning=false;if(trailAnim)cancelAnimationFrame(trailAnim);trailAnim=0}
function trailJump(){if(!trailState||!trailRunning)return;const p=trailState.player;const onGround=p.y>=trailState.ground-p.h-4;if(onGround){p.y=trailState.ground-p.h-1;p.vy=-TRAIL_LEVELS[trailLevel].jump;p.jumpBuffer=0}else{p.jumpBuffer=11}}
function trailMagic(){if(!trailState||!trailRunning)return;if(trailState.mode!=='boss'||!trailState.boss||trailState.bossHp<=0){toast('Guarde o poder para o chefão! 💖');return}const p=trailState.player;trailState.projectiles.push({x:p.x+p.w-6,y:p.y+28,vx:11.5,size:20,alive:true});}
function trailFlyStart(){if(!trailState||!trailRunning)return;if(trailState.flyStamina>8){trailState.isFlying=true;trailState.effects.push({x:trailState.player.x,y:trailState.player.y+10,text:'🦄✨',t:36});if(typeof playCuteSfx==='function')playCuteSfx('coin');toast('Voando com a amiga Unicórnia! 🦄🌈');}else{toast('Unicórnia descansando energia de voo! 🦄');}}
function trailFlyEnd(){if(!trailState)return;trailState.isFlying=false;}
window.trailFlyStart=trailFlyStart;window.trailFlyEnd=trailFlyEnd;
function isTrailBossPhase(){return trailState&&trailState.phase%5===0}
function prepareTrailPhase(){if(!trailState)return;trailState.entities=[];trailState.projectiles=[];trailState.effects=[];trailState.bossProjectiles=[];trailState.phaseCollected=0;trailState.phaseDistance=0;const pacing=TRAIL_LEVELS[trailLevel];trailState.spawnTimer=pacing.spawnMin+35;trailState.collectTimer=pacing.collectMin;trailState.player.y=trailState.ground-trailState.player.h;trailState.player.vy=0;trailState.player.inv=0;trailState.mode=isTrailBossPhase()?'boss':'run';trailState.phaseGoal=(isTrailBossPhase()?0:16+trailState.phase*2);trailState.phaseDistanceGoal=2400+trailState.phase*220;trailState.worldSpeed=TRAIL_LEVELS[trailLevel].speed+(trailState.phase-1)*0.06;trailState.boss=null;trailState.bossHp=0;trailState.bossMaxHp=0;trailState.bossVulnerable=false;trailState.bossPattern='attack';trailState.bossPatternTimer=pacing.bossAttack||150;trailState.bossShotCd=28;trailState.gameOver=false;trailState.messageShown=false;if(isTrailBossPhase()){const hp=TRAIL_LEVELS[trailLevel].bossHp+Math.max(0,Math.floor(trailState.phase/5)-1);trailState.boss={x:745,y:110,w:118,h:118,phase:0,float:0,hitFlash:0};trailState.bossHp=hp;trailState.bossMaxHp=hp;}syncTrailHud()}
function syncTrailHud(){if(!trailState)return;trailUI.phase.textContent=trailState.phase;trailUI.lives.textContent='💗 '+trailState.lives;trailUI.collected.textContent=`${trailState.totalCollected}/${trailState.nextLifeAt}`;trailUI.score.textContent=trailState.score;trailUI.mode.textContent=isTrailBossPhase()?'Modo chefão':'Modo aventura';
const flyEnergyEl=document.getElementById('trailFlyEnergy');if(flyEnergyEl)flyEnergyEl.textContent=Math.round(trailState.flyStamina||0)+'%';
const flyBarEl=document.getElementById('trailFlyBarFill');if(flyBarEl)flyBarEl.style.width=Math.round(trailState.flyStamina||0)+'%';if(trailState.mode==='boss'){trailUI.bossBar.classList.add('show');trailUI.bossFill.style.width=((trailState.bossHp/Math.max(1,trailState.bossMaxHp))*100)+'%'}else trailUI.bossBar.classList.remove('show')}
function trailLoop(ts){if(!trailRunning||!trailState)return;const dt=Math.min(1.6,(ts-trailLast)/16.6667);trailLast=ts;trailTick+=dt;updateTrail(dt);drawTrailScene(dt);trailAnim=requestAnimationFrame(trailLoop)}
function updateTrail(dt){const s=trailState,p=s.player,gravity=0.9; if(p.jumpBuffer>0)p.jumpBuffer--;
if(s.isFlying && s.flyStamina > 0){
  s.flyStamina = Math.max(0, s.flyStamina - dt * 0.45);
  p.vy = Math.max(-5.5, p.vy - 1.35 * dt);
  p.y += p.vy * dt;
  if(p.y < 95){ p.y = 95; p.vy = 0; }
  if(Math.random() < 0.32){
    s.effects.push({x: p.x - 24 + Math.random()*8, y: p.y + p.h - 10 + Math.random()*15, text: ['✨', '🌈', '⭐', '🦄', '💖'][Math.floor(Math.random()*5)], t: 28});
  }
  if(s.flyStamina <= 0){
    s.isFlying = false;
    toast('Energia de voo terminou, planando suavemente! 🦄');
  }
} else {
  p.vy += gravity * dt;
  p.y += p.vy * dt;
  if(p.y > s.ground - p.h){
    p.y = s.ground - p.h;
    p.vy = 0;
    if(p.jumpBuffer > 0){
      p.jumpBuffer = 0;
      p.vy = -TRAIL_LEVELS[trailLevel].jump;
    }
    s.flyStamina = Math.min(100, s.flyStamina + dt * 0.72);
  }
}
if(p.inv>0)p.inv-=dt;
 if(s.mode==='run'){const cfg=TRAIL_LEVELS[trailLevel];s.phaseDistance+=s.worldSpeed*dt*3; s.spawnTimer-=dt; s.collectTimer-=dt; if(s.spawnTimer<=0){spawnTrailObstacle(); s.spawnTimer=Math.max(42,cfg.spawnMin+Math.random()*cfg.spawnVar-Math.min(14,s.phase*.8))} if(s.collectTimer<=0){spawnTrailCollectible(); s.collectTimer=cfg.collectMin+Math.random()*cfg.collectVar} }
 if(s.mode==='boss')updateTrailBoss(dt);
 updateTrailEntities(dt); updateTrailProjectiles(dt); updateTrailEffects(dt); if(s.mode==='run'&&s.phaseDistance>=s.phaseDistanceGoal&&s.phaseCollected>=s.phaseGoal){completeTrailPhase()} syncTrailHud()}
function spawnTrailObstacle(){const themes=['mushroom','crate','crystal','bush'];const type=themes[Math.floor(Math.random()*themes.length)];const h=type==='crate'?48:type==='crystal'?60:type==='bush'?44:42;const w=type==='crate'?46:type==='crystal'?36:type==='bush'?52:40;trailState.entities.push({kind:'obstacle',type,x:950+Math.random()*80,y:trailState.ground-h,w,h})}
function spawnTrailCollectible(){
  const randVal=Math.random();
  const kind = randVal < 0.08 ? 'magnet' : (randVal < 0.16 ? 'shield' : (randVal < 0.36 ? 'unicorn' : 'star'));const arc=Math.random();let y=trailState.ground-110-Math.random()*120;if(arc>.6)y=trailState.ground-170-Math.random()*75;trailState.entities.push({kind:'collectible',type:kind,x:930+Math.random()*60,y,w:kind==='unicorn'?32:28,h:kind==='unicorn'?32:28,spin:Math.random()*6.28})}
function updateTrailEntities(dt){const s=trailState,p=s.player; s.entities.forEach(e=>{
  e.x-=s.worldSpeed*dt*3.2;
  if(e.spin!=null)e.spin+=0.08*dt;
  // Se o ímã estiver ativo, puxa estrelas e unicórnios em direção à Elo
  if(s.magnetTimer > 0 && e.kind === 'collectible'){
    const dx = p.x - e.x, dy = p.y - e.y, dist = Math.hypot(dx, dy) || 1;
    if(dist < 420){
      e.x += (dx / dist) * 7.5 * dt;
      e.y += (dy / dist) * 7.5 * dt;
    }
  }
});
if(s.magnetTimer > 0) s.magnetTimer -= dt; s.entities=s.entities.filter(e=>e.x+e.w>-60); for(const e of [...s.entities]){if(rectHit(p,e,16)){if(e.kind==='collectible'){collectTrailItem(e)} else if(e.kind==='obstacle'&&s.isFlying&&p.y<s.ground-p.h-35){if(Math.random()<0.14)s.effects.push({x:e.x,y:e.y-12,text:'🦄 Desviou!',t:28});} else if(p.inv<=0){trailDamage(1,'Cuidado com o obstáculo!')}}}}
function collectTrailItem(e){
  const s=trailState;
  s.entities=s.entities.filter(x=>x!==e);
  if(e.type === 'magnet'){
    s.magnetTimer = 380;
    s.effects.push({x:e.x, y:e.y, text:'🧲 Ímã Ativo!', t:50});
    toast('Ímã de Estrelas Ativado! 🧲✨');
    return;
  }
  if(e.type === 'shield'){
    s.hasShield = true;
    s.effects.push({x:e.x, y:e.y, text:'🛡️ Escudo!', t:50});
    toast('Escudo Mágico Protegendo a Elo! 🛡️✨');
    return;
  }
  const value=e.type==='unicorn'?2:1;
  s.phaseCollected+=value;
  s.totalCollected+=value;
  s.score+=e.type==='unicorn'?25:10;
  s.effects.push({x:e.x,y:e.y,text:e.type==='unicorn'?'🦄 +2':'⭐ +1',t:42}); if(s.totalCollected>=s.nextLifeAt){s.lives++; s.nextLifeAt+=100; toast('Vida extra! 💗')} if(s.phaseCollected>=s.phaseGoal&&s.mode==='run')trailUI.status.textContent='Objetivo da fase concluído! Continue até o final ✨'}
function updateTrailBoss(dt){const s=trailState,b=s.boss;if(!b)return;const cfg=TRAIL_LEVELS[trailLevel];b.float+=0.05*dt;b.hitFlash=Math.max(0,b.hitFlash-dt);if(b.x>660)b.x-=0.6*dt;s.bossPatternTimer-=dt;if(s.bossPattern==='attack'){s.bossVulnerable=false;trailUI.status.textContent='Chefão atacando! O Poder funciona, mas o intervalo é mais seguro 👻';s.bossShotCd-=dt;if(s.bossShotCd<=0){s.bossShotCd=cfg.bossShot;const shotType=Math.random()<0.35?'orb':'ghost';s.bossProjectiles.push({type:shotType,x:b.x+22,y:b.y+55+Math.sin(b.float)*12,vx:4.2+Math.min(1.5,s.phase*.08),vy:shotType==='orb'?0:(Math.random()-.5)*.25,w:shotType==='orb'?28:34,h:shotType==='orb'?28:34});}if(s.bossPatternTimer<=0){s.bossPattern='rest';s.bossPatternTimer=cfg.bossRest;s.bossVulnerable=true;s.bossProjectiles=[];trailUI.status.textContent='Intervalo! É a hora mais segura para usar Poder ✨';}}else{s.bossVulnerable=true;trailUI.status.textContent='Intervalo! É a hora mais segura para usar Poder ✨';if(s.bossPatternTimer<=0){s.bossPattern='attack';s.bossPatternTimer=cfg.bossAttack;s.bossVulnerable=false;s.bossShotCd=32;trailUI.status.textContent='Ele voltou a atacar! Você ainda pode usar Poder, mas cuidado!';}}for(const pr of s.bossProjectiles){pr.x-=pr.vx*dt;pr.y+=pr.vy*dt;}s.bossProjectiles=s.bossProjectiles.filter(pr=>pr.x+pr.w>-40);for(const pr of [...s.bossProjectiles])if(rectHit(s.player,{x:pr.x,y:pr.y,w:pr.w,h:pr.h},10)&&s.player.inv<=0){s.bossProjectiles=s.bossProjectiles.filter(x=>x!==pr);trailDamage(1,'O fantasma acertou a Elo!')}}
function updateTrailProjectiles(dt){const s=trailState;for(const pr of s.projectiles){pr.x+=pr.vx*dt;pr.alive=pr.x<980;}s.projectiles=s.projectiles.filter(pr=>pr.alive);if(s.mode==='boss'&&s.boss){for(const pr of [...s.projectiles]){if(rectHit({x:pr.x,y:pr.y,w:pr.size,h:pr.size},{x:s.boss.x,y:s.boss.y,w:s.boss.w,h:s.boss.h},14)){s.projectiles=s.projectiles.filter(x=>x!==pr);s.bossHp--;s.score+=20;s.boss.hitFlash=8;s.effects.push({x:s.boss.x+40,y:s.boss.y+20,text:'💥',t:30});if(s.bossHp<=0){defeatTrailBoss();break}}}}}
function updateTrailEffects(dt){trailState.effects.forEach(f=>{f.y-=.7*dt;f.t-=dt});trailState.effects=trailState.effects.filter(f=>f.t>0)}
function completeTrailPhase(){const s=trailState; trailStop(); s.score+=50+s.phase*5; trailUI.status.textContent=`Fase ${s.phase} concluída!`; addStars(1,`Fase ${s.phase} concluída! +1 ⭐`); setTimeout(()=>{s.phase++; prepareTrailPhase(); startTrailGame()},850)}
function defeatTrailBoss(){const s=trailState; trailStop(); s.score+=180; trailUI.status.textContent='Chefão derrotado! 🎉'; addStars(TRAIL_LEVELS[trailLevel].reward,`Chefão vencido! +${TRAIL_LEVELS[trailLevel].reward} ⭐`); if(!s.medalGiven){unlockGameMedal('trail',trailLevel);s.medalGiven=true}
 setTimeout(()=>{s.phase++; prepareTrailPhase(); startTrailGame()},1100)}
function trailDamage(amount,msg){
  const s=trailState,p=s.player;
  if(p.inv>0||s.gameOver)return;
  if(s.hasShield){
    s.hasShield = false;
    p.inv = 30;
    s.effects.push({x:p.x, y:p.y-20, text:'🛡️ Escudo Quebrou!', t:40});
    toast('O Escudo Mágico protegeu você! 🛡️');
    return;
  }s.lives=Math.max(0,s.lives-amount);p.inv=36;toast(msg);syncTrailHud();if(s.lives<=0){s.gameOver=true;trailStop();trailUI.status.textContent='Fim de jogo! Voltando para a fase 1...';setTimeout(()=>{restartTrailRun();startTrailGame()},1200);}}
function rectHit(a,b,pad=0){return a.x+pad<b.x+b.w&&a.x+a.w-pad>b.x&&a.y+pad<b.y+b.h&&a.y+a.h-pad>b.y}
function drawTrailScene(dt){const ctx=trailCtx,s=trailState||baseTrailState(); ctx.clearRect(0,0,trailCanvas.width,trailCanvas.height);ctx.filter='saturate(1.2) contrast(1.06)'; const phase=s.phase||1; const bossMode=s.mode==='boss'; const sky=ctx.createLinearGradient(0,0,0,trailCanvas.height); const skySets=[['#89dbff','#f7f2ff'],['#98ddff','#fff3ca'],['#6f66d9','#ffb8d0'],['#88dff3','#ffe8ff']][phase%4]; sky.addColorStop(0,skySets[0]); sky.addColorStop(1,skySets[1]); ctx.fillStyle=sky; ctx.fillRect(0,0,trailCanvas.width,trailCanvas.height); drawClouds(ctx,phase); drawSunMoon(ctx,phase); drawFarMountains(ctx,phase); drawMagicCastle(ctx,phase); drawHills(ctx,phase); drawGround(ctx,phase); if(phase%3===1&&!bossMode)drawRainbow(ctx); if(bossMode)drawBossArenaGlow(ctx);
 if(s.entities)for(const e of s.entities)drawTrailEntity(ctx,e); if(s.bossProjectiles)for(const p of s.bossProjectiles)drawBossProjectile(ctx,p); if(s.projectiles)for(const p of s.projectiles)drawMagicHeart(ctx,p.x,p.y,p.size||18); if(s.boss)drawGhostBoss(ctx,s.boss,s.boss.hitFlash>0);
if(s.isFlying || (s.player && s.player.y < s.ground - s.player.h - 8)){
  drawFlyingUnicorn(ctx, s.player.x - 12, s.player.y + s.player.h - 32, s.isFlying);
}
syncTrailEloClone(); if(s.effects)for(const f of s.effects){ctx.save();ctx.globalAlpha=Math.min(1,f.t/30);ctx.font='28px system-ui';ctx.fillText(f.text,f.x,f.y);ctx.restore()} if(!trailRunning&&trailState&&trailUI.status.textContent.startsWith('Toque em iniciar')){ctx.save();ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(250,160,400,80);ctx.fillStyle='#6949b4';ctx.font='900 26px system-ui';ctx.textAlign='center';ctx.fillText('Pronta para a aventura?',450,210);ctx.restore()}ctx.filter='none'}
function drawClouds(ctx,phase){for(let i=0;i<5;i++){const x=(i*210-(trailTick*8*(i%2?1.1:.8))%1100)+40,y=40+(i%3)*24;ctx.fillStyle='rgba(255,255,255,.78)';ctx.beginPath();ctx.arc(x,y,22,0,Math.PI*2);ctx.arc(x+20,y-8,17,0,Math.PI*2);ctx.arc(x+42,y,20,0,Math.PI*2);ctx.fill();}}
function drawSunMoon(ctx,phase){ctx.save();if(phase%4===2){ctx.fillStyle='#ffe28c';ctx.beginPath();ctx.arc(120,74,34,0,Math.PI*2);ctx.fill()}else if(phase%4===3){ctx.fillStyle='#fff5b3';ctx.beginPath();ctx.arc(120,74,28,0,Math.PI*2);ctx.fill();ctx.fillStyle='rgba(111,102,217,.75)';ctx.beginPath();ctx.arc(132,68,25,0,Math.PI*2);ctx.fill()}else{ctx.fillStyle='#fff5cc';ctx.beginPath();ctx.arc(120,74,34,0,Math.PI*2);ctx.fill();}ctx.restore()}
function drawFarMountains(ctx,phase){ctx.fillStyle=phase%4===3?'#6b60ba':'#b9b0e7';ctx.beginPath();ctx.moveTo(0,250); for(let i=0;i<=10;i++){ctx.lineTo(i*95,180+Math.sin(i*1.4+trailTick*.01)*34)} ctx.lineTo(900,330);ctx.lineTo(0,330);ctx.closePath();ctx.fill(); ctx.fillStyle=phase%4===3?'#8b7fd1':'#d9cef6';ctx.beginPath();ctx.moveTo(0,280); for(let i=0;i<=9;i++){ctx.lineTo(i*110,220+Math.cos(i*1.2+trailTick*.015)*24)} ctx.lineTo(900,340);ctx.lineTo(0,340);ctx.closePath();ctx.fill();}
function drawMagicCastle(ctx,phase){ctx.save();ctx.translate(690,150);ctx.fillStyle=phase%4===3?'rgba(255,255,255,.22)':'rgba(255,255,255,.34)';ctx.fillRect(-8,0,90,118);ctx.fillStyle='#f7d1ef';ctx.fillRect(0,30,74,88);ctx.fillStyle='#c794f0';ctx.fillRect(10,-10,14,56);ctx.fillRect(50,-22,14,68);ctx.fillStyle='#f2b445';ctx.beginPath();ctx.moveTo(7,-10);ctx.lineTo(17,-32);ctx.lineTo(27,-10);ctx.fill();ctx.beginPath();ctx.moveTo(47,-22);ctx.lineTo(57,-44);ctx.lineTo(67,-22);ctx.fill();ctx.fillStyle='#8e61dc';ctx.fillRect(30,74,15,44);ctx.restore();}
function drawHills(ctx,phase){ctx.fillStyle='#84cf83';ctx.beginPath();ctx.moveTo(0,280); for(let i=0;i<=8;i++){ctx.quadraticCurveTo(i*120+60,230+Math.sin(i+trailTick*.02)*18,(i+1)*120,285)} ctx.lineTo(900,trailCanvas.height);ctx.lineTo(0,trailCanvas.height);ctx.closePath();ctx.fill(); ctx.fillStyle='#6cbc6a';ctx.beginPath();ctx.moveTo(0,325); for(let i=0;i<=9;i++){ctx.quadraticCurveTo(i*100+40,300+Math.cos(i+trailTick*.025)*16,(i+1)*100,330)} ctx.lineTo(900,trailCanvas.height);ctx.lineTo(0,trailCanvas.height);ctx.closePath();ctx.fill();}
function drawGround(ctx,phase){ctx.fillStyle='#866341';ctx.fillRect(0,trailState?trailState.ground+48:438,900,Math.max(52,trailCanvas.height-(trailState?trailState.ground+48:438))); ctx.fillStyle='#9be284';ctx.fillRect(0,trailState?trailState.ground+38:378,900,12); for(let i=0;i<20;i++){ctx.fillStyle=i%2?'#ffe69a':'#f6a2c7';ctx.beginPath();ctx.arc(i*48+10,trailState.ground+34+Math.sin(i)*2,3.5,0,Math.PI*2);ctx.fill();}}
function drawRainbow(ctx){ctx.save();ctx.globalAlpha=.3;const cx=190,cy=270;['#ff6b99','#ffa94d','#ffe066','#8ce99a','#74c0fc','#b197fc'].forEach((c,i)=>{ctx.strokeStyle=c;ctx.lineWidth=10;ctx.beginPath();ctx.arc(cx,cy,160-i*16,Math.PI,Math.PI*2);ctx.stroke()});ctx.restore()}
function drawBossArenaGlow(ctx){const g=ctx.createRadialGradient(710,160,10,710,160,240);g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(470,0,430,330)}
function drawTrailEntity(ctx,e){if(e.kind==='collectible'){ctx.save();ctx.translate(e.x+e.w/2,e.y+e.h/2);ctx.rotate(Math.sin(e.spin||0)*0.2); if(e.type==='unicorn'){if(gameUnicornImg.complete&&gameUnicornImg.naturalWidth)ctx.drawImage(gameUnicornImg,-18,-18,38,34);else{ctx.font='28px system-ui';ctx.fillText('🦄',-14,10)}}
else if(e.type==='magnet'){ctx.font='30px system-ui';ctx.fillText('🧲',-15,10)}
else if(e.type==='shield'){ctx.font='30px system-ui';ctx.fillText('🛡️',-15,10)}
else {ctx.font='26px system-ui';ctx.fillText('⭐',-12,10)} ctx.restore(); return;} ctx.save(); if(e.type==='crate'){ctx.fillStyle='#c69058';ctx.fillRect(e.x,e.y,e.w,e.h);ctx.strokeStyle='#8b5d35';ctx.lineWidth=4;ctx.strokeRect(e.x+2,e.y+2,e.w-4,e.h-4);ctx.beginPath();ctx.moveTo(e.x+6,e.y+6);ctx.lineTo(e.x+e.w-6,e.y+e.h-6);ctx.moveTo(e.x+e.w-6,e.y+6);ctx.lineTo(e.x+6,e.y+e.h-6);ctx.stroke();}
 else if(e.type==='crystal'){ctx.fillStyle='#b47dff';ctx.beginPath();ctx.moveTo(e.x+e.w/2,e.y);ctx.lineTo(e.x+e.w,e.y+e.h*.4);ctx.lineTo(e.x+e.w*.7,e.y+e.h);ctx.lineTo(e.x+e.w*.3,e.y+e.h);ctx.lineTo(e.x,e.y+e.h*.4);ctx.closePath();ctx.fill();ctx.fillStyle='rgba(255,255,255,.35)';ctx.fillRect(e.x+e.w*.45,e.y+8,6,e.h-14)}
 else if(e.type==='bush'){ctx.fillStyle='#4da06f';ctx.beginPath();ctx.ellipse(e.x+16,e.y+20,18,20,0,0,Math.PI*2);ctx.ellipse(e.x+32,e.y+18,18,20,0,0,Math.PI*2);ctx.ellipse(e.x+43,e.y+22,16,18,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#a8ecae';ctx.fillRect(e.x+20,e.y+28,4,10)}
 else {ctx.fillStyle='#f24f9f';ctx.beginPath();ctx.arc(e.x+14,e.y+14,12,0,Math.PI*2);ctx.arc(e.x+26,e.y+18,14,0,Math.PI*2);ctx.fillStyle='#f45ea8';ctx.fill();ctx.fillStyle='#fff29b';ctx.fillRect(e.x+18,e.y+24,6,14)} ctx.restore()}
function drawBossProjectile(ctx,p){ctx.save(); if(p.type==='ghost'){ctx.font='30px system-ui';ctx.fillText('👻',p.x,p.y+26)} else {const g=ctx.createRadialGradient(p.x+14,p.y+14,2,p.x+14,p.y+14,14);g.addColorStop(0,'#fff');g.addColorStop(.45,'#d6b2ff');g.addColorStop(1,'#8f63ff');ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x+14,p.y+14,14,0,Math.PI*2);ctx.fill();} ctx.restore()}
function drawMagicHeart(ctx,x,y,size){ctx.save();ctx.translate(x,y);ctx.fillStyle='#ff6fae';ctx.beginPath();ctx.moveTo(0,size*.28);ctx.bezierCurveTo(0,-size*.05,-size*.42,-size*.06,-size*.42,size*.22);ctx.bezierCurveTo(-size*.42,size*.45,-size*.12,size*.62,0,size*.8);ctx.bezierCurveTo(size*.12,size*.62,size*.42,size*.45,size*.42,size*.22);ctx.bezierCurveTo(size*.42,-size*.06,0,-size*.05,0,size*.28);ctx.fill();ctx.restore()}
function drawGhostBoss(ctx,b,flash){ctx.save();ctx.translate(b.x,b.y+Math.sin(b.float)*10);ctx.globalAlpha=.96;ctx.fillStyle=flash?'#ffd0f2':'#f1e6ff';ctx.beginPath();ctx.arc(58,40,34,Math.PI,0);ctx.lineTo(92,92);for(let i=0;i<5;i++)ctx.quadraticCurveTo(84-i*14,102,77-i*14,92);ctx.lineTo(24,92);for(let i=0;i<4;i++)ctx.quadraticCurveTo(18+i*12,102,12+i*12,92);ctx.closePath();ctx.fill();ctx.fillStyle='#6d59b8';ctx.beginPath();ctx.arc(45,42,6,0,Math.PI*2);ctx.arc(71,42,6,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#c77be8';ctx.lineWidth=4;ctx.beginPath();ctx.arc(58,58,14,.2,Math.PI-.2);ctx.stroke();ctx.font='28px system-ui';ctx.fillText('👑',46,16);ctx.restore()}
function drawPlayerElo(ctx,p,blink){ctx.save();ctx.translate(p.x,p.y);ctx.globalAlpha=blink?.45:1;
 // cabelo baixo: rabo de cavalo para trás/para baixo
 ctx.fillStyle='#5b3527';
 // coque/base baixa atrás da cabeça
 for(const [cx,cy,r] of [[17,24,8],[12,28,7],[10,35,7],[18,38,8],[24,36,7],[8,18,6]]){ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill()}
 // topo e frente do cabelo, olhando de lado/frente de forma mais suave
 for(const [cx,cy,r] of [[25,14,10],[32,14,10],[38,18,8],[22,20,8]]){ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill()}
 // laço rosa preso atrás e mais baixo
 ctx.fillStyle='#ff70b3';ctx.beginPath();ctx.ellipse(16,18,7,5,-.25,0,Math.PI*2);ctx.ellipse(26,18,7,5,.25,0,Math.PI*2);ctx.fill();ctx.fillStyle='#ff4f9d';ctx.beginPath();ctx.arc(21,18,3.5,0,Math.PI*2);ctx.fill();
 // rosto
 ctx.fillStyle='#efbd9b';ctx.beginPath();ctx.arc(29,27,17,0,Math.PI*2);ctx.fill();ctx.fillStyle='#2f2544';ctx.beginPath();ctx.arc(23,26,2.6,0,Math.PI*2);ctx.arc(35,26,2.6,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(22.2,25.2,.8,0,Math.PI*2);ctx.arc(34.2,25.2,.8,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#d57da4';ctx.lineWidth=2;ctx.beginPath();ctx.arc(29,33,7,.15,Math.PI-.15);ctx.stroke();
 // camiseta e vestido/short roxo-rosa
 ctx.fillStyle='#ff78ad';ctx.beginPath();ctx.moveTo(17,44);ctx.quadraticCurveTo(29,40,41,44);ctx.lineTo(45,64);ctx.lineTo(13,64);ctx.closePath();ctx.fill();ctx.fillStyle='#7a4fc5';ctx.beginPath();ctx.moveTo(13,63);ctx.lineTo(45,63);ctx.lineTo(40,80);ctx.lineTo(18,80);ctx.closePath();ctx.fill();ctx.fillStyle='#ffd65b';ctx.font='13px system-ui';ctx.fillText('★',25,60);
 // mochila lateral
 ctx.fillStyle='#8e4fbe';ctx.beginPath();ctx.roundRect(42,49,13,20,4);ctx.fill();ctx.fillStyle='#ffd65b';ctx.font='10px system-ui';ctx.fillText('★',44,63);
 // braços e pernas
 ctx.fillStyle='#efbd9b';ctx.fillRect(9,48,7,19);ctx.fillRect(42,48,7,19);ctx.fillRect(19,79,7,15);ctx.fillRect(33,79,7,15);ctx.fillStyle='#f6b5d1';ctx.fillRect(18,90,10,5);ctx.fillRect(32,90,10,5);ctx.restore()}
trailCanvas.addEventListener('pointerdown',e=>{e.preventDefault();trailJump()});const trailWrap=trailCanvas.closest('.trailCanvasWrap');if(trailWrap)trailWrap.addEventListener('pointerdown',e=>{if(e.target===trailCanvas)return;e.preventDefault();trailJump()});
window.addEventListener('keydown',e=>{if(document.getElementById('gameModal').classList.contains('hidden'))return;if(document.getElementById('trailGame').classList.contains('active')){if(e.code==='Space'||e.code==='ArrowUp'){e.preventDefault();trailJump()} if(e.code==='KeyZ'||e.code==='Enter'){e.preventDefault();trailMagic()} if(e.code==='KeyX'||e.code==='KeyW'||e.code==='KeyF'){e.preventDefault();trailFlyStart()}}});
restartTrailRun();


// ===== v2.2 • Escolinha adaptada por faixa etária =====
const SCHOOL_KID_SETS={
 colors:{name:'Cores',icon:'🎨',items:[['vermelho','🔴'],['azul','🔵'],['amarelo','🟡'],['verde','🟢'],['rosa','🩷'],['roxo','🟣']]},
 numbers:{name:'Números',icon:'🔢',items:[['1','1'],['2','2'],['3','3'],['4','4'],['5','5'],['6','6'],['7','7'],['8','8'],['9','9']]},
 fruits:{name:'Frutas',icon:'🍓',items:[['maçã','🍎'],['banana','🍌'],['morango','🍓'],['laranja','🍊'],['uva','🍇'],['melancia','🍉']]},
 animals:{name:'Animais',icon:'🐾',items:[['gato','🐱'],['cachorro','🐶'],['pássaro','🐦'],['peixe','🐟'],['coelho','🐰'],['leão','🦁']]},
 shapes:{name:'Formas',icon:'🔷',items:[['círculo','●'],['quadrado','■'],['triângulo','▲'],['estrela','★'],['coração','♥']]}
};
let schoolKidCategory='colors',schoolKidRound=0,schoolKidScore=0,schoolKidLocked=false;
function getSchoolAge(){return getActiveProfile().ageRange||'6-8'}
function renderSchoolChallenges(){const controls=document.getElementById('schoolControls'),info=document.getElementById('schoolAgeInfo');if(!controls||!info)return;const age=getSchoolAge();info.innerHTML=`<div class="schoolAgeBadge">🎂 ${age.replace('-', '–')} anos</div>`;if(age==='3-5'){controls.innerHTML=`<p class="muted">A criança ouve e toca. Não precisa ler para responder.</p><div class="kidSchoolCats">${Object.entries(SCHOOL_KID_SETS).map(([id,s])=>`<button class="chip ${schoolKidCategory===id?'on':''}" onclick="startKidSchool('${id}')">${s.icon} ${s.name}</button>`).join('')}</div>`;startKidSchool(schoolKidCategory,true)}else{const levels=age==='9-11'?[['medium','Médio'],['hard','Desafio']]:[['easy','Fácil'],['medium','Médio']];controls.innerHTML=`<p class="muted">Atividades de leitura, matemática, lógica e conhecimentos adequadas à faixa.</p><div class="levelRow">${levels.map(([id,label],i)=>`<button class="levelBtn ${i===0?'on':''}" data-level="${id}" onclick="startQuiz('${id}')">${label}</button>`).join('')}</div>`;startQuiz(levels[0][0])}}
function startKidSchool(category='colors',silent=false){schoolKidCategory=category;schoolKidRound=0;schoolKidScore=0;schoolKidLocked=false;document.querySelectorAll('.kidSchoolCats .chip').forEach((b,i)=>b.classList.toggle('on',Object.keys(SCHOOL_KID_SETS)[i]===category));renderKidSchoolQuestion(silent)}
function kidOptionVisual(category,item){if(category==='colors')return `<span class="kidSchoolVisual colorDot ${item[1]==='🔴'?'red':item[1]==='🔵'?'blue':item[1]==='🟡'?'yellow':item[1]==='🟢'?'green':item[1]==='🩷'?'pink':'purple'}"></span>`;return `<span class="kidSchoolVisual">${item[1]}</span>`}
function renderKidSchoolQuestion(silent=false){const box=document.getElementById('quiz'),set=SCHOOL_KID_SETS[schoolKidCategory];if(!box||!set)return;if(schoolKidRound>=8){box.innerHTML=`<div class="kidSchoolEnd"><div>🏅⭐</div><b>${schoolKidScore}/8</b><button class="btn" onclick="startKidSchool('${schoolKidCategory}')">🔁</button></div>`;addStars(Math.max(1,Math.floor(schoolKidScore/3)),'Escolinha concluída! ⭐');trackActivity('school');return}schoolKidLocked=false;const correct=set.items[Math.floor(Math.random()*set.items.length)],others=shuffle(set.items.filter(x=>x[0]!==correct[0])).slice(0,2),opts=shuffle([correct,...others]);box.dataset.correct=correct[0];box.innerHTML=`<div class="kidSchoolActivity"><button class="kidListenMain" onclick="speakText('Toque em ${escapeHtml(correct[0])}')">👂</button><div class="kidSchoolOptions">${opts.map(o=>`<button class="kidSchoolChoice" data-value="${escapeHtml(o[0])}" onclick="answerKidSchool(this)">${kidOptionVisual(schoolKidCategory,o)}</button>`).join('')}</div><div class="kidSchoolDots">${schoolKidRound+1}/8</div></div>`;if(!silent)setTimeout(()=>speakText(`Toque em ${correct[0]}`),250)}
function answerKidSchool(btn){if(schoolKidLocked)return;const box=document.getElementById('quiz'),correct=box.dataset.correct;if(btn.dataset.value!==correct){btn.classList.add('bad');speakText(`Tente de novo. Toque em ${correct}`);setTimeout(()=>btn.classList.remove('bad'),600);return}schoolKidLocked=true;schoolKidScore++;btn.classList.add('good');speakText('Muito bem!');schoolKidRound++;setTimeout(()=>renderKidSchoolQuestion(false),850)}

// Quiz
const QUESTIONS={
 easy:[
  ['Qual animal faz “miau”?',['Cachorro','Gato','Pato'],1,'Animais'],['Qual cor aparece no céu em um dia sem nuvens?',['Azul','Marrom','Preto'],0,'Cores'],['Quanto é 2 + 2?',['3','4','5'],1,'Números'],['Qual destes vive na água?',['Peixe','Leão','Galinha'],0,'Animais'],['Qual letra começa a palavra ELO?',['A','E','O'],1,'Letras'],['Quantos dedos temos em uma mão?',['3','5','8'],1,'Corpo'],['Qual fruta costuma ser amarela?',['Banana','Morango','Uva'],0,'Frutas'],['Qual destes é uma forma redonda?',['Círculo','Triângulo','Quadrado'],0,'Formas'],['Qual número vem depois do 6?',['5','7','9'],1,'Números'],['Qual animal late?',['Gato','Cachorro','Peixe'],1,'Animais'],['Misturando azul e amarelo, qual cor aparece?',['Verde','Vermelho','Preto'],0,'Cores'],['Quantas rodas tem uma bicicleta comum?',['1','2','4'],1,'Conhecimentos'],['Qual é o contrário de grande?',['Pequeno','Alto','Largo'],0,'Palavras'],['Qual destes é usado para escrever?',['Lápis','Prato','Sapato'],0,'Objetos'],['Qual estação costuma ser mais fria?',['Verão','Inverno','Primavera'],1,'Natureza'],['Qual número é maior?',['3','8','5'],1,'Números'],['Qual dessas atitudes é gentil?',['Ajudar alguém','Empurrar alguém','Gritar com alguém'],0,'Boas atitudes'],['Qual parte do corpo usamos para ouvir?',['Olhos','Ouvidos','Nariz'],1,'Corpo'],['Qual destes cresce em uma árvore?',['Maçã','Bola','Colher'],0,'Natureza'],['Qual letra vem depois do B?',['C','A','D'],0,'Letras']
 ],
 medium:[
  ['Quanto é 7 + 5?',['10','12','13'],1,'Matemática'],['Qual palavra está escrita corretamente?',['Caza','Casa','Cassa'],1,'Português'],['Se você tem 10 balas e dá 3, quantas sobram?',['7','6','8'],0,'Matemática'],['Qual destes animais é mamífero?',['Golfinho','Tubarão','Polvo'],0,'Animais'],['Qual planeta onde vivemos?',['Marte','Terra','Júpiter'],1,'Natureza'],['Qual é a metade de 10?',['2','5','8'],1,'Matemática'],['Qual palavra rima com “gato”?',['Pato','Bola','Flor'],0,'Português'],['Quantos lados tem um triângulo?',['3','4','5'],0,'Formas'],['O que uma planta precisa para crescer?',['Água e luz','Só brinquedos','Escuridão total'],0,'Natureza'],['Qual é o dobro de 4?',['6','8','10'],1,'Matemática'],['Qual palavra começa com o mesmo som de “bola”?',['Boca','Casa','Dado'],0,'Português'],['Qual destes é um inseto?',['Borboleta','Gato','Sapo'],0,'Animais'],['Que número falta: 2, 4, 6, __?',['7','8','10'],1,'Lógica'],['Se hoje é segunda-feira, amanhã será?',['Domingo','Terça-feira','Sábado'],1,'Tempo'],['Qual objeto mede a temperatura?',['Termômetro','Régua','Relógio'],0,'Conhecimentos'],['Qual atitude protege a natureza?',['Jogar lixo no chão','Reciclar','Desperdiçar água'],1,'Boas atitudes'],['Quanto é 15 - 6?',['9','8','10'],0,'Matemática'],['Qual palavra tem 3 sílabas?',['Sol','Boneca','Pão'],1,'Português'],['Qual destes não é fruta?',['Maçã','Cenoura','Pera'],1,'Alimentos'],['Qual sequência está em ordem crescente?',['5,4,3','2,4,6','9,7,8'],1,'Lógica']
 ],
 hard:[
  ['Quanto é 8 × 3?',['18','24','32'],1,'Matemática'],['Qual é o resultado de 36 ÷ 6?',['5','6','7'],1,'Matemática'],['Qual palavra é sinônimo de “feliz”?',['Alegre','Bravo','Cansado'],0,'Português'],['Qual número completa: 3, 6, 9, 12, __?',['14','15','16'],1,'Lógica'],['Uma dúzia corresponde a quantas unidades?',['10','12','20'],1,'Matemática'],['Qual destes animais é anfíbio?',['Sapo','Águia','Cavalo'],0,'Animais'],['Qual é a capital do Brasil?',['Brasília','Rio de Janeiro','São Paulo'],0,'Conhecimentos'],['Quantos minutos existem em uma hora?',['30','60','100'],1,'Tempo'],['Qual palavra é o oposto de “rápido”?',['Lento','Forte','Claro'],0,'Português'],['Se um livro tem 20 páginas e você leu 12, faltam quantas?',['8','10','12'],0,'Matemática'],['Qual é o próximo número: 1, 4, 7, 10, __?',['12','13','14'],1,'Lógica'],['Qual destes órgãos bombeia sangue pelo corpo?',['Coração','Pulmão','Estômago'],0,'Corpo'],['Qual é 25 + 17?',['40','42','43'],1,'Matemática'],['Qual palavra está no plural?',['Menina','Meninas','Menino'],1,'Português'],['Se três crianças dividem 12 figurinhas igualmente, cada uma recebe?',['3','4','6'],1,'Matemática'],['O que acontece com a água quando congela?',['Vira gelo','Vira fumaça','Desaparece'],0,'Natureza'],['Qual número é primo?',['9','11','15'],1,'Matemática'],['Qual frase demonstra empatia?',['Não me importo','Posso ajudar você?','Saia daqui'],1,'Boas atitudes'],['Quantos centímetros formam um metro?',['10','100','1000'],1,'Medidas'],['Qual destas palavras é um verbo?',['Correr','Azul','Casa'],0,'Português']
 ]
};
function toggleSchoolChallenges(force){const content=document.getElementById('schoolChallengesContent'),hero=document.getElementById('schoolChallengesHero');if(!content||!hero)return;const open=typeof force==='boolean'?force:content.classList.contains('hidden');content.classList.toggle('hidden',!open);hero.classList.toggle('open',open);hero.setAttribute('aria-expanded',open?'true':'false');if(open)renderSchoolChallenges()}
let quizLevel='easy',quizDeck=[],quizPos=0,quizCorrect=0;
function shuffle(arr){const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function startQuiz(level='easy'){quizLevel=level;document.querySelectorAll('.levelBtn').forEach(b=>b.classList.toggle('on',b.dataset.level===level));quizDeck=shuffle(QUESTIONS[level]).slice(0,10);quizPos=0;quizCorrect=0;renderQuiz()}
let currentLegacyQuizChoices = [];
function renderQuiz(){
  const box=document.getElementById('quiz');
  if(!box)return;
  if(quizPos>=quizDeck.length){
    const reward=Math.max(1,Math.floor(quizCorrect/3));
    box.innerHTML=`<div class="quizEnd"><strong>${quizCorrect}/10 acertos 🎉</strong><p class="muted">Rodada concluída sem repetir perguntas.</p><button class="btn" onclick="startQuiz('${quizLevel}')">Nova rodada</button></div>`;
    addStars(reward,`Escolinha concluída! +${reward} ⭐`);
    trackActivity('school');
    return;
  }
  const q=quizDeck[quizPos];
  const items = q[1].map((text, idx) => ({ text, isCorrect: idx === q[2] }));
  currentLegacyQuizChoices = shuffle(items);
  box.innerHTML=`<div class="quizTop"><span class="quizProgress">Pergunta ${quizPos+1}/10 • ${q[3]}</span><span class="quizProgress">Acertos: ${quizCorrect}</span></div><div class="quiz-q">${q[0]}</div><div class="answers">${currentLegacyQuizChoices.map((c,i)=>`<button class="ans" onclick="answerQuiz(${i})">${c.text}</button>`).join('')}</div>`;
}
function answerQuiz(i){
  const choice = currentLegacyQuizChoices[i];
  if(choice && choice.isCorrect){
    quizCorrect++;
    toast('Acertou! ⭐');
    quizPos++;
    setTimeout(renderQuiz,250);
  } else {
    toast('Quase! Tente outra resposta 😊');
  }
}

// Coloring
const COLORING=Array.from({length:10},(_,i)=>`assets/coloring/color-${i+1}.webp`);
const PALETTE=['#ff6fae','#ff4f8b','#ff8aa8','#ffd866','#ffbf3f','#f28b4b','#ff6b6b','#a756f5','#7756d8','#5f7bff','#61c9ef','#00bcd4','#67c98e','#00b894','#5cc08a','#8d5a3b','#c97f53','#9ea7ad','#404040','#000000','#ffffff','#d4a5ff','#a3d8ff','#f7b2d9','#b8f2e6','#ffe8a3','#f1c0a8','#caffbf','#ffc6ff','#bde0fe'];
let colorIndex=0,color='#ff6fae',baseTemplate=null,colorHistory=[];
const COLOR_HISTORY_LIMIT=6;
const canvas=document.getElementById('draw');
const ctx=canvas.getContext('2d',{willReadFrequently:true});
const colorViewport=document.getElementById('colorViewport');
const colorCanvasWrap=document.getElementById('colorCanvasWrap');
let colorZoom=1,colorBaseDisplay=600,colorPointers=new Map(),colorGesture=null,colorDragMoved=false,colorDragStart=null;
function renderColoringGallery(){const g=document.getElementById('coloringGallery');if(!g)return;g.innerHTML=COLORING.map((src,i)=>`<button class="templateBtn ${i===colorIndex?'on':''}" onclick="openColoring(${i})"><img src="${src}" alt="Desenho ${i+1}"></button>`).join('');const c=document.getElementById('coloringCountText');if(c)c.textContent=`${COLORING.length} desenhos novos da Elo. Toque em um para abrir em tela cheia.`}
function renderPalette(){const p=document.getElementById('palette');if(!p)return;p.innerHTML=PALETTE.map(c=>`<button class="color ${color===c?'on':''}" style="background:${c}" onclick="setColor('${c}')" aria-label="cor"></button>`).join('')}
function setColor(c){color=c;renderPalette();toast('Cor escolhida! Agora toque no desenho 🎨')}
function fitImage(img){const ratio=Math.min(canvas.width/img.width,canvas.height/img.height);const w=img.width*ratio,h=img.height*ratio,x=(canvas.width-w)/2,y=(canvas.height-h)/2;ctx.drawImage(img,x,y,w,h)}
function normalizeTemplate(){const image=ctx.getImageData(0,0,canvas.width,canvas.height),d=image.data;for(let i=0;i<d.length;i+=4){const lum=(d[i]+d[i+1]+d[i+2])/3;if(lum<215){d[i]=d[i+1]=d[i+2]=0;d[i+3]=255}else{d[i]=d[i+1]=d[i+2]=255;d[i+3]=255}}ctx.putImageData(image,0,0)}
function drawBase(){ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height);if(baseTemplate)fitImage(baseTemplate);normalizeTemplate();colorHistory=[]}
function chooseColoring(i,showModal=false){colorIndex=i;const img=new Image();img.onload=()=>{baseTemplate=img;drawBase();renderColoringGallery();renderPalette();if(showModal){document.getElementById('coloringModal').classList.remove('hidden');document.body.style.overflow='hidden';requestAnimationFrame(()=>resetColorZoom())}toast('Desenho pronto! Use zoom se precisar e toque para pintar. 🖍️')};img.src=COLORING[i]}
function getPointerPos(e){const r=canvas.getBoundingClientRect();return{x:Math.max(0,Math.min(canvas.width-1,Math.floor((e.clientX-r.left)*(canvas.width/r.width)))),y:Math.max(0,Math.min(canvas.height-1,Math.floor((e.clientY-r.top)*(canvas.height/r.height))))}}
function hexToRgb(hex){const c=hex.replace('#','');const n=parseInt(c.length===3?c.split('').map(x=>x+x).join(''):c,16);return[(n>>16)&255,(n>>8)&255,n&255]}
function colorMatch(d,i,target,tol=18){return Math.abs(d[i]-target[0])<=tol&&Math.abs(d[i+1]-target[1])<=tol&&Math.abs(d[i+2]-target[2])<=tol&&d[i+3]===target[3]}
function fillAt(x,y){const image=ctx.getImageData(0,0,canvas.width,canvas.height),d=image.data,w=image.width,h=image.height;const start=(y*w+x)*4;const target=[d[start],d[start+1],d[start+2],d[start+3]];if(target[0]<30&&target[1]<30&&target[2]<30)return;const fill=hexToRgb(color);if(Math.abs(target[0]-fill[0])<4&&Math.abs(target[1]-fill[1])<4&&Math.abs(target[2]-fill[2])<4)return;colorHistory.push(ctx.getImageData(0,0,w,h));if(colorHistory.length>COLOR_HISTORY_LIMIT)colorHistory.shift();const matches=(px,py)=>{if(px<0||py<0||px>=w||py>=h)return false;return colorMatch(d,(py*w+px)*4,target)};const paint=(px,py)=>{const i=(py*w+px)*4;d[i]=fill[0];d[i+1]=fill[1];d[i+2]=fill[2];d[i+3]=255};const stack=[[x,y]];while(stack.length){const [sx,sy]=stack.pop();if(!matches(sx,sy))continue;let lx=sx;while(lx>=0&&matches(lx,sy))lx--;lx++;let spanUp=false,spanDown=false;for(let px=lx;px<w&&matches(px,sy);px++){paint(px,sy);if(sy>0){if(matches(px,sy-1)){if(!spanUp){stack.push([px,sy-1]);spanUp=true}}else spanUp=false}if(sy<h-1){if(matches(px,sy+1)){if(!spanDown){stack.push([px,sy+1]);spanDown=true}}else spanDown=false}}}ctx.putImageData(image,0,0)}
function updateZoomLabel(){const z=document.getElementById('zoomValue');if(z)z.textContent=Math.round(colorZoom*100)+'%'}
function applyColorZoom(next,anchor=null){if(!colorViewport||!colorCanvasWrap)return;const oldZoom=colorZoom;const oldSize=colorBaseDisplay*oldZoom;colorZoom=Math.max(1,Math.min(4,next));colorBaseDisplay=Math.min(600,Math.max(280,colorViewport.clientWidth-8));const newSize=colorBaseDisplay*colorZoom;let ax=colorViewport.clientWidth/2,ay=colorViewport.clientHeight/2;if(anchor){ax=anchor.x;ay=anchor.y}const contentX=(colorViewport.scrollLeft+ax)/(oldSize||colorBaseDisplay),contentY=(colorViewport.scrollTop+ay)/(oldSize||colorBaseDisplay);colorCanvasWrap.style.width=newSize+'px';colorCanvasWrap.style.height=newSize+'px';canvas.style.width=newSize+'px';canvas.style.height=newSize+'px';updateZoomLabel();if(oldZoom!==colorZoom){requestAnimationFrame(()=>{colorViewport.scrollLeft=Math.max(0,contentX*newSize-ax);colorViewport.scrollTop=Math.max(0,contentY*newSize-ay)})}}
function zoomColor(delta){applyColorZoom(colorZoom+delta)}
function resetColorZoom(){colorZoom=1;colorViewport.scrollLeft=0;colorViewport.scrollTop=0;applyColorZoom(1);requestAnimationFrame(()=>{colorViewport.scrollLeft=0;colorViewport.scrollTop=0})}
function pointerDistance(){const pts=[...colorPointers.values()];if(pts.length<2)return 0;return Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y)}
function pointerMidpoint(){const pts=[...colorPointers.values()];if(pts.length<2)return{x:colorViewport.clientWidth/2,y:colorViewport.clientHeight/2};const r=colorViewport.getBoundingClientRect();return{x:(pts[0].x+pts[1].x)/2-r.left,y:(pts[0].y+pts[1].y)/2-r.top}}
colorViewport.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button!==0)return;colorViewport.setPointerCapture?.(e.pointerId);colorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(colorPointers.size===1){colorDragMoved=false;colorDragStart={x:e.clientX,y:e.clientY,scrollLeft:colorViewport.scrollLeft,scrollTop:colorViewport.scrollTop,target:e.target}}else if(colorPointers.size===2){colorGesture={dist:pointerDistance(),zoom:colorZoom,mid:pointerMidpoint()};colorDragMoved=true}e.preventDefault()});
colorViewport.addEventListener('pointermove',e=>{if(!colorPointers.has(e.pointerId))return;colorPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(colorPointers.size>=2&&colorGesture){const d=pointerDistance();if(colorGesture.dist>0)applyColorZoom(colorGesture.zoom*(d/colorGesture.dist),pointerMidpoint());colorDragMoved=true;e.preventDefault();return}if(colorPointers.size===1&&colorDragStart&&colorZoom>1){const dx=e.clientX-colorDragStart.x,dy=e.clientY-colorDragStart.y;if(Math.hypot(dx,dy)>7)colorDragMoved=true;if(colorDragMoved){colorViewport.scrollLeft=colorDragStart.scrollLeft-dx;colorViewport.scrollTop=colorDragStart.scrollTop-dy;e.preventDefault()}}});
function endColorPointer(e){const wasOnly=colorPointers.size===1;const shouldPaint=wasOnly&&!colorDragMoved&&colorDragStart?.target===canvas;if(shouldPaint){const p=getPointerPos(e);fillAt(p.x,p.y)}colorPointers.delete(e.pointerId);if(colorPointers.size<2)colorGesture=null;if(colorPointers.size===0){colorDragStart=null;colorDragMoved=false}e.preventDefault()}
colorViewport.addEventListener('pointerup',endColorPointer);colorViewport.addEventListener('pointercancel',e=>{colorPointers.delete(e.pointerId);if(colorPointers.size<2)colorGesture=null;if(colorPointers.size===0){colorDragStart=null;colorDragMoved=false}});
window.addEventListener('resize',()=>{if(!document.getElementById('coloringModal').classList.contains('hidden'))applyColorZoom(colorZoom)});
function undoColoring(){if(!colorHistory.length)return toast('Nada para desfazer 😊');ctx.putImageData(colorHistory.pop(),0,0)}
function clearCanvas(){if(baseTemplate)drawBase();else{ctx.fillStyle='white';ctx.fillRect(0,0,canvas.width,canvas.height)}toast('Desenho limpo!')}
function rewardArt(){const key='artReward'+new Date().toDateString();if(pget(key))return toast('Você já ganhou a estrela da pintura hoje 💗');pset(key,'1');addStars(1,'Pintura concluída! ⭐')}
function saveColoring(){const a=document.createElement('a');a.download='colorindo-com-a-elo.png';a.href=canvas.toDataURL('image/png');a.click();toast('Imagem pronta para salvar 💗')}


// ===== v2.1.2 • Escolinha da Elo — números visuais 3–5 =====
const ENGLISH_AGES={
 '3-5':{label:'3–5 anos',short:'Descobrir',desc:'Ouvir, ver e tocar',types:['listenKid']},
 '6-8':{label:'6–8 anos',short:'Praticar',desc:'Ouvir, ler e escrever',types:['listen','choose','write','scramble']},
 '9-11':{label:'9–11 anos',short:'Avançar',desc:'Escrita, frases e compreensão',types:['listen','write','sentence','translate']}
};
const ENGLISH_WORLDS={
 colors:{icon:'🎨',name:'Cores',medal:'Mestre das Cores',items:[
  {id:'red',en:'red',pt:'vermelho',emoji:'🔴',sentence:'The balloon is ___.'},{id:'blue',en:'blue',pt:'azul',emoji:'🔵',sentence:'The sky is ___.'},{id:'yellow',en:'yellow',pt:'amarelo',emoji:'🟡',sentence:'The sun is ___.'},{id:'green',en:'green',pt:'verde',emoji:'🟢',sentence:'The leaf is ___.'},{id:'pink',en:'pink',pt:'rosa',emoji:'🩷',sentence:'The bow is ___.'},{id:'purple',en:'purple',pt:'roxo',emoji:'🟣',sentence:'The flower is ___.'},{id:'orange',en:'orange',pt:'laranja',emoji:'🟠',sentence:'The pumpkin is ___.'},{id:'black',en:'black',pt:'preto',emoji:'⚫',sentence:'The cat is ___.'},{id:'white',en:'white',pt:'branco',emoji:'⚪',sentence:'The cloud is ___.'}
 ]},
 numbers:{icon:'🔢',name:'Números',medal:'Craque dos Números',items:[
  {id:'one',en:'one',pt:'um',emoji:'1️⃣',sentence:'I have ___ star.'},{id:'two',en:'two',pt:'dois',emoji:'2️⃣',sentence:'I have ___ pencils.'},{id:'three',en:'three',pt:'três',emoji:'3️⃣',sentence:'I see ___ cats.'},{id:'four',en:'four',pt:'quatro',emoji:'4️⃣',sentence:'There are ___ books.'},{id:'five',en:'five',pt:'cinco',emoji:'5️⃣',sentence:'I have ___ apples.'},{id:'six',en:'six',pt:'seis',emoji:'6️⃣',sentence:'There are ___ stars.'},{id:'seven',en:'seven',pt:'sete',emoji:'7️⃣',sentence:'I see ___ balloons.'},{id:'eight',en:'eight',pt:'oito',emoji:'8️⃣',sentence:'There are ___ flowers.'},{id:'nine',en:'nine',pt:'nove',emoji:'9️⃣',sentence:'I have ___ crayons.'},{id:'ten',en:'ten',pt:'dez',emoji:'🔟',sentence:'There are ___ hearts.'}
 ]},
 fruits:{icon:'🍓',name:'Frutas',medal:'Amiga das Frutas',items:[
  {id:'apple',en:'apple',pt:'maçã',emoji:'🍎',sentence:'I like ___.'},{id:'banana',en:'banana',pt:'banana',emoji:'🍌',sentence:'The ___ is yellow.'},{id:'strawberry',en:'strawberry',pt:'morango',emoji:'🍓',sentence:'This is a ___.'},{id:'orange-fruit',en:'orange',pt:'laranja',emoji:'🍊',sentence:'I eat an ___.'},{id:'grape',en:'grape',pt:'uva',emoji:'🍇',sentence:'This is a ___.'},{id:'watermelon',en:'watermelon',pt:'melancia',emoji:'🍉',sentence:'The ___ is big.'},{id:'pear',en:'pear',pt:'pera',emoji:'🍐',sentence:'This is a ___.'},{id:'pineapple',en:'pineapple',pt:'abacaxi',emoji:'🍍',sentence:'I like ___.'}
 ]},
 animals:{icon:'🐾',name:'Animais',medal:'Amiga dos Animais',items:[
  {id:'cat',en:'cat',pt:'gato',emoji:'🐱',sentence:'I see a ___.'},{id:'dog',en:'dog',pt:'cachorro',emoji:'🐶',sentence:'The ___ is happy.'},{id:'bird',en:'bird',pt:'pássaro',emoji:'🐦',sentence:'The ___ can fly.'},{id:'fish',en:'fish',pt:'peixe',emoji:'🐟',sentence:'The ___ can swim.'},{id:'lion',en:'lion',pt:'leão',emoji:'🦁',sentence:'I see a ___.'},{id:'monkey',en:'monkey',pt:'macaco',emoji:'🐵',sentence:'The ___ is funny.'},{id:'rabbit',en:'rabbit',pt:'coelho',emoji:'🐰',sentence:'The ___ can jump.'},{id:'turtle',en:'turtle',pt:'tartaruga',emoji:'🐢',sentence:'The ___ is slow.'}
 ]},
 greetings:{icon:'👋',name:'Saudações',medal:'Hello, Friend!',items:[
  {id:'hello',en:'hello',pt:'olá',emoji:'👋',sentence:'Say ___ when you meet a friend.'},{id:'goodbye',en:'goodbye',pt:'tchau',emoji:'👋',sentence:'Say ___ when you leave.'},{id:'please',en:'please',pt:'por favor',emoji:'🙏',sentence:'Say ___ when you ask politely.'},{id:'thank-you',en:'thank you',pt:'obrigado',emoji:'💗',sentence:'Say ___ when someone helps you.'},{id:'good-morning',en:'good morning',pt:'bom dia',emoji:'☀️',sentence:'Say ___ in the morning.'},{id:'good-night',en:'good night',pt:'boa noite',emoji:'🌙',sentence:'Say ___ before sleep.'},{id:'how-are-you',en:'how are you?',pt:'como você está?',emoji:'🙂',sentence:'Ask a friend: ___'},{id:'im-fine',en:"I'm fine",pt:'estou bem',emoji:'😊',sentence:'Answer: ___'}
 ]}
};
const ENGLISH_WORLD_ORDER=['colors','numbers','fruits','animals','greetings'];
const ENGLISH_COLOR_HEX={red:'#ef4444',blue:'#3b82f6',yellow:'#facc15',green:'#22c55e',pink:'#ff76b8',purple:'#8b5cf6',orange:'#f97316',black:'#1f2937',white:'#ffffff'};
const ENGLISH_NUMBER_VALUE={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
const ENGLISH_GREETING_VISUAL={'hello':'👋🙂','goodbye':'👋🚪','please':'🙏🙂','thank-you':'🎁💗','good-morning':'☀️😊','good-night':'🌙😴','how-are-you':'🙂❓','im-fine':'😊👍'};
function englishKidVisual(item,world=englishWorldId){if(world==='colors')return `<span class="kidColorSwatch" style="background:${ENGLISH_COLOR_HEX[item.id]||'#ddd'}"></span>`;if(world==='numbers'){const n=ENGLISH_NUMBER_VALUE[item.id]||1;return `<span class="kidNumberVisual">${n}</span>`}if(world==='greetings')return `<span class="kidVisualSeq">${ENGLISH_GREETING_VISUAL[item.id]||item.emoji}</span>`;return `<span class="kidChoiceEmoji">${item.emoji}</span>`}
let englishAge=getActiveProfile().ageRange||pget('englishAge')||'6-8',englishWorldId=null,englishSession=[],englishPos=0,englishCorrect=0,englishAnswered=false,englishMode='learn';
function englishProgressKey(age=englishAge){return `englishProgressV2:${age}`}
function getEnglishProgress(age=englishAge){try{if(pget('englishProgressV2Migrated')!=='1'){const old=pget('englishProgressV1'),target=getActiveProfile().ageRange||'6-8';if(old&&!pget(englishProgressKey(target)))pset(englishProgressKey(target),old);pset('englishProgressV2Migrated','1')}const raw=pget(englishProgressKey(age));const p=JSON.parse(raw||'{}');return Object.assign({mastery:{},completed:[],certificate:false},p)}catch(_){return{mastery:{},completed:[],certificate:false}}}
function saveEnglishProgress(v,age=englishAge){pset(englishProgressKey(age),JSON.stringify(v))}
function englishMasteryKey(world,item){return `${world}:${item}`}
function englishMastery(world,item,age=englishAge){const p=getEnglishProgress(age);return Math.min(3,Number(p.mastery[englishMasteryKey(world,item)]||0))}
function englishWorldPercent(id,age=englishAge){const w=ENGLISH_WORLDS[id],p=getEnglishProgress(age);const score=w.items.reduce((n,it)=>n+Math.min(3,Number(p.mastery[englishMasteryKey(id,it.id)]||0)),0);return Math.round(score/(w.items.length*3)*100)}
function englishOverallPercent(age=englishAge){return Math.round(ENGLISH_WORLD_ORDER.reduce((n,id)=>n+englishWorldPercent(id,age),0)/ENGLISH_WORLD_ORDER.length)}
function setEnglishAge(age){if(!ENGLISH_AGES[age])return;englishAge=age;pset('englishAge',age);const ps=loadProfiles(),p=ps.find(x=>x.id===activeProfileId);if(p){p.ageRange=age;saveProfiles(ps)}renderEnglishSchool();renderProfileManager();toast(`Atividades para ${ENGLISH_AGES[age].label} 💗`)}
function speakEnglish(txt,slow=false){if(!('speechSynthesis'in window))return toast('Este aparelho não oferece leitura em voz.');speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(txt);u.lang='en-US';u.rate=slow?.68:.78;u.pitch=1.04;speechSynthesis.speak(u)}
function speakEnglishItem(world,id){const it=ENGLISH_WORLDS[world]?.items.find(x=>x.id===id);if(it)speakEnglish(it.en)}
function repeatEnglishQuestion(){const q=englishSession[englishPos];if(q)speakEnglish(q.item.en,true)}
function openEnglishSchool(){trackActivity('english');openPanel('englishPanel','learn');englishWorldId=null;englishMode='home';renderEnglishSchool();showTutorialOnce('english-v220','Inglês da Elo 🇺🇸',['Escolha a faixa etária para adaptar as atividades.','De 3 a 5 anos, a criança ouve e toca nas figuras, cores e quantidades, sem precisar ler.','Para ouvir uma palavra novamente, basta tocar na própria cor, número, fruta, animal ou figura.','Nas faixas maiores entram leitura, escrita e frases.'])}
function renderEnglishHomeProgress(){const bar=document.getElementById('englishHomeProgress'),txt=document.getElementById('englishHomeProgressText'),pct=englishOverallPercent();if(bar)bar.style.width=pct+'%';if(txt)txt.textContent=pct+'%'}
function renderEnglishSchool(){renderEnglishHomeProgress();const root=document.getElementById('englishRoot');if(!root)return;if(englishWorldId&&englishMode!=='home')return renderEnglishWorld();const p=getEnglishProgress(),overall=englishOverallPercent(),kid=englishAge==='3-5';root.innerHTML=`<div class="englishHero"><h3>Aprenda inglês brincando 🌈</h3><p>${kid?'Para os pequenos: ouvir, ver e tocar. Sem precisar ler nas atividades.':'5 mundos iniciais com áudio, imagens, escrita e revisão.'} O progresso pertence ao perfil ${escapeHtml(getActiveProfile().name)}.</p><div class="ageGrid">${Object.entries(ENGLISH_AGES).map(([id,a])=>`<button class="ageBtn ${englishAge===id?'on':''}" onclick="setEnglishAge('${id}')">${a.label}<small>${a.desc}</small></button>`).join('')}</div><div class="engProgressWrap"><div class="engProgressTrack"><i style="width:${overall}%"></i></div><b>${overall}% dominado</b></div></div><div class="card"><h3>Escolha um mundo</h3><p class="muted">Cada palavra avança de Aprendendo → Praticando → Dominei.</p><div class="engWorldGrid">${ENGLISH_WORLD_ORDER.map(id=>{const w=ENGLISH_WORLDS[id],pct=englishWorldPercent(id),done=p.completed.includes(id);return `<button class="engWorld ${done?'done':''}" onclick="openEnglishWorld('${id}')"><span class="ewPct">${done?'🏅 ':''}${pct}%</span><span class="ewIcon">${w.icon}</span><b>${w.name}</b><small>${w.items.length} palavras e expressões</small><div class="miniProgress"><i style="width:${pct}%"></i></div></button>`}).join('')}</div></div><div class="card"><h3>Suas medalhas 🇺🇸</h3><div class="engMedalGrid">${renderEnglishMedalsHtml()}</div>${renderEnglishCertificateHtml()}</div>`}
function openEnglishWorld(id){if(!ENGLISH_WORLDS[id])return;englishWorldId=id;englishMode='learn';renderEnglishWorld()}
function closeEnglishWorld(){englishWorldId=null;englishMode='home';renderEnglishSchool()}
function masteryDots(n){return `${'●'.repeat(n)}${'○'.repeat(3-n)}`}
function masteryLabel(n){return n>=3?'Dominei':n===2?'Praticando':n===1?'Aprendendo':'Novo'}
function renderEnglishWorld(){const root=document.getElementById('englishRoot'),w=ENGLISH_WORLDS[englishWorldId];if(!root||!w)return;if(englishMode==='practice')return renderEnglishActivity();const kid=englishAge==='3-5';root.innerHTML=`<div class="card"><button class="smallBtn" onclick="closeEnglishWorld()">‹ Mundos</button><div class="engWorldHead" style="margin-top:12px"><div class="bigIcon">${w.icon}</div><div><h3>${w.name}</h3><p class="muted" style="margin:3px 0">${kid?'Toque nas figuras para ouvir.':'Toque em qualquer cartão para ouvir e repita em voz alta!'}</p></div></div><div class="engWordGrid">${w.items.map(it=>{const m=englishMastery(englishWorldId,it.id);if(kid)return `<button class="engWord kid" onclick="speakEnglishItem('${englishWorldId}','${it.id}')" aria-label="Ouvir ${escapeHtml(it.en)}">${englishKidVisual(it,englishWorldId)}</button>`;return `<button class="engWord" onclick="speakEnglishItem('${englishWorldId}','${it.id}')" aria-label="Ouvir ${escapeHtml(it.en)}"><span class="emoji">${it.emoji}</span><b>${escapeHtml(it.en)}</b><small>${escapeHtml(it.pt)}</small><div class="masteryDots">${masteryDots(m)} • ${masteryLabel(m)}</div></button>`}).join('')}</div><div class="engActions"><button class="btn" onclick="startEnglishPractice('${englishWorldId}',false)">🎮 ${kid?'▶️':'Praticar'}</button><button class="btn secondary" onclick="startEnglishPractice('${englishWorldId}',true)">🧠 ${kid?'⭐':'Revisão inteligente'}</button></div></div>`}
function englishWeakItems(id){const w=ENGLISH_WORLDS[id];return [...w.items].sort((a,b)=>englishMastery(id,a.id)-englishMastery(id,b.id)||Math.random()-.5)}
function startEnglishPractice(id,review=false){englishWorldId=id;englishMode='practice';englishCorrect=0;englishPos=0;englishAnswered=false;const w=ENGLISH_WORLDS[id],age=ENGLISH_AGES[englishAge];let items=review?englishWeakItems(id):shuffle(w.items);items=items.slice(0,Math.min(8,items.length));englishSession=items.map((it,i)=>({item:it,type:age.types[i%age.types.length]}));englishSession=shuffle(englishSession);renderEnglishActivity()}
function englishOptions(item,count=4){const w=ENGLISH_WORLDS[englishWorldId],others=shuffle(w.items.filter(x=>x.id!==item.id)).slice(0,Math.max(1,count-1));return shuffle([item,...others])}
function scrambleEnglish(s){const chars=s.replace(/[^a-zA-Z]/g,'').toUpperCase().split('');let out=shuffle(chars);if(out.join('')===chars.join('')&&out.length>2)out=[...out.slice(1),out[0]];return out.join(' ')}
function normalizeEnglish(s){return String(s||'').toLowerCase().trim().replace(/[’']/g,"'").replace(/[?.!,]/g,'').replace(/\s+/g,' ')}
function renderEnglishActivity(){const root=document.getElementById('englishRoot'),w=ENGLISH_WORLDS[englishWorldId];if(!root)return;if(englishPos>=englishSession.length)return finishEnglishPractice();const q=englishSession[englishPos],it=q.item;englishAnswered=false;let body='';if(englishAge==='3-5'){const opts=englishOptions(it,3);body=`<div class="kidListenHint"><button onclick="repeatEnglishQuestion()" aria-label="Ouvir novamente">👂</button></div><div class="engKidChoices">${opts.map(o=>`<button class="kidChoice" data-answer="${o.id}" onclick="answerEnglishChoice('${o.id}')" aria-label="Opção">${englishKidVisual(o,englishWorldId)}</button>`).join('')}</div>`;setTimeout(()=>repeatEnglishQuestion(),350)}else if(q.type==='listen'){body=`<div class="engPrompt"><span class="bigEmoji">🎧</span><h3>Ouça e escolha</h3><button class="engAudioBtn" onclick="repeatEnglishQuestion()">🔊 Ouvir novamente</button><p>Qual imagem combina com o que você ouviu?</p></div><div class="engChoices">${englishOptions(it).map(o=>`<button class="engChoice" data-answer="${o.id}" onclick="answerEnglishChoice('${o.id}')"><span class="choiceEmoji">${o.emoji}</span>${escapeHtml(o.en)}</button>`).join('')}</div>`;setTimeout(()=>speakEnglish(it.en,true),300)}else if(q.type==='choose'){body=`<div class="engPrompt"><button class="bigEmoji" style="border:0;background:transparent" onclick="repeatEnglishQuestion()">${it.emoji}</button><h3>Como se diz “${escapeHtml(it.pt)}” em inglês?</h3></div><div class="engChoices">${englishOptions(it).map(o=>`<button class="engChoice" data-answer="${o.id}" onclick="answerEnglishChoice('${o.id}')">${escapeHtml(o.en)}</button>`).join('')}</div>`}else if(q.type==='scramble'){body=`<div class="engPrompt"><button class="bigEmoji" style="border:0;background:transparent" onclick="repeatEnglishQuestion()">${it.emoji}</button><h3>Organize e escreva a palavra</h3><p>${escapeHtml(it.pt)}</p></div><div class="engScramble">${scrambleEnglish(it.en)}</div>${englishWriteBox()}`}else if(q.type==='sentence'){body=`<div class="engPrompt"><button class="bigEmoji" style="border:0;background:transparent" onclick="repeatEnglishQuestion()">${it.emoji}</button><h3>Complete a frase</h3><p style="font-size:18px;font-weight:800;color:var(--ink)">${escapeHtml(it.sentence)}</p></div>${englishWriteBox()}`}else if(q.type==='translate'){body=`<div class="engPrompt"><button class="bigEmoji" style="border:0;background:transparent" onclick="repeatEnglishQuestion()">${it.emoji}</button><h3>Escreva em inglês</h3><p style="font-size:18px">${escapeHtml(it.pt)}</p></div>${englishWriteBox()}`}else{body=`<div class="engPrompt"><button class="bigEmoji" style="border:0;background:transparent" onclick="repeatEnglishQuestion()">${it.emoji}</button><h3>Escreva em inglês</h3><p>${escapeHtml(it.pt)}</p></div>${englishWriteBox()}`};root.innerHTML=`<div class="card engActivity ${englishAge==='3-5'?'engKidMode':''}"><div class="engActivityTop"><button class="smallBtn" onclick="englishMode='learn';renderEnglishWorld()">✕ Sair</button><span class="engPill">${englishPos+1}/${englishSession.length}${englishAge==='3-5'?'':' • '+englishCorrect+' acertos'}</span></div>${body}<div id="engFeedback"></div></div>`;if(['write','scramble','sentence','translate'].includes(q.type)&&englishAge!=='3-5')setTimeout(()=>document.getElementById('englishAnswer')?.focus(),100)}
function englishWriteBox(){return `<div class="engWrite"><input id="englishAnswer" type="text" inputmode="text" autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="Escreva em inglês" onkeydown="if(event.key==='Enter')checkEnglishWrite()"><button class="btn" onclick="checkEnglishWrite()">OK</button></div>`}
function updateEnglishMastery(correct){const q=englishSession[englishPos],p=getEnglishProgress(),k=englishMasteryKey(englishWorldId,q.item.id);if(correct)p.mastery[k]=Math.min(3,Number(p.mastery[k]||0)+1);saveEnglishProgress(p)}
function answerEnglishChoice(id){if(englishAnswered)return;const q=englishSession[englishPos],ok=id===q.item.id;if(englishAge==='3-5'){const picked=document.querySelector(`.kidChoice[data-answer="${id}"]`);if(!ok){picked?.classList.add('bad');speakEnglish(q.item.en,true);setTimeout(()=>picked?.classList.remove('bad'),650);return}englishAnswered=true;document.querySelectorAll('.kidChoice').forEach(b=>{b.disabled=true;if(b.dataset.answer===q.item.id)b.classList.add('good')});finishEnglishQuestion(true);return}englishAnswered=true;document.querySelectorAll('.engChoice').forEach(b=>{b.disabled=true;if(b.dataset.answer===q.item.id)b.classList.add('good');else if(b.dataset.answer===id&&!ok)b.classList.add('bad')});finishEnglishQuestion(ok)}
function checkEnglishWrite(){if(englishAnswered)return;const q=englishSession[englishPos],input=document.getElementById('englishAnswer');if(!input||!input.value.trim())return toast('Escreva uma resposta 😊');englishAnswered=true;input.disabled=true;const ok=normalizeEnglish(input.value)===normalizeEnglish(q.item.en);finishEnglishQuestion(ok)}
function finishEnglishQuestion(ok){const q=englishSession[englishPos];if(ok){englishCorrect++;updateEnglishMastery(true);speakEnglish(q.item.en);if(englishAge==='3-5'){const f=document.getElementById('engFeedback');if(f)f.innerHTML='<div class="kidFeedback">⭐✅</div>';renderEnglishHomeProgress();setTimeout(()=>{if(englishAnswered)nextEnglishQuestion()},950);return}showEnglishFeedback(true,`Great! ${q.item.en} ⭐`);renderEnglishHomeProgress();setTimeout(()=>{if(englishAnswered)nextEnglishQuestion()},900);return}else{updateEnglishMastery(false);speakEnglish(q.item.en,true);showEnglishFeedback(false,`Quase! A resposta é “${q.item.en}”.`)}renderEnglishHomeProgress()}
function showEnglishFeedback(ok,msg){const f=document.getElementById('engFeedback');if(!f)return;f.innerHTML=`<div class="engFeedback ${ok?'ok':'no'}">${escapeHtml(msg)}</div>${ok?'<div class="engAutoNext">Próxima automaticamente…</div>':`<button class="btn engNext" onclick="nextEnglishQuestion()">${englishPos===englishSession.length-1?'Ver resultado':'Próxima →'}</button>`}`}
function nextEnglishQuestion(){englishPos++;englishAnswered=false;renderEnglishActivity()}
function finishEnglishPractice(){const root=document.getElementById('englishRoot'),p=getEnglishProgress(),passed=englishCorrect>=Math.ceil(englishSession.length*.7),first=!p.completed.includes(englishWorldId);if(passed&&!p.completed.includes(englishWorldId))p.completed.push(englishWorldId);if(passed&&first){addStars(3,`${ENGLISH_WORLDS[englishWorldId].medal}! +3 ⭐`)}if(p.completed.length>=ENGLISH_WORLD_ORDER.length&&!p.certificate){p.certificate=true;addStars(5,`Inglês ${ENGLISH_AGES[englishAge].label} concluído! +5 ⭐`)}saveEnglishProgress(p);renderBadges();renderV2Album();if(englishAge==='3-5'){root.innerHTML=`<div class="card engEnd"><div style="font-size:72px">${passed?'🏅⭐':'💗🌈'}</div><div class="score">${englishCorrect}/${englishSession.length}</div><div class="engActions"><button class="btn" style="font-size:30px" onclick="startEnglishPractice('${englishWorldId}',true)" aria-label="Jogar novamente">🔁</button><button class="btn secondary" style="font-size:30px" onclick="closeEnglishWorld()" aria-label="Voltar aos mundos">🏠</button></div></div>`;if(typeof speakText==='function')setTimeout(()=>speakText(passed?'Muito bem! Você terminou a atividade.':'Muito bem por tentar! Vamos brincar mais uma vez.'),150);renderEnglishHomeProgress();return}root.innerHTML=`<div class="card engEnd"><span style="font-size:52px">${passed?'🏅':'💗'}</span><div class="score">${englishCorrect}/${englishSession.length}</div><h3>${passed?'Muito bem!':'Vamos praticar mais um pouco!'}</h3><p class="muted">${passed?`Você concluiu ${ENGLISH_WORLDS[englishWorldId].name}. Continue praticando para dominar todas as palavras.`:'Use a Revisão Inteligente para treinar as palavras que ainda estão difíceis.'}</p><div class="engActions"><button class="btn" onclick="startEnglishPractice('${englishWorldId}',true)">🧠 Revisar</button><button class="btn secondary" onclick="englishMode='learn';renderEnglishWorld()">📖 Palavras</button></div><button class="smallBtn" style="margin-top:12px" onclick="closeEnglishWorld()">← Voltar aos mundos</button></div>`;renderEnglishHomeProgress()}
function renderEnglishMedalsHtml(age=englishAge){const p=getEnglishProgress(age);return ENGLISH_WORLD_ORDER.map(id=>{const w=ENGLISH_WORLDS[id],on=p.completed.includes(id);return `<div class="engMedal ${on?'on':''}"><span>${on?w.icon:'🔒'}</span><b>${w.name}</b></div>`}).join('')}
function renderEnglishCertificateHtml(age=englishAge){const p=getEnglishProgress(age),label=ENGLISH_AGES[age]?.label||age;return p.certificate?`<div class="engCertificate"><span style="font-size:32px">🏆</span><strong>Inglês da Elo — ${label}</strong><small>${escapeHtml(getActiveProfile().name)} completou Cores, Números, Frutas, Animais e Saudações nesta faixa.</small></div>`:''}
function renderEnglishAlbum(){const m=document.getElementById('englishAlbumMedals'),c=document.getElementById('englishAlbumCertificate');if(m)m.innerHTML=Object.keys(ENGLISH_AGES).map(age=>`<div class="engAgeCollection"><h4>${ENGLISH_AGES[age].label}</h4><div class="engMedalGrid">${renderEnglishMedalsHtml(age)}</div>${renderEnglishCertificateHtml(age)}</div>`).join('');if(c)c.innerHTML='';renderEnglishHomeProgress()}
function englishAchievementCount(){return Object.keys(ENGLISH_AGES).reduce((sum,age)=>{const p=getEnglishProgress(age);return sum+p.completed.length+(p.certificate?1:0)},0)}
// ===== fim v2.1.1 Inglês =====

const ACH=[
 {icon:'⭐',name:'Primeira estrela',ok:()=>stars>=1},
 {icon:'🌈',name:'Exploradora',ok:()=>stars>=10},
 {icon:'👑',name:'Super Elo',ok:()=>stars>=25},
 {icon:'📚',name:'Leitora de Aventuras',ok:()=>readStories.length>=1},
 {icon:'🏆',name:'Mestre das Aventuras',ok:()=>readStories.length>=4},
 {icon:'🎨',name:'Artista do dia',ok:()=>!!pget('artReward'+new Date().toDateString())},
 {icon:'🧠',name:'Craque da Escolinha',ok:()=>stars>=40},
 {icon:'💗',name:'Missão do dia',ok:()=>!!pget(dailyKey)}
];
function renderBadges(){const baseUnlocked=ACH.filter(x=>x.ok()).length,medalUnlocked=MEDAL_GAMES.reduce((n,g)=>n+['easy','medium','hard'].filter(level=>hasGameMedal(g.id,level)).length,0),rpgUnlocked=getRpgMedals().length,englishUnlocked=englishAchievementCount(),unlocked=baseUnlocked+medalUnlocked+rpgUnlocked+englishUnlocked,total=ACH.length+MEDAL_GAMES.length*3+RPG_MEDALS.length+18;const html=ACH.map(x=>`<div class="badge ${x.ok()?'on':''}"><span>${x.icon}</span><strong>${x.name}</strong><small>${x.ok()?'Conquistada!':'Continue brincando'}</small></div>`).join('');const all=document.getElementById('allBadges');if(all)all.innerHTML=html;renderGameMedals();renderRpgMedals();renderEnglishAlbum();const home=document.getElementById('achievementCountHome');if(home)home.textContent=unlocked;const u=document.getElementById('achievementUnlocked');if(u)u.textContent=unlocked;const t=document.getElementById('achievementTotal');if(t)t.textContent=total}
function renderV2Album(){const p=getActiveProfile(),name=document.getElementById('albumProfileName'),avatar=document.getElementById('albumAvatar');if(name)name.textContent=p.name;if(avatar)avatar.textContent=p.avatar;const st=document.getElementById('albumStars');if(st)st.textContent=stars;const sr=document.getElementById('albumStories');if(sr)sr.textContent=readStories.length;let lvl=1;try{const s=JSON.parse(pget('eloRpgSaveV1')||'null');if(s?.level)lvl=s.level}catch(_){}const rl=document.getElementById('albumRpgLevel');if(rl)rl.textContent=lvl;const gm=MEDAL_GAMES.reduce((n,g)=>n+['easy','medium','hard'].filter(l=>hasGameMedal(g.id,l)).length,0)+getRpgMedals().length+englishAchievementCount();const am=document.getElementById('albumMedals');if(am)am.textContent=gm;renderEnglishAlbum()}


document.querySelectorAll('[data-app-version]').forEach(el=>el.textContent=APP_VERSION);
[setupAppHistory, renderStars, renderStoryStrip, renderLibrary, renderPlaylists, ()=>startQuiz('easy'), startMemory, renderPalette, renderColoringGallery, ()=>chooseColoring(0), renderBadges, renderEnglishHomeProgress].forEach(fn=>{ try{ fn(); }catch(e){ console.warn(e); } });
function dismissAppSplash(){
  const s = document.getElementById('splash');
  if(s){
    s.style.opacity = '0';
    s.style.pointerEvents = 'none';
    setTimeout(()=>{ try{ s.remove(); }catch(_){} }, 450);
  }
}
window.addEventListener('load', ()=>setTimeout(dismissAppSplash, 350));
if(document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(dismissAppSplash, 500);
setTimeout(dismissAppSplash, 1200);
if('serviceWorker' in navigator){
  navigator.serviceWorker.addEventListener('controllerchange',()=>{
    if(!sessionStorage.getItem('elo-reloaded-'+APP_VERSION)){
      sessionStorage.setItem('elo-reloaded-'+APP_VERSION,'1');
      location.reload();
    }
  });
  navigator.serviceWorker.register('./sw.js?v='+encodeURIComponent(APP_VERSION),{updateViaCache:'none'}).then(r=>r.update()).catch(()=>{});
}

window.addEventListener('DOMContentLoaded',()=>{applyA11y();renderProfileManager();renderParentV2();renderV2Album()});


// ==========================================================
// FILTRO E DESTAQUE STREAMING DO CINEMA DA ELO
// ==========================================================
window.cinemaFilterCategory = function(cat, btn){
  document.querySelectorAll('.streamingChip').forEach(c => c.classList.remove('active'));
  if(btn) btn.classList.add('active');
  const shelves = document.querySelectorAll('#cinemaShelves .cinemaShelf');
  shelves.forEach(shelf => {
    if(cat === 'all'){
      shelf.style.display = '';
    } else if(cat === 'shorts'){
      shelf.style.display = shelf.classList.contains('shortShelf') ? '' : 'none';
    } else if(cat === 'adventures'){
      const title = (shelf.querySelector('h3')?.textContent || '').toLowerCase();
      shelf.style.display = (title.includes('aventura') || title.includes('jogo') || title.includes('reino') || title.includes('história')) ? '' : 'none';
    } else if(cat === 'music'){
      const title = (shelf.querySelector('h3')?.textContent || '').toLowerCase();
      shelf.style.display = (title.includes('música') || title.includes('clipe') || title.includes('canção')) ? '' : 'none';
    } else if(cat === 'school'){
      const title = (shelf.querySelector('h3')?.textContent || '').toLowerCase();
      shelf.style.display = (title.includes('escolinha') || title.includes('aprender') || title.includes('inglês') || title.includes('desafio')) ? '' : 'none';
    }
  });
};


// Efeito de confetes e partículas estelares comemorativas
window.triggerStarConfetti = function(x, y){
  const symbols = ['⭐', '✨', '💖', '🎉', '🌟'];
  const colors = ['#ff68a7', '#ffd554', '#79d8f6', '#b58ef7', '#73e2a7'];
  const ox = x || window.innerWidth / 2;
  const oy = y || (window.innerHeight * 0.38);
  for(let i=0; i<18; i++){
    const p = document.createElement('span');
    p.className = 'confettiStarParticle';
    p.textContent = symbols[i % symbols.length];
    p.style.left = ox + 'px';
    p.style.top = oy + 'px';
    const a = (Math.PI * 2 * i) / 18 + (Math.random() * 0.3);
    const d = 55 + Math.random() * 95;
    const tx = Math.cos(a) * d;
    const ty = Math.sin(a) * d - 30;
    p.style.setProperty('--tx', `${tx}px`);
    p.style.setProperty('--ty', `${ty}px`);
    p.style.color = colors[i % colors.length];
    document.body.appendChild(p);
    setTimeout(() => p.remove(), 950);
  }
};


// ==========================================================
// v3.6.0 — MODERNIZAÇÃO TOTAL: HUB, ESCOLINHA, FAMÍLIA & ATELIÊ
// ==========================================================

// --- 0. SISTEMA DE ÁUDIO WEB AUDIO API (SONS, PIANO E ANIMAIS) ---
let audioFxCtx = null;
function getAudioFxCtx(){
  if(!audioFxCtx){
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if(AC) audioFxCtx = new AC();
    } catch(_) {}
  }
  if(audioFxCtx && audioFxCtx.state === "suspended"){
    try { audioFxCtx.resume(); } catch(_) {}
  }
  return audioFxCtx;
}

window.playCuteSfx = function(type){
  if("vibrate" in navigator){
    try {
      if(type === "coin") navigator.vibrate([18, 28, 18]);
      else if(type === "win") navigator.vibrate([25, 45, 35]);
      else if(type === "wrong") navigator.vibrate(40);
      else navigator.vibrate(10);
    } catch(_) {}
  }
  const ctx = getAudioFxCtx();
  if(!ctx) return;
  const now = ctx.currentTime;
  try {
    if(type === "pop"){
      const osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(480, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.07);
      g.gain.setValueAtTime(0.04, now);
      g.gain.linearRampToValueAtTime(0.0001, now + 0.075);
      osc.connect(g); g.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.08);
    } else if(type === "tick"){
      const osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(820, now);
      g.gain.setValueAtTime(0.04, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
      osc.connect(g); g.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.06);
    } else if(type === "wrong"){
      const osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.linearRampToValueAtTime(160, now + 0.18);
      g.gain.setValueAtTime(0.04, now);
      g.gain.linearRampToValueAtTime(0.0001, now + 0.19);
      osc.connect(g); g.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.2);
    } else if(type === "coin"){
      const osc = ctx.createOscillator(), g = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(988, now);
      osc.frequency.setValueAtTime(1318, now + 0.07);
      g.gain.setValueAtTime(0.06, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);
      osc.connect(g); g.connect(ctx.destination);
      osc.start(now); osc.stop(now + 0.29);
    } else if(type === "win"){
      [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
        const osc = ctx.createOscillator(), g = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);
        g.gain.setValueAtTime(0.06, now + idx * 0.07);
        g.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.07 + 0.24);
        osc.connect(g); g.connect(ctx.destination);
        osc.start(now + idx * 0.07); osc.stop(now + idx * 0.07 + 0.25);
      });
    }
  } catch(_) {}
};

// --- 1. MODAL HUB DO CANTINHO DA ELO ---
window.openEloHubModal = function(){
  const m = document.getElementById("eloHubModal");
  if(m){
    m.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    playCuteSfx("pop");
    if(typeof eloGuideSay === "function"){
      eloGuideSay("Bem-vinda ao meu Cantinho! Escolha o Quarto, o Guarda-roupa ou o Bichinho Virtual.");
    }
  }
};
window.closeEloHubModal = function(){
  const m = document.getElementById("eloHubModal");
  if(m){
    m.classList.add("hidden");
    document.body.style.overflow = "";
  }
};

// --- 2. FESTA DA FAMÍLIA (MÍMICA, DUELO 2 JOGADORES & ROLETA/PLACAR) ---
let familyActiveMode = "mime";
let mimeTimer = null, mimeSecondsLeft = 45, currentMimeCategory = "animals";
let duelActive = false, duelCurrentChallenge = null, duelP1Points = 0, duelP2Points = 0, duelRoundTimeout = null;
let team1Pts = 0, team2Pts = 0;

const MODERN_MIMES = {
  animals: [
    "Macaco descascando e comendo banana 🍌",
    "Pinguim andando no gelo escorregadio ❄️",
    "Elefante tomando banho com a tromba 🐘",
    "Gatinho acordando e se espreguiçando 🐱",
    "Leão rugindo bem forte na floresta 🦁",
    "Sapinho pulando para pegar mosca 🐸",
    "Cachorrinho correndo atrás do próprio rabo 🐶",
    "Galinha ciscando e botando ovo 🐔",
    "Borboleta voando de flor em flor 🦋",
    "Jacaré abrindo o bocão no rio 🐊"
  ],
  actions: [
    "Escovando os dentes com muita espuma 🪥",
    "Andando de skate e fazendo manobra 🛹",
    "Comendo uma fatia gigante de melancia 🍉",
    "Dançando balé na ponta do pé 🩰",
    "Tocando bateria em um show de rock 🥁",
    "Pescando um peixe muito pesado 🎣",
    "Fazendo um bolo e batendo a massa 🎂",
    "Tentando caminhar contra um vento forte 💨",
    "Pulando corda bem rápido 🪢",
    "Tomando um sorvete que está derretendo 🍦"
  ],
  characters: [
    "Robô ficando sem bateria 🤖",
    "Princesa procurando a coroa perdida 👑",
    "Super-herói voando acima das nuvens 🦸",
    "Pirata procurando tesouro com luneta 🏴‍☠️",
    "Mago fazendo um feitiço com varinha 🧙",
    "Astronauta caminhando sem gravidade na Lua 🚀",
    "Unicórnio galopando pelo arco-íris 🦄",
    "Fada espalhando pó de estrelas ✨",
    "Chef de cozinha fazendo pizza girando a massa 🍕",
    "Detetive seguindo pegadas com lupa 🔎"
  ],
  mix: [
    "Dinossauro T-Rex tentando bater palmas 🦖",
    "Pintando um quadro gigante colorido 🎨",
    "Segurando 10 bexigas que querem voar 🎈",
    "Andando em uma montanha-russa maluca 🎢",
    "Tocando violão e cantando no microfone 🎸",
    "Abrindo um presente cheio de surpresas 🎁",
    "Fazendo embaixadinha com bola de futebol ⚽",
    "Mergulhando no fundo do mar com peixinhos 🤿"
  ]
};

window.switchFamilyMode = function(mode, btn){
  familyActiveMode = mode;
  document.querySelectorAll(".familyTabBtn").forEach(b => b.classList.remove("active"));
  if(btn){
    btn.classList.add("active");
  } else {
    const targetBtn = document.querySelector(`.familyTabBtn[onclick*="'${mode}'"]`);
    if(targetBtn) targetBtn.classList.add("active");
  }
  const mimeEl = document.getElementById("familyMimeView");
  const duelEl = document.getElementById("familyDuelView");
  const scoreEl = document.getElementById("familyScoreView");
  if(mimeEl) mimeEl.classList.toggle("hidden", mode !== "mime");
  if(duelEl) duelEl.classList.toggle("hidden", mode !== "duel");
  if(scoreEl) scoreEl.classList.toggle("hidden", mode !== "score");

  if(mode !== "mime" && mimeTimer){ clearInterval(mimeTimer); mimeTimer = null; }
  if(mode === "duel"){ startDuelRound(); }
  if(mode === "mime"){ resetMimeCard(); }
};

window.setMimeCat = function(cat, btn){
  currentMimeCategory = cat;
  document.querySelectorAll(".mimeCategoryPills .pillBtn").forEach(b => b.classList.remove("on"));
  if(btn) btn.classList.add("on");
  resetMimeCard();
};

function resetMimeCard(){
  if(mimeTimer){ clearInterval(mimeTimer); mimeTimer = null; }
  mimeSecondsLeft = 45;
  const tDisp = document.getElementById("mimeTimerDisplay");
  if(tDisp) tDisp.textContent = "⏱️ 45s";
  const box = document.getElementById("mimeCardBox");
  if(box){
    box.innerHTML = `<div class="mimeHiddenPrompt">
      <span style="font-size:52px;display:block;margin-bottom:8px;">🙈</span>
      <h3>Vez do mímico!</h3>
      <p>Apenas quem vai fazer a mímica deve olhar a tela agora.</p>
      <button class="btn mainBtn" onclick="startMimeRound()">Revelar e Iniciar Cronômetro! ⏱️</button>
    </div>`;
  }
}

window.startMimeRound = function(){
  const pool = MODERN_MIMES[currentMimeCategory] || MODERN_MIMES.animals;
  const picked = pool[Math.floor(Math.random() * pool.length)];
  const box = document.getElementById("mimeCardBox");
  if(!box) return;
  playCuteSfx("pop");

  box.innerHTML = `<div class="mimeActiveCard">
    <small style="color:var(--muted);font-weight:900;">FAÇA SEM FALAR UMA PALAVRA:</small>
    <div class="mimePromptText">${picked}</div>
    <div style="font-size:12px;color:#d84376;margin-bottom:12px;">Esconda a tela e comece a mímica!</div>
    <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
      <button class="btn" style="background:#00d288;color:#fff;font-weight:900;" onclick="mimeSuccess()">Acertaram! (+1 Ponto & ⭐) 🎉</button>
      <button class="btn secondary" onclick="startMimeRound()">Outro Desafio 🎲</button>
    </div>
  </div>`;

  mimeSecondsLeft = 45;
  const tDisp = document.getElementById("mimeTimerDisplay");
  if(tDisp) tDisp.textContent = "⏱️ 45s";
  if(mimeTimer) clearInterval(mimeTimer);
  mimeTimer = setInterval(()=>{
    mimeSecondsLeft--;
    const td = document.getElementById("mimeTimerDisplay");
    if(td) td.textContent = `⏱️ ${mimeSecondsLeft}s`;
    if(mimeSecondsLeft <= 15 && mimeSecondsLeft > 0) playCuteSfx("tick");
    if(mimeSecondsLeft <= 0){
      clearInterval(mimeTimer);
      mimeTimer = null;
      playCuteSfx("wrong");
      box.innerHTML = `<div class="mimeActiveCard">
        <span style="font-size:46px;">⏰</span>
        <h3>O tempo acabou!</h3>
        <p>A resposta era: <b>${picked}</b></p>
        <button class="btn" onclick="startMimeRound()">Próxima Mímica 🎲</button>
      </div>`;
    }
  }, 1000);
};

window.mimeSuccess = function(){
  if(mimeTimer){ clearInterval(mimeTimer); mimeTimer = null; }
  playCuteSfx("win");
  triggerStarConfetti();
  changeTeamScore(1, 1);
  addStars(1, "Mímica acertada em família! +1 ⭐");
  resetMimeCard();
};

// --- DUELO 2 JOGADORES COM 3 OPÇÕES DE REFLEXO ---
const DUEL_CHALLENGES = [
  { cmd: "Toque na ESTRELA ⭐!", target: "⭐", options: ["⭐", "🌙", "☁️"] },
  { cmd: "Toque no UNICÓRNIO 🦄!", target: "🦄", options: ["🐱", "🦄", "🐰"] },
  { cmd: "Toque no CORAÇÃO 💖!", target: "💖", options: ["💎", "💖", "🌸"] },
  { cmd: "Quanto é 2 + 3? Toque no 5!", target: "5", options: ["4", "5", "6"] },
  { cmd: "Quanto é 1 + 2? Toque no 3!", target: "3", options: ["2", "3", "5"] },
  { cmd: "Qual bicho faz MIAU? 🐱", target: "🐱", options: ["🐶", "🐱", "🐸"] },
  { cmd: "Qual fruta é VERMELHA? 🍓", target: "🍓", options: ["🍌", "🍓", "🍐"] },
  { cmd: "Toque no FOGUETE 🚀!", target: "🚀", options: ["🚗", "⛵", "🚀"] },
  { cmd: "Toque no ARCO-ÍRIS 🌈!", target: "🌈", options: ["🌈", "⚡", "❄️"] },
  { cmd: "Qual começa com A? ABELHA 🐝!", target: "🐝", options: ["🐝", "🐢", "🦁"] },
  { cmd: "Toque na COROA 👑!", target: "👑", options: ["🎩", "👑", "🎀"] },
  { cmd: "Quanto é 4 + 4? Toque no 8!", target: "8", options: ["6", "8", "9"] }
];

window.resetDuelMatch = function(){
  duelP1Points = 0;
  duelP2Points = 0;
  const s1 = document.getElementById("duelP1Score");
  const s2 = document.getElementById("duelP2Score");
  if(s1) s1.textContent = "0";
  if(s2) s2.textContent = "0";
  startDuelRound();
};

window.startDuelRound = function(){
  duelActive = false;
  if(duelRoundTimeout) clearTimeout(duelRoundTimeout);
  const cmdEl = document.getElementById("duelCenterCommand");
  const p1El = document.getElementById("duelP1Prompt");
  const p2El = document.getElementById("duelP2Prompt");
  if(cmdEl) cmdEl.textContent = "Preparem os dedos... ⏳";
  if(p1El) p1El.innerHTML = "<div class='duelWait'>⏳ Atenção...</div>";
  if(p2El) p2El.innerHTML = "<div class='duelWait'>⏳ Atenção...</div>";

  duelRoundTimeout = setTimeout(()=>{
    const c = DUEL_CHALLENGES[Math.floor(Math.random() * DUEL_CHALLENGES.length)];
    duelCurrentChallenge = c;
    duelActive = true;
    playCuteSfx("pop");
    if(cmdEl) cmdEl.textContent = c.cmd;
    const opts1 = shuffle(c.options);
    const opts2 = shuffle(c.options);
    if(p1El){
      p1El.innerHTML = opts1.map(o => `<button class="duelChoiceBtn" onclick="handleDuelChoice(1, '${o}', this)">${o}</button>`).join("");
    }
    if(p2El){
      p2El.innerHTML = opts2.map(o => `<button class="duelChoiceBtn" onclick="handleDuelChoice(2, '${o}', this)">${o}</button>`).join("");
    }
  }, 700);
};

window.handleDuelChoice = function(player, choice, btn){
  if(!duelActive || !duelCurrentChallenge) return;
  if(choice !== duelCurrentChallenge.target){
    playCuteSfx("wrong");
    if(btn){
      btn.disabled = true;
      btn.style.opacity = "0.35";
    }
    toast(`Jogador ${player} errou! Cuidado!`);
    return;
  }
  duelActive = false;
  playCuteSfx("win");
  triggerStarConfetti();
  if(player === 1){
    duelP1Points++;
    const s1 = document.getElementById("duelP1Score");
    if(s1) s1.textContent = duelP1Points;
    const a1 = document.getElementById("duelP1Area");
    if(a1){ a1.classList.add("winPulse"); setTimeout(()=>a1.classList.remove("winPulse"), 650); }
  } else {
    duelP2Points++;
    const s2 = document.getElementById("duelP2Score");
    if(s2) s2.textContent = duelP2Points;
    const a2 = document.getElementById("duelP2Area");
    if(a2){ a2.classList.add("winPulse"); setTimeout(()=>a2.classList.remove("winPulse"), 650); }
  }
  const cmdEl = document.getElementById("duelCenterCommand");
  if(duelP1Points >= 5 || duelP2Points >= 5){
    const winP = duelP1Points >= 5 ? 1 : 2;
    if(cmdEl) cmdEl.textContent = `🏆 JOGADOR ${winP} VENCEU O DUELO DE 5 PONTOS! 🎉`;
    addStars(3, `Duelo vencido pelo Jogador ${winP}! +3 ⭐`);
    duelP1Points = 0; duelP2Points = 0;
    setTimeout(()=>{
      const s1 = document.getElementById("duelP1Score");
      const s2 = document.getElementById("duelP2Score");
      if(s1) s1.textContent = "0";
      if(s2) s2.textContent = "0";
      startDuelRound();
    }, 2200);
  } else {
    if(cmdEl) cmdEl.textContent = `⚡ Ponto para o Jogador ${player}! Próxima rodada...`;
    setTimeout(startDuelRound, 1300);
  }
};
window.handleDuelTouch = function(player){
  if(duelCurrentChallenge) handleDuelChoice(player, duelCurrentChallenge.target, null);
};

// --- ROLETA DE DESAFIOS DA FAMÍLIA & PLACAR ---
const FAMILY_ROULETTE_CHALLENGES = [
  "🤗 Desafio do Abraço: Todo mundo dá um abraço coletivo de 10 segundos!",
  "🦩 Desafio do Flamingo: Quem consegue ficar num pé só sem mexer por 15 segundos?",
  "🐸 Desafio dos Bichos: Cada pessoa imita o som de um animal diferente!",
  "💃 Dança Congelada: Dancem por 10 segundos e façam pose de estátua quando alguém bater palma!",
  "😂 Desafio do Riso: Olhem olho no olho sem rir! Quem rir primeiro faz uma careta!",
  "🎵 Show de Talentos: Cantem juntos um pedacinho da música favorita da criança!",
  " compliments 💖 Rodada do Carinho: Diga uma coisa que você admira em quem está ao seu lado!",
  "🚀 Missão Relâmpago: Encontrem 3 objetos azuis na sala sem correr!"
];

window.spinFamilyRoulette = function(){
  const el = document.getElementById("familyRouletteText");
  if(!el) return;
  let spins = 0;
  const iv = setInterval(()=>{
    playCuteSfx("tick");
    el.textContent = FAMILY_ROULETTE_CHALLENGES[spins % FAMILY_ROULETTE_CHALLENGES.length];
    spins++;
    if(spins >= 10){
      clearInterval(iv);
      const picked = FAMILY_ROULETTE_CHALLENGES[Math.floor(Math.random() * FAMILY_ROULETTE_CHALLENGES.length)].replace(" compliments ", "");
      el.textContent = picked;
      playCuteSfx("win");
      triggerStarConfetti();
      if(typeof speakText === "function") speakText(picked);
    }
  }, 90);
};

window.changeTeamScore = function(team, delta){
  playCuteSfx("pop");
  if(team === 1){
    team1Pts = Math.max(0, team1Pts + delta);
    const el = document.getElementById("team1Score");
    if(el) el.textContent = team1Pts;
  } else {
    team2Pts = Math.max(0, team2Pts + delta);
    const el = document.getElementById("team2Score");
    if(el) el.textContent = team2Pts;
  }
};

window.resetTeamScores = function(){
  team1Pts = 0; team2Pts = 0;
  const t1 = document.getElementById("team1Score");
  const t2 = document.getElementById("team2Score");
  if(t1) t1.textContent = "0";
  if(t2) t2.textContent = "0";
  toast("Placar zerado!");
};

window.finishFamilyMatch = function(){
  playCuteSfx("win");
  triggerStarConfetti();
  addStars(3, "Festa da Família concluída! +3 ⭐");
  const winner = team1Pts > team2Pts ? "Time Crianças venceu!" : (team2Pts > team1Pts ? "Time Adultos venceu!" : "Empate lindo entre toda a família!");
  toast(`🏆 ${winner} Parabéns pela diversão!`);
};

// --- 3. NOVA ESCOLINHA MÁGICA + BANCO DE 75 PERGUNTAS COM RESPOSTAS EMBARALHADAS ---
let activeSchoolTrack = "letters", currentSchoolQuestionIdx = 0, schoolTrackScore = 0, activeSchoolDeck = [];
let currentModernSchoolChoices = window.currentModernSchoolChoices = []; // Armazena as opções embaralhadas da pergunta atual

const SCHOOL_TRACK_DATA = window.SCHOOL_TRACK_DATA = {
  letters: [
    { prompt: "Qual letrinha começa a palavra BOLA?", options: ["B", "M", "P"], answer: 0, visual: "⚽" },
    { prompt: "Qual letrinha começa a palavra ESTRELA?", options: ["A", "E", "O"], answer: 1, visual: "⭐" },
    { prompt: "Qual letrinha começa a palavra GATO?", options: ["C", "G", "T"], answer: 1, visual: "🐱" },
    { prompt: "Qual letrinha começa a palavra CASA?", options: ["C", "S", "D"], answer: 0, visual: "🏠" },
    { prompt: "Qual letrinha começa a palavra UNICÓRNIO?", options: ["I", "U", "E"], answer: 1, visual: "🦄" },
    { prompt: "Qual letrinha começa a palavra PATO?", options: ["P", "B", "T"], answer: 0, visual: "🦆" },
    { prompt: "Qual letrinha começa a palavra ABELHA?", options: ["A", "O", "E"], answer: 0, visual: "🐝" },
    { prompt: "Qual letrinha começa a palavra DADO?", options: ["D", "B", "P"], answer: 0, visual: "🎲" },
    { prompt: "Qual letrinha começa a palavra MACACO?", options: ["M", "N", "W"], answer: 0, visual: "🐵" },
    { prompt: "Qual letrinha começa a palavra SAPO?", options: ["S", "C", "Z"], answer: 0, visual: "🐸" },
    { prompt: "Qual letrinha começa a palavra URSO?", options: ["U", "O", "V"], answer: 0, visual: "🐻" },
    { prompt: "Qual letrinha começa a palavra LEÃO?", options: ["L", "I", "T"], answer: 0, visual: "🦁" },
    { prompt: "Qual letrinha começa a palavra PEIXE?", options: ["P", "Q", "B"], answer: 0, visual: "🐟" },
    { prompt: "Qual letrinha começa a palavra FADA?", options: ["F", "T", "P"], answer: 0, visual: "🧚" },
    { prompt: "Qual letrinha começa a palavra MAÇÃ?", options: ["M", "N", "A"], answer: 0, visual: "🍎" },
    { prompt: "Qual letrinha começa a palavra PIPOCA?", options: ["P", "B", "D"], answer: 0, visual: "🍿" },
    { prompt: "Qual letrinha começa a palavra JANELA?", options: ["J", "G", "I"], answer: 0, visual: "🪟" },
    { prompt: "Qual letrinha começa a palavra BORBOLETA?", options: ["B", "P", "D"], answer: 0, visual: "🦋" },
    { prompt: "Qual letrinha começa a palavra TARTARUGA?", options: ["T", "D", "L"], answer: 0, visual: "🐢" },
    { prompt: "Qual letrinha termina com o som de FLOR?", options: ["R", "L", "S"], answer: 0, visual: "🌸" },
    { prompt: "Qual palavra rima com CORAÇÃO?", options: ["Balão", "Mesa", "Sol"], answer: 0, visual: "❤️" },
    { prompt: "Qual letrinha começa a palavra SOL?", options: ["S", "C", "Z"], answer: 0, visual: "☀️" },
    { prompt: "Quantas letrinhas tem a palavra ELO?", options: ["3 letrinhas", "5 letrinhas", "2 letrinhas"], answer: 0, visual: "👧" },
    { prompt: "Qual palavra rima com PATO?", options: ["Gato", "Cadeira", "Flor"], answer: 0, visual: "🦆" },
    { prompt: "Qual letrinha começa a palavra LUA?", options: ["L", "U", "I"], answer: 0, visual: "🌙" }
  ],
  numbers: [
    { prompt: "Quantas maçãs tem aqui?", options: ["3", "2", "4"], answer: 0, visual: "🍎 🍎 🍎" },
    { prompt: "Quanto é 2 + 2?", options: ["4", "3", "5"], answer: 0, visual: "✌️ + ✌️" },
    { prompt: "Qual forma é redondinha como a Lua cheia?", options: ["Círculo", "Triângulo", "Quadrado"], answer: 0, visual: "⚪" },
    { prompt: "Qual número vem DEPOIS do 4?", options: ["5", "3", "6"], answer: 0, visual: "1, 2, 3, 4, __?" },
    { prompt: "Quantas patinhas tem o gatinho?", options: ["4 patinhas", "2 patinhas", "6 patinhas"], answer: 0, visual: "🐾" },
    { prompt: "Quanto é 1 + 1 docinho?", options: ["2", "3", "1"], answer: 0, visual: "🧁 + 🧁" },
    { prompt: "Quantas estrelinhas temos aqui?", options: ["5", "4", "6"], answer: 0, visual: "⭐ ⭐ ⭐ ⭐ ⭐" },
    { prompt: "Qual número é MAIOR?", options: ["8", "3", "5"], answer: 0, visual: "🔢" },
    { prompt: "Qual forma tem 3 pontinhas?", options: ["Triângulo", "Círculo", "Quadrado"], answer: 0, visual: "🔺" },
    { prompt: "Quantos dedinhos temos em uma mão?", options: ["5", "4", "10"], answer: 0, visual: "🖐️" },
    { prompt: "Quanto é 3 + 2?", options: ["5", "4", "6"], answer: 0, visual: "🎈🎈🎈 + 🎈🎈" },
    { prompt: "Qual número vem ANTES do 3?", options: ["2", "1", "4"], answer: 0, visual: "__, 3, 4" },
    { prompt: "Quantas orelhinhas tem o coelho?", options: ["2", "1", "4"], answer: 0, visual: "🐰" },
    { prompt: "Quanto é 5 - 1 balãozinho?", options: ["4", "3", "5"], answer: 0, visual: "🎈🎈🎈🎈🎈 - 🎈" },
    { prompt: "Qual número é MENOR?", options: ["2", "7", "9"], answer: 0, visual: "🔢" },
    { prompt: "Quantos lados tem um quadrado?", options: ["4 lados", "3 lados", "5 lados"], answer: 0, visual: "🟩" },
    { prompt: "Qual número vem DEPOIS do 9?", options: ["10", "8", "11"], answer: 0, visual: "7, 8, 9, __?" },
    { prompt: "Quantas flores temos aqui?", options: ["4", "2", "6"], answer: 0, visual: "🌸 🌸 🌸 🌸" },
    { prompt: "Quanto é 2 + 3?", options: ["5", "6", "4"], answer: 0, visual: "🍓🍓 + 🍓🍓🍓" },
    { prompt: "Quantas rodas tem uma bicicleta?", options: ["2 rodas", "4 rodas", "3 rodas"], answer: 0, visual: "🚲" },
    { prompt: "Quanto é 4 + 4?", options: ["8", "6", "9"], answer: 0, visual: "🌟🌟🌟🌟 + 🌟🌟🌟🌟" },
    { prompt: "Qual forma parece uma caixinha de presente?", options: ["Quadrado", "Círculo", "Triângulo"], answer: 0, visual: "🎁" },
    { prompt: "Se você tem 3 maçãs e come 1, com quantas fica?", options: ["2", "1", "3"], answer: 0, visual: "🍎🍎🍎" },
    { prompt: "Qual destes números é par?", options: ["4", "3", "5"], answer: 0, visual: "🔢" },
    { prompt: "Quanto é 5 + 5 dedos das mãos?", options: ["10", "8", "12"], answer: 0, visual: "🖐️ + 🖐️" }
  ],
  curious: [
    { prompt: "Onde os peixinhos nadam felizes?", options: ["Na água", "No céu", "Na terra"], answer: 0, visual: "🐠" },
    { prompt: "Qual cor resulta da mistura de Azul + Amarelo?", options: ["Verde", "Roxo", "Laranja"], answer: 0, visual: "🎨" },
    { prompt: "O que o Sol nos dá durante o dia?", options: ["Luz e calor", "Neve", "Escuridão"], answer: 0, visual: "☀️" },
    { prompt: "Qual alimento a abelhinha faz?", options: ["Mel doce", "Queijo", "Pão"], answer: 0, visual: "🍯" },
    { prompt: "Qual planeta nós moramos?", options: ["Terra", "Marte", "Lua"], answer: 0, visual: "🌍" },
    { prompt: "O que devemos fazer antes de comer?", options: ["Lavar as mãozinhas", "Dormir", "Correr"], answer: 0, visual: "🧼" },
    { prompt: "Qual destes animais voa no céu?", options: ["Passarinho", "Tartaruga", "Peixe"], answer: 0, visual: "🐦" },
    { prompt: "Qual frutinha é vermelha com pontinhos?", options: ["Morango", "Banana", "Laranja"], answer: 0, visual: "🍓" },
    { prompt: "O que as plantinhas precisam para crescer?", options: ["Água e luz do sol", "Suco de uva", "Chocolate"], answer: 0, visual: "🌱" },
    { prompt: "Qual desses animais vive na fazenda e dá leite?", options: ["Vaca", "Leão", "Tubarão"], answer: 0, visual: "🐄" },
    { prompt: "Qual parte do corpinho usamos para enxergar?", options: ["Olhos", "Ouvidos", "Nariz"], answer: 0, visual: "👀" },
    { prompt: "Qual parte do corpo usamos para ouvir músicas?", options: ["Ouvidos", "Boca", "Mãozinhas"], answer: 0, visual: "👂" },
    { prompt: "O que devemos fazer depois das refeições?", options: ["Escovar os dentes", "Comer doce", "Pular"], answer: 0, visual: "🪥" },
    { prompt: "Qual animal tem pescoço bem comprido?", options: ["Girafa", "Coelhinho", "Gatinho"], answer: 0, visual: "🦒" },
    { prompt: "Em qual estação caem folhas das árvores?", options: ["Outono", "Verão", "Primavera"], answer: 0, visual: "🍂" },
    { prompt: "Em qual estação as flores se abrem perfumadas?", options: ["Primavera", "Inverno", "Outono"], answer: 0, visual: "🌺" },
    { prompt: "Quem brilha no céu durante a noite?", options: ["A Lua e as Estrelas", "O Sol", "O Arco-íris"], answer: 0, visual: "🌙" },
    { prompt: "O que acontece quando chove com sol?", options: ["Aparece o Arco-íris", "Fica de noite", "Cai neve"], answer: 0, visual: "🌈" },
    { prompt: "Qual animal é conhecido como o rei da selva?", options: ["Leão", "Cachorro", "Pinguim"], answer: 0, visual: "🦁" },
    { prompt: "Onde o esquilo gosta de guardar suas nozes?", options: ["No tronco da árvore", "No rio", "Na cama"], answer: 0, visual: "🐿️" },
    { prompt: "Qual animal anda bem devagarzinho com sua carapaça?", options: ["Tartaruga", "Leopardo", "Pássaro"], answer: 0, visual: "🐢" },
    { prompt: "O que os carros usam para avisar no trânsito?", options: ["Buzina", "Sino de igreja", "Violino"], answer: 0, visual: "🚗" },
    { prompt: "Qual fruta costuma ser azedinha e amarela?", options: ["Limão", "Uva", "Melancia"], answer: 0, visual: "🍋" },
    { prompt: "Qual destes animais vive no gelo e sabe nadar?", options: ["Pinguim", "Camelo", "Macaco"], answer: 0, visual: "🐧" },
    { prompt: "Quantas cores principais tem o arco-íris?", options: ["7 cores", "3 cores", "12 cores"], answer: 0, visual: "🌈" }
  ]
};

window.selectSchoolTrack = function(track){
  activeSchoolTrack = track;
  currentSchoolQuestionIdx = 0;
  schoolTrackScore = 0;
  document.querySelectorAll(".schoolTrackTab").forEach(t => {
    t.classList.toggle("active", t.dataset.track === track);
  });
  const bank = SCHOOL_TRACK_DATA[track] || SCHOOL_TRACK_DATA.letters;
  activeSchoolDeck = shuffle([...bank]).slice(0, 8);
  renderModernSchoolQuestion();
};

window.renderModernSchoolQuestion = function(){
  if(!activeSchoolDeck.length){
    activeSchoolDeck = shuffle(SCHOOL_TRACK_DATA[activeSchoolTrack] || SCHOOL_TRACK_DATA.letters).slice(0, 8);
  }
  const box = document.getElementById("schoolOptionsGrid");
  const titleEl = document.getElementById("schoolQuestionTitle");
  const roundEl = document.getElementById("schoolRoundCounter");
  if(!box || !titleEl || !roundEl) return;

  if(currentSchoolQuestionIdx >= activeSchoolDeck.length){
    titleEl.textContent = "Parabéns! Rodada concluída com sucesso!";
    roundEl.textContent = `${activeSchoolDeck.length}/${activeSchoolDeck.length} ✓`;
    box.innerHTML = `<div style="text-align:center;padding:20px;grid-column:span 3;">
      <div style="font-size:52px;animation:dollHappy .6s infinite alternate;">🏅⭐🎉</div>
      <h3 style="margin:10px 0 6px;color:#d84376;">Você brilhou na Escolinha da Elo!</h3>
      <p style="color:var(--muted);margin-bottom:14px;">Acertos: ${schoolTrackScore}/${activeSchoolDeck.length}. Ganhou +4 estrelinhas!</p>
      <button class="btn" onclick="selectSchoolTrack('${activeSchoolTrack}')">Nova Rodada Embaralhada 🔁</button>
    </div>`;
    playCuteSfx("win");
    triggerStarConfetti();
    addStars(4, "Trilha da Escolinha concluída com perfeição! +4 ⭐");
    trackActivity("school");
    return;
  }

  const q = activeSchoolDeck[currentSchoolQuestionIdx];
  roundEl.textContent = `Desafio ${currentSchoolQuestionIdx + 1}/${activeSchoolDeck.length}`;
  titleEl.innerHTML = `${q.prompt}<br><span style="font-size:40px;display:inline-block;margin-top:8px;">${q.visual}</span>`;

  // Embaralha dinamicamente as opções para a resposta correta cair aleatoriamente em qualquer botão!
  const choices = q.options.map((opt, idx) => ({ text: opt, isCorrect: idx === q.answer }));
  currentModernSchoolChoices = window.currentModernSchoolChoices = shuffle(choices);

  box.innerHTML = currentModernSchoolChoices.map((c, i) => `
    <button class="schoolOptBtn" onclick="answerSchoolChoice(${i}, this)">
      <b>${c.text}</b>
    </button>
  `).join("");

  if(typeof speakText === "function"){
    setTimeout(()=>speakText(q.prompt), 180);
  }
};

window.speakCurrentSchoolPrompt = function(){
  const q = activeSchoolDeck[currentSchoolQuestionIdx];
  if(q && typeof speakText === "function") speakText(q.prompt);
};

window.answerSchoolChoice = function(choiceIdx, btn){
  const choice = currentModernSchoolChoices[choiceIdx];
  if(!choice) return;
  if(choice.isCorrect){
    schoolTrackScore++;
    if(btn) {
      btn.style.background = "#dcfce7";
      btn.style.borderColor = "#22c55e";
    }
    playCuteSfx("coin");
    triggerStarConfetti();
    toast("Isso mesmo! Você acertou! ⭐");
    currentSchoolQuestionIdx++;
    setTimeout(renderModernSchoolQuestion, 600);
  } else {
    playCuteSfx("wrong");
    if(btn) {
      btn.style.background = "#fee2e2";
      btn.style.borderColor = "#ef4444";
    }
    toast("Quase! Tente outra opção 💗");
  }
};

// --- PIANO ARCO-ÍRIS & SONS ENCANTADOS ---
const PIANO_NOTES_FREQ = {
  do: 261.63, re: 293.66, mi: 329.63, fa: 349.23,
  sol: 392.00, la: 440.00, si: 493.88, do2: 523.25
};

window.playPianoKey = function(note, noteName){
  const freq = PIANO_NOTES_FREQ[note] || 440;
  playTone(freq, 0.45, "triangle");
  toast(`Nota: ${noteName} 🎶`);
  const k = document.querySelector(`.pianoKey[data-note="${note}"]`);
  if(k){
    k.style.transform = "scale(0.92) translateY(6px)";
    setTimeout(()=>k.style.transform = "", 200);
  }
};

window.playBabySong = function(songKey){
  toast("Tocando cançãozinha da Elo... 🎵");
  const songs = {
    estrela: [
      {n:"do", d:300}, {n:"do", d:300}, {n:"sol", d:300}, {n:"sol", d:300},
      {n:"la", d:300}, {n:"la", d:300}, {n:"sol", d:600},
      {n:"fa", d:300}, {n:"fa", d:300}, {n:"mi", d:300}, {n:"mi", d:300},
      {n:"re", d:300}, {n:"re", d:300}, {n:"do", d:600}
    ],
    alecrim: [
      {n:"do", d:350}, {n:"re", d:350}, {n:"mi", d:350}, {n:"sol", d:350},
      {n:"fa", d:350}, {n:"mi", d:350}, {n:"re", d:700}
    ],
    ciranda: [
      {n:"sol", d:300}, {n:"mi", d:300}, {n:"sol", d:300}, {n:"mi", d:300},
      {n:"fa", d:300}, {n:"re", d:300}, {n:"fa", d:300}, {n:"re", d:600}
    ]
  };
  const melody = songs[songKey] || songs.estrela;
  let delay = 0;
  melody.forEach(step => {
    setTimeout(()=>{
      playPianoKey(step.n, step.n.toUpperCase());
    }, delay);
    delay += step.d;
  });
  setTimeout(()=>{
    addStars(1, "Canção tocada com carinho! +1 ⭐");
    triggerStarConfetti();
  }, delay + 200);
};

// --- BANDA & MESA DE DJ DA ELO ---
let djBeatLoopInterval = null;
let djBeatStep = 0;

window.playDJPad = function(type){
  const ctx = getAudioContext();
  if(!ctx) return;
  const now = ctx.currentTime;
  
  if(type === "kick"){
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(0.01, now + 0.3);
    g.gain.setValueAtTime(1, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.3);
    toast("BOOM! Bumbo Pop 🥁");
  } else if(type === "snare"){
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(280, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.2);
    g.gain.setValueAtTime(0.8, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.2);
    toast("CAIXA! Pow! 🎶");
  } else if(type === "hihat"){
    playTone(1800, 0.05, "square");
    toast("TSS! Prato Estelar ✨");
  } else if(type === "clap"){
    playCuteSfx("pop");
    toast("PALMAS! 👏");
  } else if(type === "synth1"){
    playTone(523.25, 0.3, "sine");
    toast("SYNTH! Brilho 🌈");
  } else if(type === "synth2"){
    playTone(659.25, 0.3, "sawtooth");
    toast("DISCO! 🪩");
  } else if(type === "cheer"){
    playCuteSfx("win");
    toast("UHUUUL! A plateia vibrou! 🎉");
  }
};

window.toggleDJBeatLoop = function(){
  const btn = document.getElementById("djBeatToggleBtn");
  if(djBeatLoopInterval){
    clearInterval(djBeatLoopInterval);
    djBeatLoopInterval = null;
    if(btn) {
      btn.textContent = "▶ Iniciar Ritmo Automático (110 BPM)";
      btn.style.background = "";
    }
    toast("Ritmo pausado ⏸️");
  } else {
    djBeatStep = 0;
    if(btn) {
      btn.textContent = "⏹ Parar Ritmo Dançante";
      btn.style.background = "#22c55e";
      btn.style.color = "#fff";
    }
    toast("Solta o som! Batida dançante da Elo iniciada 🎧🕺");
    djBeatLoopInterval = setInterval(()=>{
      djBeatStep = (djBeatStep + 1) % 4;
      if(djBeatStep === 0 || djBeatStep === 2) {
        playDJPad("kick");
      } else {
        playDJPad("snare");
      }
      playDJPad("hihat");
    }, 545); // ~110 BPM
  }
};

// --- 4. ATELIÊ CRIATIVO DA ELO + ESTÚDIO DE FOTOS ---
let freeCanvas, freeCtx, isPainting = false, currentBrushColor = "#ff4d8d", currentBrushSize = 8;
let photoScene = "castle", photoFrame = "pink";

window.switchCreativeMode = function(mode, btn){
  document.querySelectorAll(".creativeModeTabs .cTabBtn").forEach(b => b.classList.remove("active"));
  if(btn){
    btn.classList.add("active");
  } else {
    const targetBtn = document.querySelector(`.creativeModeTabs .cTabBtn[onclick*="'${mode}'"]`);
    if(targetBtn) targetBtn.classList.add("active");
  }
  const fSec = document.getElementById("freeDrawSection");
  const cSec = document.getElementById("coloringSection");
  const chSec = document.getElementById("chefSection");
  const pSec = document.getElementById("photoSection");
  if(fSec) fSec.classList.toggle("hidden", mode !== "freeDraw");
  if(cSec) cSec.classList.toggle("hidden", mode !== "coloring");
  if(chSec) chSec.classList.toggle("hidden", mode !== "chef");
  if(pSec) pSec.classList.toggle("hidden", mode !== "photo");

  if(mode === "freeDraw") setTimeout(initFreeDrawCanvas, 60);
  if(mode === "chef") setTimeout(generateNewChefOrder, 60);
  if(mode === "photo") setTimeout(initPhotoStudio, 60);
};

window.initFreeDrawCanvas = function(){
  freeCanvas = document.getElementById("freeDrawCanvas");
  if(!freeCanvas) return;
  freeCtx = freeCanvas.getContext("2d");
  
  if(!freeCanvas.dataset.ready){
    freeCanvas.dataset.ready = "1";
    freeCanvas.width = 440;
    freeCanvas.height = 340;
    clearFreeDraw();

    const getPos = (e) => {
      const rect = freeCanvas.getBoundingClientRect();
      const cx = e.touches ? e.touches[0].clientX : e.clientX;
      const cy = e.touches ? e.touches[0].clientY : e.clientY;
      return {
        x: (cx - rect.left) * (freeCanvas.width / rect.width),
        y: (cy - rect.top) * (freeCanvas.height / rect.height)
      };
    };

    const startDraw = (e) => {
      e.preventDefault();
      isPainting = true;
      const p = getPos(e);
      freeCtx.beginPath();
      freeCtx.moveTo(p.x, p.y);
      freeCtx.lineCap = "round";
      freeCtx.lineJoin = "round";
      freeCtx.strokeStyle = currentBrushColor;
      freeCtx.lineWidth = currentBrushSize;
    };

    const moveDraw = (e) => {
      if(!isPainting) return;
      e.preventDefault();
      const p = getPos(e);
      freeCtx.lineTo(p.x, p.y);
      freeCtx.stroke();
    };

    const stopDraw = () => { isPainting = false; };

    freeCanvas.addEventListener("mousedown", startDraw);
    freeCanvas.addEventListener("mousemove", moveDraw);
    window.addEventListener("mouseup", stopDraw);

    freeCanvas.addEventListener("touchstart", startDraw, { passive: false });
    freeCanvas.addEventListener("touchmove", moveDraw, { passive: false });
    window.addEventListener("touchend", stopDraw);
  }
};

window.setBrushColor = function(color, btn){
  currentBrushColor = color;
  document.querySelectorAll(".colorSwatch").forEach(b => b.classList.remove("active"));
  if(btn) btn.classList.add("active");
  playCuteSfx("pop");
};

window.setBrushSize = function(size, btn){
  currentBrushSize = size;
  document.querySelectorAll(".brushSizeBtn").forEach(b => b.classList.remove("active"));
  if(btn) btn.classList.add("active");
  playCuteSfx("pop");
};

window.clearFreeDraw = function(){
  if(!freeCtx || !freeCanvas) return;
  freeCtx.fillStyle = "#ffffff";
  freeCtx.fillRect(0, 0, freeCanvas.width, freeCanvas.height);
};

window.addCanvasSticker = function(emoji){
  if(!freeCtx || !freeCanvas) return;
  freeCtx.font = "46px sans-serif";
  freeCtx.textAlign = "center";
  freeCtx.textBaseline = "middle";
  const x = 50 + Math.random() * (freeCanvas.width - 100);
  const y = 50 + Math.random() * (freeCanvas.height - 100);
  freeCtx.fillText(emoji, x, y);
  playCuteSfx("pop");
  toast(`Adesivo ${emoji} colado na sua arte! ✨`);
};

window.saveFreeDrawArt = function(){
  triggerStarConfetti();
  playCuteSfx("win");
  addStars(3, "Que desenho maravilhoso! Artista nata! +3 ⭐");
  toast("Desenho salvo no seu coraçãozinho! 🎨⭐");
};

// --- ESTÚDIO DE FOTOS DA ELO & BICHINHO VIRTUAL ---
window.initPhotoStudio = function(){
  renderPhotoStudio();
};

window.setPhotoScene = function(scene, btn){
  photoScene = scene;
  document.querySelectorAll(".photoSceneBtn").forEach(b => b.classList.remove("active"));
  if(btn) btn.classList.add("active");
  renderPhotoStudio();
  playCuteSfx("pop");
};

window.setPhotoFrame = function(frame, btn){
  photoFrame = frame;
  document.querySelectorAll(".photoFrameBtn").forEach(b => b.classList.remove("active"));
  if(btn) btn.classList.add("active");
  renderPhotoStudio();
  playCuteSfx("pop");
};

window.renderPhotoStudio = function(){
  const canvas = document.getElementById("photoStudioCanvas");
  if(!canvas) return;
  const ctx = canvas.getContext("2d");
  canvas.width = 480;
  canvas.height = 360;

  // 1. Cenário de Fundo
  if(photoScene === "castle"){
    const grad = ctx.createLinearGradient(0, 0, 0, 360);
    grad.addColorStop(0, "#fbcfe8"); grad.addColorStop(1, "#f472b6");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 480, 360);
    ctx.font = "80px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("🏰", 240, 160);
    ctx.font = "32px sans-serif";
    ctx.fillText("☁️", 90, 80); ctx.fillText("☁️", 390, 90);
  } else if(photoScene === "forest"){
    const grad = ctx.createLinearGradient(0, 0, 0, 360);
    grad.addColorStop(0, "#bbf7d0"); grad.addColorStop(1, "#4ade80");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 480, 360);
    ctx.font = "80px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("🌳 🍄 🌸", 240, 160);
  } else if(photoScene === "beach"){
    const grad = ctx.createLinearGradient(0, 0, 0, 360);
    grad.addColorStop(0, "#bae6fd"); grad.addColorStop(0.65, "#38bdf8"); grad.addColorStop(1, "#fde047");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 480, 360);
    ctx.font = "50px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("☀️", 400, 70); ctx.fillText("🏖️ 🌊 🦀", 240, 240);
  } else if(photoScene === "space"){
    const grad = ctx.createLinearGradient(0, 0, 0, 360);
    grad.addColorStop(0, "#0f172a"); grad.addColorStop(1, "#312e81");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 480, 360);
    ctx.font = "40px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("✨ 🪐 🚀 ⭐ 🛸", 240, 140);
  } else { // rainbow
    const grad = ctx.createLinearGradient(0, 0, 480, 360);
    grad.addColorStop(0, "#fbcfe8"); grad.addColorStop(0.5, "#fed7aa"); grad.addColorStop(1, "#ddd6fe");
    ctx.fillStyle = grad; ctx.fillRect(0, 0, 480, 360);
    ctx.font = "80px sans-serif"; ctx.textAlign = "center";
    ctx.fillText("🌈 ✨ 🦄", 240, 150);
  }

  // 2. Chão com graminha / tapete
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.beginPath();
  ctx.ellipse(240, 290, 190, 45, 0, 0, Math.PI * 2);
  ctx.fill();

  // 3. Personagens: Elo e Pet
  ctx.font = "90px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("👧", 190, 280); // Elo
  
  // Pegar ícone do pet se existir
  let petEmoji = "🦄";
  try {
    if(window.petData && window.petData.species) {
      const specMap = { unicorn:"🦄", cat:"🐱", dog:"🐶", rabbit:"🐰", dragon:"🐲", pony:"🐴" };
      petEmoji = specMap[window.petData.species] || "🦄";
    }
  } catch(_) {}
  ctx.font = "70px sans-serif";
  ctx.fillText(petEmoji, 290, 280); // Pet companheiro

  // 4. Moldura fotográfica
  ctx.lineWidth = 14;
  if(photoFrame === "pink"){
    ctx.strokeStyle = "#ec4899";
    ctx.strokeRect(10, 10, 460, 340);
  } else if(photoFrame === "gold"){
    ctx.strokeStyle = "#eab308";
    ctx.strokeRect(10, 10, 460, 340);
  } else { // party
    ctx.strokeStyle = "#8b5cf6";
    ctx.strokeRect(10, 10, 460, 340);
  }

  // Faixa de legenda fofa
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  ctx.fillRect(40, 305, 400, 36);
  ctx.font = "bold 16px 'Nunito', sans-serif";
  ctx.fillStyle = "#831843";
  ctx.textAlign = "center";
  ctx.fillText("Dia a Dia da Elo • Melhores Amigos Para Sempre 💕", 240, 329);
};

window.savePhotoStudioArt = function(){
  const canvas = document.getElementById("photoStudioCanvas");
  if(!canvas) return;
  const link = document.createElement("a");
  link.download = "foto-da-elo-e-amigos.png";
  link.href = canvas.toDataURL("image/png");
  link.click();

  playCuteSfx("win");
  triggerStarConfetti();
  addStars(3, "Foto mágica revelada com sucesso! +3 ⭐");
  toast("Foto baixada com sucesso! Ficou linda! 📸✨");
};

// --- MINI CHEF DA ELO ---
const CHEF_RECIPES = [
  { name: "Bolo da Princesa", req: ["Ovos", "Farinha", "Morangos", "Confeitos"], icon: "🎂" },
  { name: "Hambúrguer Fofinho", req: ["Pão", "Queijo", "Tomate", "Alface"], icon: "🍔" },
  { name: "Taça de Sorvete Encantado", req: ["Sorvete", "Calda", "Confeitos", "Morangos"], icon: "🍨" },
  { name: "Pizza de Coração", req: ["Farinha", "Tomate", "Queijo", "Cogumelos"], icon: "🍕" }
];
let currentChefRecipe = null, selectedChefIngredients = [];

window.generateNewChefOrder = function(){
  currentChefRecipe = CHEF_RECIPES[Math.floor(Math.random() * CHEF_RECIPES.length)];
  selectedChefIngredients = [];
  const nameEl = document.getElementById("chefRecipeName");
  const iconEl = document.getElementById("chefRecipeIcon");
  const reqEl = document.getElementById("chefRecipeReq");
  const bowlEl = document.getElementById("chefBowlContent");
  if(nameEl) nameEl.textContent = currentChefRecipe.name;
  if(iconEl) iconEl.textContent = currentChefRecipe.icon;
  if(reqEl) reqEl.innerHTML = currentChefRecipe.req.map(i => `<span class="badge" style="background:#fce7f3;color:#be185d;">${i}</span>`).join(" ");
  if(bowlEl) bowlEl.textContent = "Tigela Vazia 🥣";
  document.querySelectorAll(".chefIngBtn").forEach(b => b.classList.remove("selected"));
};

window.toggleChefIngredient = function(ing, btn){
  const idx = selectedChefIngredients.indexOf(ing);
  if(idx > -1){
    selectedChefIngredients.splice(idx, 1);
    if(btn) btn.classList.remove("selected");
  } else {
    selectedChefIngredients.push(ing);
    if(btn) btn.classList.add("selected");
    playCuteSfx("pop");
  }
  const bowlEl = document.getElementById("chefBowlContent");
  if(bowlEl){
    bowlEl.textContent = selectedChefIngredients.length ? `🥣 Misturando: ${selectedChefIngredients.join(" + ")}` : "Tigela Vazia 🥣";
  }
};

window.deliverChefOrder = function(){
  if(!currentChefRecipe) return;
  const missing = currentChefRecipe.req.filter(i => !selectedChefIngredients.includes(i));
  if(missing.length > 0){
    playCuteSfx("wrong");
    toast(`Faltam ingredientes para o ${currentChefRecipe.name}: ${missing.join(", ")}! 👩‍🍳`);
    return;
  }
  playCuteSfx("win");
  triggerStarConfetti();
  addStars(4, `Receita entregue! O ${currentChefRecipe.name} ficou delicioso! +4 ⭐`);
  toast("Chef 5 estrelas! Prato perfeito! 👩‍🍳⭐");
  setTimeout(generateNewChefOrder, 1000);
};

// --- 5. CONSULTÓRIO & SALÃO DE CUIDADOS DA ELO ---
let teethCleanCount = 0;
let scrapeStep = 0;
let lunchboxItems = { fruit: null, snack: null, drink: null };

window.switchCareTab = function(tab, btn){
  document.querySelectorAll(".careTabBtn").forEach(b => b.classList.remove("active"));
  if(btn) btn.classList.add("active");
  const tSec = document.getElementById("careTeethStage");
  const bSec = document.getElementById("careBandageStage");
  const lSec = document.getElementById("careLunchStage");
  if(tSec) tSec.classList.toggle("hidden", tab !== "teeth");
  if(bSec) bSec.classList.toggle("hidden", tab !== "bandage");
  if(lSec) lSec.classList.toggle("hidden", tab !== "lunch");
  if(tab === "teeth") initTeethStage();
};

window.initTeethStage = function(){
  teethCleanCount = 0;
  const pText = document.getElementById("teethProgressText");
  if(pText) pText.textContent = "Toque em cada dentinho com sua escova mágica para remover a sujeirinha! 🫧 (0/8 limpos)";
  const rows = ["teethRowUpper", "teethRowLower"];
  rows.forEach((rowId, rIdx) => {
    const row = document.getElementById(rowId);
    if(row){
      row.innerHTML = [0, 1, 2, 3].map(c => `
        <button class="toothItem dirty" onclick="brushTooth(this)" style="font-size:36px;background:none;border:none;cursor:pointer;transition:transform .2s;">
          🦷<span style="font-size:16px;display:block;margin-top:-10px;">🦠</span>
        </button>
      `).join("");
    }
  });
};

window.brushTooth = function(btn){
  if(!btn || !btn.classList.contains("dirty")) return;
  btn.classList.remove("dirty");
  btn.innerHTML = `🦷<span style="font-size:16px;display:block;margin-top:-10px;">✨</span>`;
  btn.style.transform = "scale(1.2)";
  setTimeout(()=>btn.style.transform = "scale(1)", 200);
  playCuteSfx("pop");
  teethCleanCount++;
  const pText = document.getElementById("teethProgressText");
  if(pText) pText.textContent = `Que capricho! Dentinhos brilhando: ${teethCleanCount}/8 ✨`;
  if(teethCleanCount >= 8){
    playCuteSfx("win");
    triggerStarConfetti();
    toast("Todos os dentinhos estão limpinhos e protegidos! 🪥✨");
    if(pText) pText.innerHTML = "<b>Parabéns! Sorriso nota 10 com cheirinho de morango! 🍓✨</b>";
  }
};

window.finishBrushingTeeth = function(){
  if(teethCleanCount < 8){
    toast("Ainda tem dentinhos precisando de escovação! 🪥");
    return;
  }
  playCuteSfx("win");
  triggerStarConfetti();
  addStars(3, "Sorriso limpinho e protegido de cáries! +3 ⭐");
  toast("Dentes 100% limpinhos e saudáveis! ⭐");
  setTimeout(initTeethStage, 1200);
};

window.treatScrape = function(btn){
  const spot = document.getElementById("scrapeSpot1");
  const fb = document.getElementById("scrapeFeedback");
  scrapeStep++;
  if(scrapeStep === 1){
    playCuteSfx("pop");
    if(spot) spot.innerHTML = "🧴<span style='font-size:14px;display:block;'>Pomadinha Mágica</span>";
    if(fb) fb.textContent = "Passamos pomadinha refrescante! Agora toque para colocar o curativo de coração! 💖";
  } else if(scrapeStep === 2){
    playCuteSfx("win");
    triggerStarConfetti();
    if(spot) spot.innerHTML = "🩹💖<span style='font-size:14px;display:block;'>Curado com Amor!</span>";
    if(fb) fb.innerHTML = "<b>O dodói sarou completamente com o carinho da Elo! ✨</b>";
    addStars(3, "Dodói tratado com muito amor e carinho! +3 ⭐");
    setTimeout(()=>{
      scrapeStep = 0;
      if(spot) spot.innerHTML = "🩹<br>Dodói no Joelho";
      if(fb) fb.textContent = "Toque no joelho para limpar e passar pomada mágica!";
    }, 2500);
  }
};

window.setLunchItem = function(slot, emoji, label){
  lunchboxItems[slot] = { emoji, label };
  const slotEl = document.getElementById(`lunchSlot${slot.charAt(0).toUpperCase() + slot.slice(1)}`);
  if(slotEl){
    slotEl.innerHTML = `<span style="font-size:32px;">${emoji}</span><small style="display:block;font-size:12px;font-weight:bold;">${label}</small>`;
    slotEl.style.background = "#dcfce7";
  }
  playCuteSfx("pop");
  toast(`Adicionado à lancheira: ${label}! 😋`);
};

window.finishLunchbox = function(){
  if(!lunchboxItems.fruit || !lunchboxItems.snack || !lunchboxItems.drink){
    toast("Preencha a frutinha, o lanchinho e a bebidinha da lancheira! 🥪🥤");
    return;
  }
  playCuteSfx("win");
  triggerStarConfetti();
  addStars(4, "Lancheira nutritiva e deliciosa preparada com carinho! +4 ⭐");
  toast("Lancheira nota 10 para a escolinha! 🥪🍎✨");
};

// --- 6. COPA DA FAMÍLIA (TORNEIO DE 3 RODADAS) ---
let cupCurrentRound = 1, cupP1Score = 0, cupP2Score = 0;

window.switchFamilyMode = function(mode, btn){
  familyActiveMode = mode;
  document.querySelectorAll(".familyTabBtn").forEach(b => b.classList.remove("active"));
  if(btn){
    btn.classList.add("active");
  } else {
    const targetBtn = document.querySelector(`.familyTabBtn[onclick*="'${mode}'"]`);
    if(targetBtn) targetBtn.classList.add("active");
  }
  const mimeEl = document.getElementById("familyMimeView");
  const duelEl = document.getElementById("familyDuelView");
  const scoreEl = document.getElementById("familyScoreView");
  const cupEl = document.getElementById("familyCupView");
  if(mimeEl) mimeEl.classList.toggle("hidden", mode !== "mime");
  if(duelEl) duelEl.classList.toggle("hidden", mode !== "duel");
  if(scoreEl) scoreEl.classList.toggle("hidden", mode !== "score");
  if(cupEl) cupEl.classList.toggle("hidden", mode !== "cup");

  if(mode === "duel") startDuelRound();
  if(mode === "cup") resetCupTournament();
};

window.finishCupRound = function(round){
  cupCurrentRound = round + 1;
  playCuteSfx("win");
  triggerStarConfetti();
  const c1 = document.getElementById("cupStep1");
  const c2 = document.getElementById("cupStep2");
  const c3 = document.getElementById("cupStep3");
  const title = document.getElementById("cupRoundTitle");
  const prompt = document.getElementById("cupRoundPrompt");

  if(round === 1){
    if(c1) { c1.classList.remove("active"); c1.classList.add("done"); c1.textContent = "1 ✓"; }
    if(c2) { c2.classList.add("active"); }
    if(title) title.textContent = "Rodada 2: Desafio do Duelo Rápido ⚡";
    if(prompt) prompt.innerHTML = "Quem é mais veloz no toque da tela? Disputem um duelo e toquem no botão para avançar para a Grande Final!";
    const btn = document.querySelector("#cupRoundCard button");
    if(btn) { btn.setAttribute("onclick", "finishCupRound(2)"); btn.textContent = "Concluir Rodada 2 e Ir Para a Final! 🚀"; }
    toast("Rodada 1 concluída! Avançando para a Rodada 2! 🏅");
  } else if(round === 2){
    if(c2) { c2.classList.remove("active"); c2.classList.add("done"); c2.textContent = "2 ✓"; }
    if(c3) { c3.classList.add("active"); }
    if(title) title.textContent = "🏆 Grande Final: Cerimônia do Troféu da Família! 🏆";
    if(prompt) prompt.innerHTML = "<div style='font-size:72px;margin:10px 0;'>🏆✨🎉</div><b style='font-size:20px;color:#d84376;'>Parabéns, Família Campeã!</b><p>Vocês jogaram com união, alegria e carinho. A taça dourada da Elo é de todos vocês!</p>";
    const btn = document.querySelector("#cupRoundCard button");
    if(btn) { btn.setAttribute("onclick", "resetCupTournament()"); btn.textContent = "Novo Torneio da Copa da Família 🔁"; }
    addStars(10, "Grande Campeão da Copa da Família! +10 ⭐");
  }
};

window.resetCupTournament = function(){
  cupCurrentRound = 1;
  const c1 = document.getElementById("cupStep1");
  const c2 = document.getElementById("cupStep2");
  const c3 = document.getElementById("cupStep3");
  const title = document.getElementById("cupRoundTitle");
  const prompt = document.getElementById("cupRoundPrompt");
  if(c1) { c1.className = "cupStep active"; c1.textContent = "1"; }
  if(c2) { c2.className = "cupStep"; c2.textContent = "2"; }
  if(c3) { c3.className = "cupStep"; c3.textContent = "3"; }
  if(title) title.textContent = "Rodada 1: Desafio da Mímica Encantada 🎭";
  if(prompt) prompt.innerHTML = "Um jogador faz a mímica de um animal ou profissão sem falar! Quem acertar ganha o ponto da rodada!";
  const btn = document.querySelector("#cupRoundCard button");
  if(btn) { btn.setAttribute("onclick", "finishCupRound(1)"); btn.textContent = "Concluir Rodada 1 e Ir Para o Duelo ➡️"; }
};

// --- 7. ÁLBUM DE FIGURINHAS BRILHANTES & PACOTINHOS SURPRESA ---
const STICKER_COLLECTION_DATA = [
  { id: "s1", name: "Elo Princesa", emoji: "👸", rarity: "rare", desc: "Coroa brilhante e vestido real" },
  { id: "s2", name: "Luminho Unicórnio", emoji: "🦄", rarity: "gold", desc: "Crina arco-íris mágica" },
  { id: "s3", name: "Pipoca Gatinho", emoji: "🐱", rarity: "common", desc: "Ronrom mais fofo do mundo" },
  { id: "s4", name: "Pingo Cachorrinho", emoji: "🐶", rarity: "common", desc: "Adora brincar de bolinha" },
  { id: "s5", name: "Elo Astronauta", emoji: "👩‍🚀", rarity: "gold", desc: "Exploradora de galáxias" },
  { id: "s6", name: "Bolo Encantado", emoji: "🎂", rarity: "common", desc: "Sabor morango com confeitos" },
  { id: "s7", name: "Castelo das Estrelas", emoji: "🏰", rarity: "rare", desc: "Onde mora a magia" },
  { id: "s8", name: "Faísca Dragãozinho", emoji: "🐲", rarity: "gold", desc: "Cospe faíscas de glitter" },
  { id: "s9", name: "Nuvem Coelhinho", emoji: "🐰", rarity: "common", desc: "Pula pula nas flores" },
  { id: "s10", name: "Varinha de Condão", emoji: "🪄", rarity: "rare", desc: "Faz plim e realiza desejos" },
  { id: "s11", name: "Arco-Íris Celestial", emoji: "🌈", rarity: "rare", desc: "Ponte para o Reino dos Sonhos" },
  { id: "s12", name: "Elo DJ Pop", emoji: "🎧", rarity: "gold", desc: "Faz a festa dançar" },
  { id: "s13", name: "Pônei Jujuba", emoji: "🐴", rarity: "common", desc: "Galopa nos campos doces" },
  { id: "s14", name: "Estrela Guia", emoji: "⭐", rarity: "common", desc: "Ilumina as noites quentinhas" },
  { id: "s15", name: "Borboleta Dourada", emoji: "🦋", rarity: "rare", desc: "Asas de pura luz" },
  { id: "s16", name: "Super Elo Heroína", emoji: "🦸‍♀️", rarity: "gold", desc: "Protege todos com abraços" }
];

function getCollectedStickers(){
  try {
    return JSON.parse(localStorage.getItem("elo_stickers_album_v410") || "[]");
  } catch(_) {
    return [];
  }
}

function saveCollectedStickers(list){
  try {
    localStorage.setItem("elo_stickers_album_v410", JSON.stringify(list));
  } catch(_) {}
  updateStickersCounterUI();
}

function updateStickersCounterUI(){
  const list = getCollectedStickers();
  const homeCount = document.getElementById("homeStickerCountText");
  const modalCount = document.getElementById("albumStickerCounter");
  const text = `${list.length}/${STICKER_COLLECTION_DATA.length}`;
  if(homeCount) homeCount.textContent = text;
  if(modalCount) modalCount.textContent = `${text} coladas`;
}

window.openStickersAlbum = function(){
  const modal = document.getElementById("stickersModal");
  if(modal) modal.classList.remove("hidden");
  renderStickersAlbum();
  updateStickersCounterUI();
};

window.closeStickersAlbum = function(){
  const modal = document.getElementById("stickersModal");
  if(modal) modal.classList.add("hidden");
};

window.renderStickersAlbum = function(){
  const grid = document.getElementById("stickersAlbumGrid");
  if(!grid) return;
  const collected = getCollectedStickers();

  grid.innerHTML = STICKER_COLLECTION_DATA.map((s, idx) => {
    const isCollected = collected.includes(s.id);
    const rarityLabel = s.rarity === "gold" ? "HOLOGRÁFICA 🌟" : (s.rarity === "rare" ? "RARA 💎" : "COMUM 🌸");
    if(isCollected){
      return `
        <div class="stickerCard owned ${s.rarity}">
          <div style="font-size:48px;">${s.emoji}</div>
          <b>${s.name}</b>
          <small class="rarityTag">${rarityLabel}</small>
        </div>
      `;
    } else {
      return `
        <div class="stickerCard locked">
          <div style="font-size:36px;opacity:0.35;">🔒</div>
          <b style="color:var(--muted);">#${idx + 1}</b>
          <small style="font-size:11px;color:var(--muted);">${rarityLabel}</small>
        </div>
      `;
    }
  }).join("");
};

let currentOpenedStickers = [];

window.openStickerPack = function(){
  const prof = getActiveProfile();
  if((prof.stars || 0) < 5){
    toast("Você precisa de 5 estrelinhas para abrir um pacotinho surpresa! ⭐");
    return;
  }
  prof.stars -= 5;
  saveProfiles();
  playCuteSfx("coin");

  // Sorteia 3 figurinhas
  const shuffled = shuffle([...STICKER_COLLECTION_DATA]);
  currentOpenedStickers = shuffled.slice(0, 3);

  const packArea = document.getElementById("revealedPackArea");
  const revealCards = document.getElementById("revealedStickersCards");
  const collectBtn = document.getElementById("collectStickersBtn");
  if(packArea) packArea.classList.remove("hidden");
  if(collectBtn) collectBtn.classList.remove("hidden");

  if(revealCards){
    revealCards.innerHTML = currentOpenedStickers.map(s => `
      <div class="stickerPackRevealCard ${s.rarity}">
        <div style="font-size:54px;animation:dollCelebration .6s infinite alternate;">${s.emoji}</div>
        <h4 style="margin:6px 0 2px;">${s.name}</h4>
        <p style="font-size:12px;color:var(--muted);margin:0 0 4px;">${s.desc}</p>
        <span class="badge" style="background:#fce7f3;color:#d84376;font-size:11px;">
          ${s.rarity === "gold" ? "✨ HOLOGRÁFICA!" : (s.rarity === "rare" ? "💎 RARA!" : "🌸 LINDA!")}
        </span>
      </div>
    `).join("");
  }
  playCuteSfx("win");
  triggerStarConfetti();
  toast("Pacotinho aberto! Veja que figurinhas lindas você tirou! 🎁🎉");
};

window.collectRevealedStickers = function(){
  if(!currentOpenedStickers.length) return;
  const collected = getCollectedStickers();
  currentOpenedStickers.forEach(s => {
    if(!collected.includes(s.id)) collected.push(s.id);
  });
  saveCollectedStickers(collected);
  currentOpenedStickers = [];

  const packArea = document.getElementById("revealedPackArea");
  if(packArea) packArea.classList.add("hidden");
  renderStickersAlbum();
  playCuteSfx("win");
  triggerStarConfetti();
  toast("Figurinhas coladas com sucesso no seu álbum! 📖💖");
};

// --- 8. MODO HORA DO SONINHO & CANÇÃO DE NINAR ---
let sleepLullabyPlaying = false;
let lullabyTimer = null;

window.toggleSleepMode = function(force){
  const overlay = document.getElementById("sleepModeOverlay");
  if(!overlay) return;
  const isHidden = overlay.classList.contains("hidden");
  if(force === false || !isHidden){
    overlay.classList.add("hidden");
    if(sleepLullabyPlaying) toggleLullabyPlay();
  } else {
    overlay.classList.remove("hidden");
    playCuteSfx("pop");
    toast("Boa noite, anjinho! Bons sonhos com as estrelinhas... 🌙💤");
  }
};

window.toggleLullabyPlay = function(){
  const btn = document.getElementById("lullabyToggleBtn");
  const ctx = getAudioContext();
  if(sleepLullabyPlaying){
    sleepLullabyPlaying = false;
    if(lullabyTimer) clearInterval(lullabyTimer);
    if(btn) {
      btn.textContent = "🎵 Tocar Caixinha de Música Suave";
      btn.style.background = "";
    }
    toast("Música de ninar pausada 🌙");
  } else {
    sleepLullabyPlaying = true;
    if(btn) {
      btn.textContent = "⏸ Pausar Caixinha de Música";
      btn.style.background = "#6366f1";
    }
    toast("Tocando caixinha de música dos sonhos... 🎶✨");
    
    // Melodia de ninar relaxante e suave (Brahms' Lullaby / Nana Neném)
    const notes = [
      261.63, 261.63, 293.66, 261.63, 349.23, 329.63,
      261.63, 261.63, 293.66, 261.63, 392.00, 349.23,
      261.63, 261.63, 523.25, 440.00, 349.23, 329.63, 293.66,
      466.16, 466.16, 440.00, 349.23, 392.00, 349.23
    ];
    let noteIdx = 0;
    lullabyTimer = setInterval(()=>{
      if(!sleepLullabyPlaying) return;
      playTone(notes[noteIdx], 0.75, "sine");
      noteIdx = (noteIdx + 1) % notes.length;
    }, 900);
  }
};

window.readBedtimeStory = function(idx){
  const stories = [
    {
      title: "O Pônei que Queria Voar com as Estrelas",
      text: "Era uma vez um pônei fofinho chamado Jujuba. Todas as noites, ele olhava para o céu e via as estrelinhas cintilando. Certa noite, uma fada amiga borrifou pozinho de sonhos em suas crinas. Jujuba deu um saltinho suave e flutuou entre as nuvens macias, descansando em um travesseirinho de algodão bem quentinho..."
    },
    {
      title: "O Ursinho e o Abraço da Lua",
      text: "Lá na floresta dos sonhos encantados, o ursinho Pingo estava com muito soninho. A Lua cheia desceu bem devagarinho e cobriu o ursinho com um cobertor de luz prateada. Pingo fechou os olhinhos, respirou fundo e dormiu um sono profundo e feliz..."
    }
  ];
  const s = stories[idx] || stories[0];
  const content = document.getElementById("sleepStoryContent");
  if(content){
    content.innerHTML = `
      <div style="background:rgba(255,255,255,0.1);padding:18px;border-radius:18px;margin-top:12px;border:1px solid rgba(255,255,255,0.2);">
        <h4 style="margin:0 0 8px;color:#fbcfe8;">📖 ${s.title}</h4>
        <p style="font-size:15px;line-height:1.6;margin:0;color:#f1f5f9;">${s.text}</p>
      </div>
    `;
    if(typeof speakText === "function") speakText(s.text);
  }
};

// --- FEEDBACKS DE SONS E INICIALIZAÇÃO SEGURA ---
const originalAddStarsV410 = addStars;
addStars = function(n=1, msg="Você ganhou uma estrelinha! ⭐"){
  playCuteSfx("coin");
  originalAddStarsV410(n, msg);
};

document.addEventListener("pointerdown", e => {
  const btn = e.target?.closest?.("button, .portalCard, .schoolOptBtn, .cTabBtn, .familyTabBtn, .careTabBtn, .photoSceneBtn, .photoFrameBtn");
  if(btn && !btn.disabled){
    playCuteSfx("pop");
  }
}, { passive: true, capture: true });

// Inicializações automáticas com tratamento de erro
try { selectSchoolTrack("letters"); } catch(_) {}
try { initFreeDrawCanvas(); } catch(_) {}
try { generateNewChefOrder(); } catch(_) {}
try { updateStickersCounterUI(); } catch(_) {}

window.addEventListener('keyup',e=>{
  if(document.getElementById('gameModal')?.classList.contains('hidden'))return;
  if(document.getElementById('trailGame')?.classList.contains('active')){
    if(e.code==='KeyX'||e.code==='KeyW'||e.code==='KeyF'){e.preventDefault();trailFlyEnd();}
  }
});


// ==========================================================
// CONTROLE DE MODO DEITADO OBRIGATÓRIO (LANDSCAPE SYSTEM)
// ==========================================================
window.requestLandscapeMode = async function(){
  try {
    const el = document.documentElement;
    if (el.requestFullscreen) {
      await el.requestFullscreen();
    } else if (el.webkitRequestFullscreen) {
      await el.webkitRequestFullscreen();
    }
  } catch(e) {
    console.warn("Fullscreen request:", e);
  }

  try {
    if (screen.orientation && typeof screen.orientation.lock === 'function') {
      await screen.orientation.lock('landscape');
      toast('Modo Deitado ativado! 🌈');
      return;
    }
  } catch(e) {
    console.warn("Orientation lock error:", e);
  }

  // Fallback imediato: se o celular está com a rotação travada pelo Android/iOS, força o giro CSS 90°
  window.toggleForce90Rotation(true);
};

window.toggleForce90Rotation = function(forceVal){
  const shouldForce = typeof forceVal === 'boolean' ? forceVal : !document.body.classList.contains('force-landscape-90');
  if(shouldForce){
    document.body.classList.add('force-landscape-90');
    localStorage.setItem('elo_force_landscape_90', '1');
    toast('Giro forçado ativado! Celular pronto para deitar 📱🔄');
  } else {
    document.body.classList.remove('force-landscape-90');
    localStorage.removeItem('elo_force_landscape_90');
    toast('Modo de rotação padrão restaurado');
  }
};

function checkAutoLandscapePhysical(){
  try {
    if (window.matchMedia && window.matchMedia('(orientation: landscape)').matches) {
      if (document.body.classList.contains('force-landscape-90')) {
        document.body.classList.remove('force-landscape-90');
        localStorage.removeItem('elo_force_landscape_90');
      }
    }
  } catch(_) {}
}

window.addEventListener('resize', checkAutoLandscapePhysical);
window.addEventListener('orientationchange', checkAutoLandscapePhysical);
if (window.screen && window.screen.orientation) {
  window.screen.orientation.addEventListener('change', checkAutoLandscapePhysical);
}

// Inicializa preferência gravada caso esteja em modo retrato
window.addEventListener('DOMContentLoaded', () => {
  if (localStorage.getItem('elo_force_landscape_90') === '1' && window.matchMedia('(orientation: portrait)').matches) {
    document.body.classList.add('force-landscape-90');
  }
});

window.tryLockLandscape = function(){
  try {
    if(screen.orientation && typeof screen.orientation.lock === 'function' && document.fullscreenElement) {
      screen.orientation.lock('landscape').catch(() => {});
    }
  } catch(_) {}
};
